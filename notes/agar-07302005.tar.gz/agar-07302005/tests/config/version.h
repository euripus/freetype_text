#ifndef VERSION
#define VERSION "1.0"
#endif /* VERSION */
