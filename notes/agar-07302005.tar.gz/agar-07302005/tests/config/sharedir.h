#ifndef SHAREDIR
#define SHAREDIR "/usr/local/share"
#endif /* SHAREDIR */
