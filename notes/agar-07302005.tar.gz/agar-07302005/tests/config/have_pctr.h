#ifndef HAVE_PCTR
#define HAVE_PCTR
#endif /* HAVE_PCTR */
