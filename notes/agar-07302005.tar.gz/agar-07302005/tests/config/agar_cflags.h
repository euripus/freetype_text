#ifndef AGAR_CFLAGS
#define AGAR_CFLAGS                                                                                  \
    "-I/usr/local/include/agar -I/usr/local/include/SDL -D_REENTRANT -I/usr/local/include "          \
    "-I/usr/local/include/smpeg -I/usr/local/include/SDL -D_REENTRANT -I/usr/X11R6/include "         \
    "-I/usr/X11R6/include -I/usr/X11R6/include/freetype2 -I/usr/X11R6/include -I/usr/local/include " \
    "-I/usr/local/include "
#endif /* AGAR_CFLAGS */
