#ifndef ENABLE_NLS
#define ENABLE_NLS 1
#endif /* ENABLE_NLS */
