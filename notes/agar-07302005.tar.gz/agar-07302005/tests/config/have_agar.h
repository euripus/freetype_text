#ifndef HAVE_AGAR
#define HAVE_AGAR
#endif /* HAVE_AGAR */
