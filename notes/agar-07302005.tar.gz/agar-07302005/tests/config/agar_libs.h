#ifndef AGAR_LIBS
#define AGAR_LIBS                                                                                           \
    "-L/usr/local/lib/agar -lengine -linput -lerror -lmonitor -lmap -lspace -lvg -lrg -lwidget -lunicode "  \
    "-lloader -lcompat -lmat -L/usr/local/lib -L/usr/X11R6/lib -lSDL -pthread -lm -L/usr/X11R6/lib -lX11 "  \
    "-lXext -lusbhid -L/usr/local/lib -lsmpeg -L/usr/local/lib -L/usr/X11R6/lib -lSDL -pthread -lm "        \
    "-L/usr/X11R6/lib -lX11 -lXext -lusbhid -L/usr/X11R6/lib -L/usr/X11R6/lib -lfreetype -L/usr/X11R6/lib " \
    "-lGL -lm -L/usr/local/lib -ljpeg -L/usr/local/lib/qnet -lqnet "
#endif /* AGAR_LIBS */
