#ifndef LOCALEDIR
#define LOCALEDIR "/usr/local/share/locale"
#endif /* LOCALEDIR */
