/*	$Csoft: gaussj.h,v 1.1 2004/11/23 02:32:39 vedge Exp $	*/
/*	Public domain	*/

#ifndef _MAT_GAUSSJ_H_
#define _MAT_GAUSSJ_H_
#include "begin_code.h"

__BEGIN_DECLS
void mat_gaussj(struct mat *, struct mat *);
__END_DECLS

#include "close_code.h"
#endif /* _MAT_GAUSSJ_H_ */
