/*	$Csoft$	*/
/*	Public domain	*/

#include <engine/engine.h>

#include <sys/types.h>

#include <machine/cpu.h>
#include <machine/pctr.h>

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

static void * new_thread(void * arg)
{
    return (NULL);
}

void * func(void * foo)
{
    return (NULL);
}

static void foo_handler(int argc, union evarg * argv) {}

int main(int argc, char * argv[])
{
    pthread_t       thread;
    pctrval         tsc;
    unsigned long   avg = 0, tot = 0;
    int             i;
    pthread_mutex_t foo;
    struct object   obj;
    int             flags1 = 0;
    int             flags2 = 0x01;
    int             in1    = 0;
    int             in2    = 1;

    pthread_mutex_init(&foo, NULL);

    for(i = 0; i < 10000; i++)
    {
        tsc = rdtsc();
        pthread_create(&thread, NULL, new_thread, (void *)0xdeadbeef);
        pthread_join(thread, NULL);
        tsc  = rdtsc() - tsc;
        avg += tsc;
        tot++;
    }
    printf("thread: %lu cycles avg\n", (unsigned long)(avg / tot));

    tot = 0;
    avg = 0;
    for(i = 0; i < 1000000; i++)
    {
        tsc = rdtsc();
        func((void *)0xdeadbeef);
        tsc  = rdtsc() - tsc;
        avg += tsc;
        tot++;
    }
    printf("function: %lu cycles avg\n", (unsigned long)(avg / tot));

    tot = 0;
    avg = 0;
    for(i = 0; i < 1000000; i++)
    {
        int a, b, c;

        tsc  = rdtsc();
        c    = a + b + a + b + a + b + a + b;
        tsc  = rdtsc() - tsc;
        avg += tsc;
        tot++;
    }
    printf("addition: %lu cycles avg\n", (unsigned long)(avg / tot));

    tot = 0;
    avg = 0;
    for(i = 0; i < 1000000; i++)
    {
        int a = 40, b = 30, c = 20;

        tsc  = rdtsc();
        c    = a * b * a * b * a * b * a * b;
        tsc  = rdtsc() - tsc;
        avg += tsc;
        tot++;
    }
    printf("multiplication: %lu cycles avg\n", (unsigned long)(avg / tot));

    tot = 0;
    avg = 0;
    for(i = 0; i < 10000000; i++)
    {
        tsc = rdtsc();
        if(flags1 & 0x01)
        {
            flags1 = 0;
        }
        else
        {
            flags1 = 0x01;
        }
        if(flags2 & 0x01)
        {
            flags2 = 0;
        }
        else
        {
            flags2 = 0x01;
        }
        tsc  = rdtsc() - tsc;
        avg += tsc;
        tot++;
    }
    printf("flag check: %lu cycles avg\n", (unsigned long)(avg / tot));

    tot = 0;
    avg = 0;
    for(i = 0; i < 10000000; i++)
    {
        tsc = rdtsc();
        if(in1)
        {
            in1 = 0;
        }
        else
        {
            in1 = 1;
        }
        if(in2)
        {
            in2 = 0;
        }
        else
        {
            in2 = 1;
        }
        tsc  = rdtsc() - tsc;
        avg += tsc;
        tot++;
    }
    printf("int check: %lu cycles avg\n", (unsigned long)(avg / tot));

    return (0);
}
