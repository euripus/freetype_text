/*	$Csoft$	*/
/*	Public domain	*/

#include <sys/types.h>

#include <machine/cpu.h>
#include <machine/pctr.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int
main(int argc, char *argv[])
{
	pctrval tsc;
	unsigned long avg = 0, tot = 0;
	float f = 0;
	int i;

	for (f = 0.1f; f < 10000.0f; f+= 0.01f) {
		tsc = rdtsc();
		i = (int)f;
		tsc = rdtsc() - tsc;
		avg += tsc;
		tot++;
	}
	printf("(int) casts: %lu cycles avg\n",
	    (unsigned long)(avg/tot));
	
	for (f = 0.1f; f < 10000.0f; f+= 0.01f) {
		tsc = rdtsc();
		i = (int)rint(f);
		tsc = rdtsc() - tsc;
		avg += tsc;
		tot++;
	}
	printf("rint(): %lu cycles avg\n",
	    (unsigned long)(avg/tot));
	
	return (0);
}
