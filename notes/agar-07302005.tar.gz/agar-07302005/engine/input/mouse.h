/*	$Csoft: mouse.h,v 1.2 2005/05/08 11:09:20 vedge Exp $	*/
/*	Public domain	*/

#include "begin_code.h"

struct mouse {
	struct input in;
	int index;
};

__BEGIN_DECLS
struct mouse	*mouse_new(int);
Uint8		 mouse_get_state(int *, int *);
__END_DECLS

#include "close_code.h"
