/*	$Csoft: color.h,v 1.1 2004/04/30 07:00:23 vedge Exp $	*/
/*	Public domain	*/

#include "begin_code.h"

__BEGIN_DECLS
Uint32	read_color(struct netbuf *, SDL_PixelFormat *);
void	write_color(struct netbuf *, SDL_PixelFormat *, Uint32);
__END_DECLS

#include "close_code.h"
