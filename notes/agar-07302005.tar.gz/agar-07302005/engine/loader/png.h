/*	$Csoft$	*/
/*	Public domain	*/

#include "begin_code.h"

__BEGIN_DECLS
SDL_Surface * png_load(struct netbuf *);
void          png_save(struct netbuf *, SDL_Surface *);
__END_DECLS

#include "close_code.h"
