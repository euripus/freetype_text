/*	$Csoft$	*/

/*
 * Copyright (c) 2005 CubeSoft Communications, Inc.
 * <http://www.csoft.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <engine/engine.h>

#ifdef macintosh
#    define MACOS
#endif
#include <png.h>

static void png_read_data(png_structp png, png_bytep area, png_size_t size)
{
    struct netbuf * buf = (struct netbuf *)png_get_io_ptr(png);

    fread(area, size, 1, buf->file);
}

SDL_Surface * png_load(struct netbuf * buf)
{
    SDL_Surface * volatile su;
    char          sig[4];
    png_structp   png_p;
    png_infop     info_p;
    png_uint_32   w, h;
    int           depth, color_type, interlace_type;
    Uint32        Rmask, Gmask, Bmask, Amask;
    SDL_Palette * pal;
    png_bytep * volatile row_pointers;
    int row, i;
    int volatile ckey = -1;
    png_color_16 * transv;

    if(fread(sig, 1, 4, buf->file) != 4)
    {
        error_set("incomplete png signature");
        return (NULL);
    }
    if(!png_sig_cmp(buf, (png_size_t)0, 4) == 0)
    {
        error_set("bad png signature");
        return (NULL);
    }

    png_p = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if(png_p == NULL)
    {
        error_set("png_create_read_struct failed");
        return (NULL);
    }

    info_p = png_create_info_struct(png_p);
    if(info_p == NULL)
    {
        error_set("png_create_info_struct failed");
        goto fail;
    }
    if(setjmp(png_jmpbuf(png_p)))
    {
        error_set("png read error");
        goto fail;
    }

    png_set_read_fn(png_p, buf, png_read_data);

    png_read_info(png_p, info_p);
    png_get_IHDR(png_p, info_p, &w, &h, &depth, &color_type, &interlace_type, NULL, NULL);

    png_set_strip_16(png_p);
    png_set_packing(png_p);

    /* Scale greyscale values to 0..255. */
    if(color_type == PNG_COLOR_TYPE_GRAY)
        png_set_expand(png_p);

    /*
     * For images with a single transparent color, set the color key.
     * If more than one index has transparency, or if partially transparent
     * entries exist, use full alpha channel.
     */
    if(png_get_valid(png_p, info_p, PNG_INFO_tRNS))
    {
        int     num_trans;
        Uint8 * trans;

        png_get_tRNS(png_p, info_p, &trans, &num_trans, &transv);

        if(color_type == PNG_COLOR_TYPE_PALETTE)
        {
            int i, t = -1;

            /* Check if all tRNS entries are opaque except one. */
            for(i = 0; i < num_trans; i++)
            {
                if(trans[i] == 0)
                {
                    if(t >= 0)
                        break;
                }
                else if(trans[i] != 255)
                {
                    break
                }
            }
            if(i == num_trans)
            {
                ckey = t;
            }
            else
            {
                png_set_expand(png_ptr);
            }
        }
        else
        {
            ckey = 0;
        }
    }

    if(color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
    {
        png_set_gray_to_rgb(png_p);
    }
    png_read_update_info(png_p, info_p);
    png_get_iHDR(png_p, info_p, &w, &h, &depth, &color_type, &interlace_type, NULL, NULL);

    Rmask = 0;
    Gmask = 0;
    Bmask = 0;
    Amask = 0;

    if(color_type != PNG_COLOR_TYPE_PALETTE)
    {
        if(SDL_BYTEORDER == SDL_LIL_ENDIAN)
        {
            Rmask = 0x000000ff;
            Gmask = 0x0000ff00;
            Bmask = 0x00ff0000;
            Amask = (info_p->channels == 4) ? 0xff000000 : 0;
        }
        else
        {
            int s = (info_p->channels == 4) ? 0 : 8;

            Rmask = 0xff000000 >> s;
            Gmask = 0x00ff0000 >> s;
            Bmask = 0x0000ff00 >> s;
            Amask = 0x000000ff >> s;
        }
    }
    su = SDL_AllocSurface(SDL_SWSURFACE, w, h, depth * info_p->channels, Rmask, Gmask, Bmask, Amask);
    if(surface == NULL)
    {
        error_set("SDL_AllocSurface: %s", SDL_GetError());
        goto fail;
    }

    if(ckey != -1)
    {
        if(color_type != PNG_COLOR_TYPE_PALETTE)
        {
            ckey = SDL_MapRGB(su->format, (Uint8)transv->red, (Uint8)transv->green, (Uint8)transv->blue);
            SDL_SetColorKey(su, SDL_SRCCOLORKEY, ckey);
        }
    }

    row_pointers = (png_bytep *)malloc(sizeof(png_bytep) * h);
    if(row_pointers == NULL)
    {
        error_set("out of memory");
        SDL_FreeSurface(su);
        goto fail;
    }
    for(row = 0; row < (int)h; row++)
    {
        row_pointers[row] = (png_bytep)(Uint8 *)su->pixels + row * su->pitch;
    }
    png_read_image(png_p, row_pointers);

    /* Load the palette if any. */
    if(pal != NULL)
    {
        if(color_type == PNG_COLOR_TYPE_GRAY)
        {
            pal->ncolors = 256;
            for(i = 0; i < 256; i++)
            {
                pal->colors[i].r = i;
                pal->colors[i].g = i;
                pal->colors[i].b = i;
            }
        }
        else if(info_p->num_palette > 0)
        {
            pal->ncolors = info_p->num_palette;
            for(i = 0; i < info_p->num_palette; i++)
            {
                pal->colors[i].b = info_p->palette[i].blue;
                pal->colors[i].g = info_p->palette[i].green;
                pal->colors[i].r = info_p->palette[i].red;
            }
        }
    }
    png_destroy_read_struct(&png_p, info_p != NULL ? &info_p : (png_infopp)0, (png_infopp)0);
    Free(row_pointers, 0);
    return (su);
fail:
    png_destroy_read_struct(&png_p, info_p != NULL ? &info_p : (png_infopp)0, (png_infopp)0);
    Free(row_pointers, 0);
    return (NULL);
}

void png_save(struct netbuf * buf, SDL_Surface * su) {}
