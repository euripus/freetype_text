/*	$Csoft: spaceview.h,v 1.30 2004/09/12 05:51:44 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_PHYS_SPACEVIEW_H_
#define _AGAR_PHYS_SPACEVIEW_H_

#include <engine/widget/widget.h>
#include <engine/phys/space.h>

#include "begin_code.h"

struct spaceview
{
    struct widget  wid;
    struct space * space;
};

__BEGIN_DECLS
struct spaceview * spaceview_new(void *, struct space *);
void               spaceview_init(struct spaceview *, struct space *);
void               spaceview_destroy(void *);
void               spaceview_draw(void *);
void               spaceview_scale(void *, int, int);
__END_DECLS

#include "close_code.h"
#endif /* _AGAR_PHYS_SPACEVIEW_H_ */
