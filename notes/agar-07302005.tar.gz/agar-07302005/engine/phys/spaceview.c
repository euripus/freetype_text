/*	$Csoft: spaceview.c,v 1.83 2004/09/28 04:26:15 vedge Exp $	*/

/*
 * Copyright (c) 2004, 2005 CubeSoft Communications, Inc.
 * <http://www.csoft.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <engine/engine.h>
#include <engine/view.h>

#include "spaceview.h"

#include <engine/widget/primitive.h>

const struct widget_ops spaceview_ops = {
    {
     NULL, /* init */
        NULL, /* reinit */
        NULL, /* destroy */
        NULL, /* load */
        NULL, /* save */
        NULL  /* edit */
    },
    spaceview_draw,
    spaceview_scale
};

static void spaceview_mousemotion(int, union evarg *);
static void spaceview_mousebuttonup(int, union evarg *);
static void spaceview_mousebuttondown(int, union evarg *);
static void spaceview_keyup(int, union evarg *);
static void spaceview_keydown(int, union evarg *);

struct spaceview * spaceview_new(void * parent, struct space * sp)
{
    struct spaceview * sv;

    sv = Malloc(sizeof(struct spaceview), M_OBJECT);
    spaceview_init(sv, sp);
    object_attach(parent, sv);
    return (sv);
}

void spaceview_init(struct spaceview * sv, struct space * sp)
{
    SDL_Surface * label;

    widget_init(sv, "spaceview", &spaceview_ops, WIDGET_FOCUSABLE | WIDGET_UNFOCUSED_MOTION);
    sv->space = sp;
}

void spaceview_scale(void * p, int w, int h)
{
    struct spaceview * sv = p;

    if(w == -1 && h == -1)
    {
        WIDGET(sv)->w = 320;
        WIDGET(sv)->h = 240;
    }
}

void spaceview_draw(void * p)
{
    struct spaceview * sv = p;
}

static void spaceview_mousemotion(int argc, union evarg * argv)
{
    struct spaceview * sv = argv[0].p;
}

static void spaceview_mousebuttondown(int argc, union evarg * argv)
{
    struct spaceview * sv = argv[0].p;
}

static void spaceview_mousebuttonup(int argc, union evarg * argv)
{
    struct spaceview * sv = argv[0].p;
}

static void spaceview_keydown(int argc, union evarg * argv)
{
    struct spaceview * sv     = argv[0].p;
    int                keysym = argv[1].i;
}

static void spaceview_keyup(int argc, union evarg * argv)
{
    struct spaceview * sv = argv[0].p;
}
