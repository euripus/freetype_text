/*	$Csoft: object.h,v 1.1 2004/10/19 10:55:42 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_SOLID_H_
#define _AGAR_SOLID_H_

#include <engine/phys/space.h>

#include "begin_code.h"

struct solid
{
    struct object   obj;
    pthread_mutex_t lock;
    struct coords   pcoords; /* Coordinates inside parent */
};
#define SOLID(ob) ((struct solid *)(ob))

__BEGIN_DECLS
struct solid *  solid_new(void *, char const *);
void            solid_init(void *, char const *);
void            solid_destroy(void *);
struct window * solid_edit(void *);
int             solid_load(void *, struct netbuf *);
int             solid_save(void *, struct netbuf *);
__END_DECLS

#include "close_code.h"
#endif /* _AGAR_SOLID_H_ */
