/*	$Csoft: object.c,v 1.1 2004/10/19 10:55:42 vedge Exp $	*/

/*
 * Copyright (c) 2004, 2005 CubeSoft Communications, Inc.
 * <http://www.csoft.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <engine/engine.h>

#include <engine/map/map.h>

#include <engine/widget/window.h>
#include <engine/widget/hbox.h>
#include <engine/widget/vbox.h>
#include <engine/widget/textbox.h>
#include <engine/widget/spinbutton.h>

#include <errno.h>
#include <stdarg.h>
#include <string.h>

#include "solid.h"

const struct version solid_ver = {"agar phys solid", 0, 0};

const struct object_ops solid_ops = {solid_init, NULL, solid_destroy, solid_load, solid_save, solid_edit};

struct solid * solid_new(void * parent, char const * name)
{
    struct solid * so;

    so = Malloc(sizeof(struct solid), M_OBJECT);
    solid_init(so, name);
    object_attach(parent, so);
    return (so);
}

void solid_init(void * obj, char const * name)
{
    struct solid * so = obj;

    object_init(so, "solid", name, &solid_ops);
    pthread_mutex_init(&so->lock, NULL);
}

void solid_destroy(void * obj)
{
    /* nothing yet */
}

int solid_load(void * obj, struct netbuf * buf)
{
    struct solid * so = obj;

    if(version_read(buf, &solid_ver, NULL) != 0)
        return (-1);

    pthread_mutex_lock(&so->lock);
    pthread_mutex_unlock(&so->lock);
    return (0);
}

int solid_save(void * obj, struct netbuf * buf)
{
    struct solid * so = obj;

    version_write(buf, &solid_ver);

    pthread_mutex_lock(&so->lock);
    pthread_mutex_unlock(&so->lock);
    return (0);
}

struct window * solid_edit(void * obj)
{
    struct solid *  so = obj;
    struct window * win;
    struct vbox *   vb;

    win = window_new(WINDOW_DETACH | WINDOW_NO_VRESIZE, NULL);
    window_set_caption(win, _("Solid %s"), OBJECT(so)->name);

    return (win);
}
