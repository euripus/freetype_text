/*	$Csoft: animation.c,v 1.4 2005/03/06 04:54:10 vedge Exp $	*/

/*
 * Copyright (c) 2005 CubeSoft Communications, Inc.
 * <http://www.csoft.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <engine/engine.h>
#include <engine/view.h>

#include <engine/loader/surface.h>

#include <engine/widget/window.h>
#include <engine/widget/box.h>
#include <engine/widget/spinbutton.h>
#include <engine/widget/mspinbutton.h>
#include <engine/widget/checkbox.h>
#include <engine/widget/tlist.h>
#include <engine/widget/label.h>
#include <engine/widget/combo.h>
#include <engine/widget/notebook.h>
#include <engine/widget/bitmap.h>

#include "tileset.h"
#include "tileview.h"

#include <stdarg.h>

static Uint32
animtick(void *p, Uint32 ival, void *arg)
{
	struct animproc *ap = arg;
	struct animation *anim = ap->anim;

	if (++ap->frame < anim->nframes) {
		struct anim_frame *fr = &anim->frames[ap->frame];

		return (fr->delay != 0 ? fr->delay : ap->delay);
	} else {
		ap->frame = 0;
		return ((ap->flags & ANIMPROC_LOOP) ? ap->delay : 0);
	}
}

void
animproc_init(void *pobj, struct animproc *ap, struct animation *anim)
{
	ap->anim = anim;
	ap->frame = frame;
	ap->delay = 1;
	timeout_set(&ap->timer, animtick, ap, 0);
	timeout_add(pobj, &ap->timer, ap->delay);
}

void
animproc_set_speed(struct animproc *ap, u_int delay)
{
	ap->delay = delay;
}

void
animproc_set_frame(struct animproc *ap, u_int frame)
{
	ap->frame = frame;
}

void
animproc_destroy(void *pobj, struct animproc *ap)
{
	timeout_del(pobj, &ap->timer);
}
