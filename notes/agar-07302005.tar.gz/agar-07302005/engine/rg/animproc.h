/*	$Csoft: animation.h,v 1.4 2005/03/11 08:59:34 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_RG_ANIMATION_H_
#define _AGAR_RG_ANIMATION_H_

#include <engine/rg/tileset.h>
#include "begin_code.h"

struct anim_instance {
	struct animation *anim;
	u_int frame;			/* Current frame */
	u_int speed;			/* Delay in ticks */
	Uint8 flags;
#define ANIM_PLAY	0x01		/* Play this animation */
#define ANIM_REVERSE	0x02		/* Play in reverse */
};

struct animproc {
	struct timeout timer;
	struct anim_instance *instances;
	u_int	             ninstances;
};

__BEGIN_DECLS
void animproc_init(struct animproc *);
u_int animproc_add_instance(struct animproc *, struct animation *);

void animproc_destroy(struct animproc *);
void animproc_set_speed(struct animproc *, u_int);
__END_DECLS

#include "close_code.h"
#endif	/* _AGAR_RG_ANIMATION_H_ */
