/*	$Csoft: mkpath.h,v 1.4 2004/04/23 10:55:33 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_MKPATH_H_
#define _AGAR_MKPATH_H_
#include "begin_code.h"

__BEGIN_DECLS
int	mkpath(char *);
__END_DECLS

#include "close_code.h"
#endif /* _AGAR_MKPATH_H_ */
