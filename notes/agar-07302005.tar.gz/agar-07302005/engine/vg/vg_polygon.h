/*	$Csoft: vg_polygon.h,v 1.2 2005/06/04 04:48:45 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_VG_POLYGON_H_
#define _AGAR_VG_POLYGON_H_
#include "begin_code.h"

struct vg_polygon_args
{
    int outline;
};

#include "close_code.h"
#endif /* _AGAR_VG_POLYGON_H_ */
