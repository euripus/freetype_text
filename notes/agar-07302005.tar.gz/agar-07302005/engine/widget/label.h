/*	$Csoft: label.h,v 1.26 2005/05/26 06:43:28 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_WIDGET_LABEL_H_
#define _AGAR_WIDGET_LABEL_H_

#include <engine/widget/widget.h>

#include "begin_code.h"

#define LABEL_MAX          128
#define LABEL_MAX_POLLPTRS 32

enum label_type
{
    LABEL_STATIC,   /* Static text */
    LABEL_POLLED,   /* Polling (thread unsafe) */
    LABEL_POLLED_MT /* Polling (thread safe) */
};

struct label
{
    struct widget   wid;
    enum label_type type;
    pthread_mutex_t lock;
    int             surface;
    int             prew, preh;
    struct
    {
        char              fmt[LABEL_MAX];
        void *            ptrs[LABEL_MAX_POLLPTRS];
        int               nptrs;
        pthread_mutex_t * lock;
    } poll;
};

__BEGIN_DECLS
struct label *  label_new(void *, enum label_type, char const *, ...);
__inline__ void label_static(void *, char const *);
void            label_staticf(void *, char const *, ...);

void label_init(struct label *, enum label_type, char const *);
void label_destroy(void *);
void label_draw(void *);
void label_scale(void *, int, int);
void label_printf(struct label *, char const *, ...) FORMAT_ATTRIBUTE(printf, 2, 3) NONNULL_ATTRIBUTE(2);
void label_set_surface(struct label *, SDL_Surface *);
void label_prescale(struct label *, char const *);
__END_DECLS

#include "close_code.h"
#endif /* _AGAR_WIDGET_LABEL_H_ */
