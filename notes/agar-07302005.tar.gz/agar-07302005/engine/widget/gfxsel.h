/*	$Csoft: gfxsel.h,v 1.31 2005/01/30 05:39:11 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_WIDGET_GFXSEL_H_
#define _AGAR_WIDGET_GFXSEL_H_

#include <engine/widget/widget.h>

#include "begin_code.h"

struct gfxsel_item
{};

struct gfxsel
{
    struct widget wid;
    int           flags;
};

__BEGIN_DECLS
struct gfxsel * gfxsel_new(void *, int);
void            gfxsel_init(struct gfxsel *, int);
void            gfxsel_destroy(void *);
void            gfxsel_draw(void *);
void            gfxsel_scale(void *, int, int);
__END_DECLS

#include "close_code.h"
#endif /* _AGAR_WIDGET_GFXSEL_H_ */
