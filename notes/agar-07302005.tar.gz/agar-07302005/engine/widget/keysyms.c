/*	$Csoft: keysyms.c,v 1.2 2005/02/03 02:15:10 vedge Exp $	*/
/*	Public domain	*/

#include <engine/engine.h>

char const * keysyms[] = {
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     "Bsp",   "Tab",
    NULL,     NULL,      "Clr",       "Ret",    NULL,      NULL,    NULL,       NULL,     NULL,    "Pause",
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       "Esc",    NULL,    NULL,
    NULL,     NULL,      "Spc",       "!",      "DblQuot", "#",     "$",        NULL,     "&",     "Quot",
    "(",      ")",       "*",         "+",      ",",       "-",     ".",        "/",      "0",     "1",
    "2",      "3",       "4",         "5",      "6",       "7",     "8",        "9",      ":",     ";",
    "<",      "=",       ">",         "?",      "@",       NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     "[",       "\\",        "]",      "^",       "_",     "BackQuot", "A",      "B",     "C",
    "D",      "E",       "F",         "G",      "H",       "I",     "J",        "K",      "L",     "M",
    "N",      "O",       "P",         "Q",      "R",       "S",     "T",        "U",      "V",     "W",
    "X",      "Y",       "Z",         NULL,     NULL,      NULL,    NULL,       "Del",    NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    NULL,       NULL,     NULL,    NULL,
    NULL,     NULL,      NULL,        NULL,     NULL,      NULL,    "Kp0",      "Kp1",    "Kp2",   "Kp3",
    "Kp4",    "Kp5",     "Kp6",       "Kp7",    "Kp8",     "Kp9",   "Kp.",      "Kp/",    "Kp*",   "Kp-",
    "Kp+",    "KpEnt",   "Kp=",       "Up",     "Down",    "Right", "Left",     "Ins",    "Home",  "End",
    "PgUp",   "PgDn",    "F1",        "F2",     "F3",      "F4",    "F5",       "F6",     "F7",    "F8",
    "F9",     "F10",     "F11",       "F12",    "F13",     "F14",   "F15",      NULL,     NULL,    NULL,
    "NumLck", "CapsLck", "ScrollLck", "Rshift", "Lshift",  "Rctrl", "Lctrl",    "Ralt",   "Lalt",  "Rmeta",
    "Lmeta",  "Lsuper",  "Rsuper",    "Mode",   "Compose", "Help",  "Print",    "SysReq", "Break", "Menu",
    "Power",  "Euro",    "Undo",      NULL};

int const nkeysyms = sizeof(keysyms) / sizeof(keysyms[0]);
