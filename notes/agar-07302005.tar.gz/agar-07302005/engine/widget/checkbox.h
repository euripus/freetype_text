/*	$Csoft: checkbox.h,v 1.17 2005/05/13 09:21:47 vedge Exp $	*/
/*	Public domain	*/

#ifndef _AGAR_WIDGET_CHECKBOX_H_
#define _AGAR_WIDGET_CHECKBOX_H_

#include <engine/widget/widget.h>

#include "begin_code.h"

#define CHECKBOX_CAPTION_MAX 64

struct checkbox
{
    struct widget wid;

    int           state;    /* 1=pressed, 0=released */
    SDL_Surface * label_su; /* Text label */
    int           label_id;
};

__BEGIN_DECLS
struct checkbox * checkbox_new(void *, char const *, ...);
void              checkbox_init(struct checkbox *, char *);
void              checkbox_scale(void *, int, int);
void              checkbox_destroy(void *);
void              checkbox_draw(void *);
void              checkbox_toggle(struct checkbox *);
__END_DECLS

#include "close_code.h"
#endif /* _AGAR_WIDGET_CHECKBOX_H_ */
