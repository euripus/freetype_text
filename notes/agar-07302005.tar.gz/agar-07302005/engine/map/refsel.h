/*	$Csoft: refsel.h,v 1.2 2005/07/25 10:44:24 vedge Exp $	*/
/*	Public domain	*/

__BEGIN_DECLS
void refsel_update(struct mapview *, int, int);
void refsel_delete(struct mapview *);
__END_DECLS
