/*	$Csoft: position.c,v 1.5 2005/07/24 06:55:57 vedge Exp $	*/

/*
 * Copyright (c) 2002, 2003, 2004, 2005 CubeSoft Communications, Inc.
 * <http://www.csoft.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <engine/engine.h>

#ifdef MAP

#    include <engine/input.h>

#    include <engine/widget/tlist.h>
#    include <engine/widget/checkbox.h>
#    include <engine/widget/combo.h>
#    include <engine/widget/spinbutton.h>

#    include <string.h>

#    include "map.h"
#    include "mapedit.h"

static int    center_view  = 0;    /* Center view around? */
static int    pass_through = 0;    /* Ignore node movement restrictions */
static void * obj          = NULL; /* Object to position */
static void * projmap      = NULL; /* Projection map to display */
static void * input_dev    = NULL; /* Input device to control object */
static int    direction    = 0;    /* Angle of velocity vector */
static int    velocity     = 0;    /* Length of velocity vector */

static struct tlist_item * find_objs(struct tlist * tl, struct object * pob, int depth)
{
    char                label[TLIST_LABEL_MAX];
    struct object *     cob;
    struct tlist_item * it;

    strlcpy(label, pob->name, sizeof(label));
    if(pob->flags & OBJECT_DATA_RESIDENT)
    {
        strlcat(label, _(" (resident)"), sizeof(label));
    }
    it        = tlist_insert_item(tl, object_icon(pob), label, pob);
    it->depth = depth;

    if(!TAILQ_EMPTY(&pob->children))
    {
        it->flags |= TLIST_HAS_CHILDREN;
    }
    if((it->flags & TLIST_HAS_CHILDREN) && tlist_visible_children(tl, it))
    {
        TAILQ_FOREACH(cob, &pob->children, cobjs)
        find_objs(tl, cob, depth + 1);
    }
    return (it);
}

static void poll_objs(int argc, union evarg * argv)
{
    struct tlist *  tl  = argv[0].p;
    struct object * pob = argv[1].p;

    lock_linkage();
    tlist_clear_items(tl);
    find_objs(tl, pob, 0);
    tlist_restore_selections(tl);
    unlock_linkage();
}

static void poll_input_devs(int argc, union evarg * argv)
{
    extern struct input_devq input_devs;
    extern pthread_mutex_t   input_lock;
    struct tlist *           tl = argv[0].p;
    struct input *           in;

    pthread_mutex_lock(&input_lock);
    tlist_clear_items(tl);
    SLIST_FOREACH(in, &input_devs, inputs)
    {
        tlist_insert_item(tl, NULL, in->name, in);
    }
    tlist_restore_selections(tl);
    pthread_mutex_unlock(&input_lock);
}

static void poll_projmaps(int argc, union evarg * argv)
{
    struct tlist * tl = argv[0].p;
    struct object *ob = obj, *child;

    if(ob == NULL)
        return;

    tlist_clear_items(tl);
    TAILQ_FOREACH(child, &ob->children, cobjs)
    {
        if(strcmp(child->type, "map") == 0)
        {
            tlist_insert_item(tl, object_icon(child), child->name, child);
        }
    }
    tlist_restore_selections(tl);
}

static void position_tool_init(struct tool * t)
{
    struct window * win;
    struct box *    bo;
    struct tlist *  tl;

    win = tool_window(t, "mapedit-tool-position");

    tl                 = tlist_new(win, TLIST_POLL | TLIST_TREE);
    WIDGET(tl)->flags |= WIDGET_HFILL;
    tlist_prescale(tl, "XXXXXXXXXXXXXXXXX", 5);
    widget_bind(tl, "selected", WIDGET_POINTER, &obj);
    event_new(tl, "tlist-poll", poll_objs, "%p", world);

    bo = box_new(win, BOX_VERT, BOX_WFILL);
    {
        struct checkbox *   cb;
        struct spinbutton * sb;
        struct combo *      com;

        com = combo_new(bo, COMBO_POLL, _("Projection map: "));
        event_new(com->list, "tlist-poll", poll_projmaps, NULL);
        widget_bind(com->list, "selected", WIDGET_POINTER, &projmap);

        com = combo_new(bo, COMBO_POLL, _("Input device: "));
        event_new(com->list, "tlist-poll", poll_input_devs, NULL);
        widget_bind(com->list, "selected", WIDGET_POINTER, &input_dev);

        sb = spinbutton_new(bo, _("Direction: "));
        widget_bind(sb, "value", WIDGET_INT, &direction);
        spinbutton_set_min(sb, 0);
        spinbutton_set_max(sb, 255);
        spinbutton_set_increment(sb, 16);

        sb = spinbutton_new(bo, _("Velocity: "));
        widget_bind(sb, "value", WIDGET_INT, &velocity);
        spinbutton_set_min(sb, 0);
        spinbutton_set_max(sb, 255);
        spinbutton_set_increment(sb, 2);

        cb = checkbox_new(bo, _("Center view"));
        widget_bind(cb, "state", WIDGET_BOOL, &center_view);

        cb = checkbox_new(bo, _("Pass through"));
        widget_bind(cb, "state", WIDGET_BOOL, &pass_through);
    }
}

static int position_tool_effect(struct tool * t, struct node * n)
{
    struct mapview * mv       = t->mv;
    struct object *  ob       = obj;
    int              posflags = 0;

    if(ob == NULL)
    {
        text_msg(MSG_ERROR, _("No object selected."));
        return (1);
    }
    if(projmap == NULL)
    {
        text_msg(MSG_ERROR, _("No projection map was selected."));
        return (1);
    }
    if(position_set(ob, mv->map, mv->cx, mv->cy, mv->map->cur_layer) == -1)
    {
        text_msg(MSG_ERROR, "%s", error_get());
        return (1);
    }
    position_set_projmap(ob, projmap);
    position_set_input(ob, input_dev);
    position_set_velvec(ob, direction, velocity);

    ob->pos->flags = 0;
    if(center_view)
    {
        ob->pos->flags |= POSITION_CENTER_VIEW;
    }
    if(pass_through)
    {
        ob->pos->flags |= POSITION_PASS_THROUGH;
    }
    return (0);
}

const struct tool position_tool = {
    "position",
    N_("Set Object Position"),
    POSITION_TOOL_ICON,
    -1,
    TOOL_HIDDEN,
    position_tool_init,
    NULL, /* destroy */
    NULL, /* load */
    NULL, /* save */
    NULL, /* cursor */
    position_tool_effect,
    NULL, /* mousemotion */
    NULL, /* mousebuttondown */
    NULL, /* mousebuttonup */
    NULL, /* keydown */
    NULL, /* keyup */
    NULL  /* pane */
};

#endif /* MAP */
