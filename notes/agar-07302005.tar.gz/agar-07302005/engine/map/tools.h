/*	$Csoft: tools.h,v 1.3 2005/07/30 05:01:34 vedge Exp $	*/
/*	Public domain	*/

extern const struct tool_ops nodesel_ops;
extern const struct tool_ops refsel_ops;
extern const struct tool_ops fill_tool_ops;
extern const struct tool_ops insert_ops;
extern const struct tool_ops flip_ops;
extern const struct tool_ops invert_ops;
