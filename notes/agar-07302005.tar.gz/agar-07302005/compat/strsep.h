/*	$Csoft: strsep.h,v 1.1 2004/02/26 09:19:38 vedge Exp $	*/
/*	Public domain	*/

#include <config/have_strsep.h>

#ifndef HAVE_STRSEP
char	*strsep(char **, const char *);
#endif

