/*	$Csoft: asprintf.h,v 1.1 2004/02/26 09:19:37 vedge Exp $	*/
/*	Public domain	*/

#include <config/have_asprintf.h>

#ifdef HAVE_ASPRINTF
#    ifdef __linux__
#        define _GNU_SOURCE
#    endif
#    include <stdio.h>
#else
int asprintf(char **, char const *, ...);
#endif
