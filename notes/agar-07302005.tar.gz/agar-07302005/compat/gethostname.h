/*	$Csoft: gethostname.h,v 1.1 2004/02/26 09:19:38 vedge Exp $	*/
/*	Public domain	*/

#include <config/have_gethostname.h>

#include <sys/types.h>

#ifdef HAVE_GETHOSTNAME
#    include <unistd.h>
#else
int gethostname(char * name, size_t namelen);
#endif
