/*	$Csoft: setenv.h,v 1.1 2004/02/26 09:19:38 vedge Exp $	*/
/*	Public domain	*/

#include <config/have_setenv.h>

#ifndef HAVE_SETENV
int  setenv(char const *, char const *, int);
void unsetenv(char const *);
#endif
