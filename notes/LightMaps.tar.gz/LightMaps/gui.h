/* Graphic user interface
 *
 * Copyright (C) 2003-2005, Alexander Zaprjagaev <frustum@frustum.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __GUI_H__
#define __GUI_H__

#include <vector>
#include "mathlib.h"
#include "texture.h"
#include "font.h"

#define GUI_FADE_IN_SPEED	8.0f
#define GUI_FADE_OUT_SPEED	4.0f

class Widget;
class VBox;
class HBox;

/*
 */
class Gui {
public:
	
	Gui(const char *font,const char *path);
	Gui(Font *font,const char *path);
	~Gui();
	
	void render(int width,int height,int mouse_x,int mouse_y,int mouse_button,float ifps);
	
	int getActivity();
	
	void setAlpha(float alpha);
	
	void addWidget(Widget *widget,int flags = 0);
	void removeWidget(Widget *widget);
	int isChild(Widget *widget);
	
	enum {
		FOCUS_IN = 0,
		FOCUS_OUT,
		CHANGED,
		CLICKED,
		ACTIVATED,
		DEACTIVATED,
		NUM_CALLBACKS,
	};
	
	enum {
		ALIGN_LEFT = 1 << 0,
		ALIGN_RIGHT = 1 << 1,
		ALIGN_TOP = 1 << 2,
		ALIGN_BOTTOM = 1 << 3,
		ALIGN_EXPAND = 1 << 4,
		ALIGN_OVERLAP = 1 << 5,
	};
	
protected:
	
	friend class Widget;
	friend class Window;
	friend class VBox;
	friend class HBox;
	friend class Sprite;
	friend class Label;
	friend class Button;
	friend class CheckBox;
	friend class HSlider;
	
	void load(const char *path);	// load textures
	
	Font *font;				// font
	VBox *vbox;				// main container
	
	int width;				// screen size
	int height;
	
	int old_mouse_x;		// old mouse coordinates
	int old_mouse_y;
	int mouse_dx;			// mouse movement
	int mouse_dy;
	int mouse_button;		// mouse button
	
	float alpha;			// transparency
	float time;				// time
	
	Widget *focus;			// focused widget
	int grab_mouse;			// mouse grab flag
	
	Texture *window_tex;	// textures
	Texture *window_border_tex;
	Texture *button_tex;
	Texture *button_pressed_tex;
	Texture *checkbox_tex;
	Texture *hslider_tex;
	Texture *hslider_button_tex;
};

/*
 */
class Widget {
public:
	
	Widget(Gui *gui);
	virtual ~Widget();
	
	inline Widget *widget() { return this; }
	
	virtual void addWidget(Widget *widget,int flags = 0);
	virtual void removeWidget(Widget *widget);
	virtual void raiseWidget(Widget *widget);
	virtual int isChild(Widget *widget);
	
	void setParent(Widget *parent);
	void setFlags(int flags);
	
	void addCallBack(int callback,void (*func)(Widget *widget,void*),void *data = NULL);
	
protected:
	
	friend class Gui;
	friend class Window;
	friend class VBox;
	friend class HBox;
	friend class Sprite;
	friend class Label;
	friend class Button;
	friend class CheckBox;
	friend class HSlider;
	
	virtual void arrange();
	virtual void expand(int width,int height);
	virtual void check_callbacks(int mouse_x,int mouse_y);
	virtual void render(int mouse_x,int mouse_y) = 0;
	
	void render_quad(int x0,int y0,float tx0,float ty0,int x1,int y1,float tx1,float ty1);
	
	Gui *gui;
	Widget *parent;
	
	int pos_x;			// position
	int pos_y;
	int size_x;			// size
	int size_y;
	
	int flags;			// flags
	
	float time;			// focus in/out time
	
	struct CallBack {
		void (*func)(Widget*,void*);
		void *data;
	};
	
	CallBack callbacks[Gui::NUM_CALLBACKS];
};

/*
 */
class Window : public Widget {
public:
	
	Window(Gui *gui,int pos_x,int pos_y);
	virtual ~Window();
	
	virtual void addWidget(Widget *widget,int flags = 0);
	virtual void removeWidget(Widget *widget);
	virtual int isChild(Widget *widget);
	
	void setPos(int pos_x,int pos_y);
	
protected:
	
	friend class VBox;
	friend class HBox;
	
	virtual void arrange();
	virtual void render(int mouse_x,int mouse_y);
	
	void render_window();
	
	int mouse_pos_x;	// mouse position
	int mouse_pos_y;
	VBox *vbox;			// window container
};

/*
 */
class VBox : public Widget {
public:
	
	VBox(Gui *gui,int border_x = 0,int border_y = 0);
	virtual ~VBox();
	
	virtual void addWidget(Widget *widget,int flags = 0);
	virtual void removeWidget(Widget *widget);
	virtual void raiseWidget(Widget *widget);
	virtual int isChild(Widget *widget);

protected:
	
	friend class Gui;
	friend class Window;
	friend class HBox;
	
	virtual void arrange();
	virtual void expand(int width,int height);
	virtual void check_callbacks(int mouse_x,int mouse_y);
	virtual void render(int mouse_x,int mouse_y);
	
	int border_x;					// border size
	int border_y;
	std::vector<Widget*> widgets;	// childs
};

/*
 */
class HBox : public Widget {
public:
	
	HBox(Gui *gui,int border_x = 0,int border_y = 0);
	virtual ~HBox();
	
	virtual void addWidget(Widget *widget,int flags = 0);
	virtual void removeWidget(Widget *widget);
	virtual void raiseWidget(Widget *widget);
	virtual int isChild(Widget *widget);

protected:
	
	friend class Gui;
	friend class Window;
	friend class VBox;
	
	virtual void arrange();
	virtual void expand(int width,int height);
	virtual void check_callbacks(int mouse_x,int mouse_y);
	virtual void render(int mouse_x,int mouse_y);
	
	int border_x;					// border size
	int border_y;
	std::vector<Widget*> widgets;	// childs
};


/*
 */
class Sprite : public Widget {
public:
	
	Sprite(Gui *gui,const char *name,int pos_x,int pos_y,float scale_x,float scale_y);
	virtual ~Sprite();
	
	void setPos(int pos_x,int pos_y);
	void setScale(float scale_x,float scale_y);
	void setRotation(float angle);
	void setColor(const vec3 &color);
	
protected:
	
	friend class VBox;
	friend class HBox;
	
	virtual void arrange();
	virtual void check_callbacks(int mouse_x,int mouse_y);
	virtual void render(int mouse_x,int mouse_y);
	
	float scale_x;
	float scale_y;
	float angle;
	vec3 color;
	
	Texture *texture;
};

/*
 */
class Label : public Widget {
public:
	
	Label(Gui *gui,const char *str,const vec3 &color);
	~Label();
	
	void setColor(const vec3 &color);
	void setSize(int size);
	void setText(const char *str);
	
	void printf(const char *format,...);
	
protected:
	
	friend class VBox;
	friend class HBox;
	
	virtual void arrange();
	virtual void check_callbacks(int mouse_x,int mouse_y);
	virtual void render(int mouse_x,int mouse_y);
	
	vec3 color;			// text color
	int size;			// text size
	char text[1024];	// text
};

/*
 */
class Button : public Widget {
public:
	
	Button(Gui *gui,const char *str,const vec3 &color,int toggle = 0);
	~Button();
	
	int getPressed();
	
	void setColor(const vec3 &color);
	void setSize(int size);
	void setText(const char *str);
	
	void printf(const char *format,...);

protected:
	
	friend class VBox;
	friend class HBox;
	
	virtual void arrange();
	virtual void render(int mouse_x,int mouse_y);
	
	void render_button();
	
	vec3 color;			// text color
	int size;			// text size
	char text[1024];	// text
	
	int toggle;			// toggle flag
	int pressed;
};

/*
 */
class CheckBox : public Widget {
public:
	
	CheckBox(Gui *gui,const char *str,const vec3 &color);
	virtual ~CheckBox();
	
	int getChecked();
	
	void setColor(const vec3 &color);
	void setSize(int size);
	void setText(const char *str);
	
	void printf(const char *format,...);
	
	void setChecked(int check);
	
	void attachCheckBox(CheckBox *cb);
	
protected:
	
	friend class VBox;
	friend class HBox;
	
	virtual void arrange();
	virtual void render(int mouse_x,int mouse_y);
	
	vec3 color;			// text color
	int size;			// text size
	char text[1024];	// text
	
	int checked;
	
	// checkbox will be radio button if it had attached checkboxs
	std::vector<CheckBox*> checkboxes;
};

/*
 */
class HSlider : public Widget {
public:
	
	HSlider(Gui *gui,float min_value,float max_value,float value);
	~HSlider();
	
	float getValue();
	
	void setValue(float value);
	void setWidth(int width);
	
	void attachFloat(float *extern_float);
	void attachLabel(Label *label,const char *format = NULL);
	
protected:
	
	friend class VBox;
	friend class HBox;
	
	virtual void arrange();
	virtual void render(int mouse_x,int mouse_y);
	
	float min_value;		// minimum value
	float max_value;		// maximum value
	
	float mouse_value;		// mouse value
	float value;			// clamped value
	
	int width;				// slider width
	
	float *extern_float;	// attached float
	
	Label *label;			// attached label
	char format[1024];
};

#endif /* __GUI_H__ */
