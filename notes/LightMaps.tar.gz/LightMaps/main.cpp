/* GPU Dynamic LightMap calculation
 *
 * Copyright (C) 2003-2004, Alexander Zaprjagaev <frustum@frustum.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <string.h>
#include "glapp.h"
#include "glext.h"
#include "pbuffer.h"
#include "mathlib.h"
#include "mesh.h"
#include "shader.h"
#include "texture.h"
#include "gui.h"
#include "spline.h"

/*
 *
 */
class GLAppMain : public GLApp {
public:
	
	GLAppMain() { object = this; }
	virtual ~GLAppMain() { }
	
	int init();
	void idle();
	
	void render_shadow(Texture *texture,const vec3 &light_pos);
	void render_lightmap();
	void render_scene();
	void render_particle(const vec3 &light_pos,float radius,float angle);
	void render_flare(const vec3 &light_pos,float radius,float angle,const vec3 &color);
	void render();
	
	// variables
	int pause;
	float time;
	int grab_cursor;
	int grab_mouse_x;
	int grab_mouse_y;
	
	int blur_toggle;
	int show_toggle;
	
	int video_flags;
	
	// camera
	float psi,phi;
	vec3 camera,dir,velocity;
	mat4 modelview;
	mat4 projection;
	
	// lights
	float light_radius;
	vec3 light_pos[4];
	vec3 light_colors[4];
	Spline *light_paths[4];
	
	// soft shadows
	Texture *shadow_tex[4];
	PBuffer *shadow_pbuffer;
	Texture *lightmap_tex;
	PBuffer *lightmap_pbuffer;
	
	// shaders
	Shader *ambient_shader;
	Shader *light_shader;
	Shader *shadow_shader;
	Shader *lightmap_shader;
	Shader *vexpand_shader;
	Shader *hexpand_shader;
	Shader *vblur_shader;
	Shader *hblur_shader;
	
	// meshes
	Mesh *room_mesh;
	
	// textures
	Texture *wall_b_tex;
	Texture *wall_ns_tex;
	Texture *floor_b_tex;
	Texture *floor_ns_tex;
	Texture *ceiling_b_tex;
	Texture *ceiling_ns_tex;
	Texture *normalize_tex;
	
	Texture *flare_tex;
	
	Gui *gui;
	Label *fps_label;
	Window *config_window;
	
	static GLAppMain &instance() { return *object; }
	static GLAppMain *pointer() { return object; }
	
private:
	static GLAppMain *object;
};

GLAppMain *GLAppMain::object = NULL;

/*****************************************************************************/
/*                                                                           */
/* init                                                                      */
/*                                                                           */
/*****************************************************************************/

/*
 */
static void quit_callback(Widget *widget,void *data) {
	GLAppMain::instance().exit();
}

static void fullscreen_callback(Widget *widget,void *data) {
	GLAppMain::instance().video_flags = GLAppMain::instance().flags ^ GLAppMain::FULLSCREEN;
}

static void antialiasing_callback(Widget *widget,void *data) {
	GLAppMain::instance().video_flags = GLAppMain::instance().flags ^ GLAppMain::MULTISAMPLE_4;
}

static void blur_callback(Widget *widget,void *data) {
	CheckBox *cb = reinterpret_cast<CheckBox*>(widget);
	if(cb->getChecked() == 1) GLAppMain::instance().blur_toggle = 1;
	else GLAppMain::instance().blur_toggle = 0;
}

static void show_callback(Widget *widget,void *data) {
	CheckBox *cb = reinterpret_cast<CheckBox*>(widget);
	if(cb->getChecked() == 1) GLAppMain::instance().show_toggle = 1;
	else GLAppMain::instance().show_toggle = 0;
}

static void shadows_callback(Widget *widget,void *data) {
	CheckBox *cb = reinterpret_cast<CheckBox*>(widget);
	if(cb->getChecked() == 0) return;
	if(data == (void*)1) {
		for(int i = 0; i < 4; i++) {
			delete GLAppMain::instance().shadow_tex[i];
			GLAppMain::instance().shadow_tex[i] = new Texture(256,256,Texture::TEXTURE_CUBE,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
		}
		delete GLAppMain::instance().shadow_pbuffer;
		GLAppMain::instance().shadow_pbuffer = new PBuffer(256,256,PBuffer::RGBA | PBuffer::DEPTH);
	} else if(data == (void*)2) {
		for(int i = 0; i < 4; i++) {
			delete GLAppMain::instance().shadow_tex[i];
			GLAppMain::instance().shadow_tex[i] = new Texture(512,512,Texture::TEXTURE_CUBE,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
		}
		delete GLAppMain::instance().shadow_pbuffer;
		GLAppMain::instance().shadow_pbuffer = new PBuffer(512,512,PBuffer::RGBA | PBuffer::DEPTH);
	}
}

static void lightmaps_callback(Widget *widget,void *data) {
	CheckBox *cb = reinterpret_cast<CheckBox*>(widget);
	if(cb->getChecked() == 0) return;
	if(data == (void*)1) {
		delete GLAppMain::instance().lightmap_tex;
		delete GLAppMain::instance().lightmap_pbuffer;
		GLAppMain::instance().lightmap_tex = new Texture(256,256,Texture::TEXTURE_2D,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
		GLAppMain::instance().lightmap_pbuffer = new PBuffer(256,256,PBuffer::RGBA);
	} else if(data == (void*)2) {
		delete GLAppMain::instance().lightmap_tex;
		delete GLAppMain::instance().lightmap_pbuffer;
		GLAppMain::instance().lightmap_tex = new Texture(512,512,Texture::TEXTURE_2D,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
		GLAppMain::instance().lightmap_pbuffer = new PBuffer(512,512,PBuffer::RGBA);
	} else if(data == (void*)3) {
		delete GLAppMain::instance().lightmap_tex;
		delete GLAppMain::instance().lightmap_pbuffer;
		GLAppMain::instance().lightmap_tex = new Texture(1024,1024,Texture::TEXTURE_2D,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
		GLAppMain::instance().lightmap_pbuffer = new PBuffer(1024,1024,PBuffer::RGBA);
	}
}

/*
 */
int GLAppMain::init() {
	
	// check hardware
	if(!checkExtension("GL_ARB_vertex_buffer_object")) return 0;
	if(!checkExtension("GL_ARB_shader_objects")) return 0;
	if(!checkExtension("GL_ARB_vertex_shader")) return 0;
	if(!checkExtension("GL_ARB_fragment_shader")) return 0;
	
	// init extensions
	glext_init();
	
	// variables
	pause = 0;
	time = 0.0;
	grab_cursor = 0;
	
	blur_toggle = 1;
	show_toggle = 0;
	
	video_flags = -1;
	
	// camera
	psi = -80;
	phi = 15;
	camera = vec3(-3.5,-7,3.5);
	velocity = vec3(0,0,0);
	
	// lights
	light_radius = 16.0f;
	light_colors[0] = vec3(0.6,0.5,0.43);
	light_colors[1] = vec3(0.5,0.4,0.36);
	light_colors[2] = vec3(0.6,0.5,0.37);
	light_colors[3] = vec3(0.55,0.5,0.35);
	light_paths[0] = new Spline("data/path_0.txt",1);
	light_paths[1] = new Spline("data/path_1.txt",1);
	light_paths[2] = new Spline("data/path_2.txt",1);
	light_paths[3] = new Spline("data/path_3.txt",1);
	
	// soft shadows
	for(int i = 0; i < 4; i++) {
		shadow_tex[i] = new Texture(256,256,Texture::TEXTURE_CUBE,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
	}
	shadow_pbuffer = new PBuffer(256,256,PBuffer::RGBA | PBuffer::DEPTH);
	
	lightmap_tex = new Texture(512,512,Texture::TEXTURE_2D,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR);
	lightmap_pbuffer = new PBuffer(512,512,PBuffer::RGBA);
	
	const char *fragment_target = NULL;
	const char *extensions = (const char*)glGetString(GL_EXTENSIONS);
	if(strstr(extensions,"GL_NV_fragment_program2")) fragment_target = "fragment_nv4x";
	else if(strstr(extensions,"GL_NV_fragment_program")) fragment_target = "fragment_nv3x";
	
	// shaders
	ambient_shader = new Shader("data/shaders/ambient.shader",NULL,NULL);
	light_shader = new Shader("data/shaders/light.shader",NULL,fragment_target);
	shadow_shader = new Shader("data/shaders/shadow.shader",NULL,NULL);
	lightmap_shader = new Shader("data/shaders/lightmap.shader",NULL,NULL);
	vexpand_shader = new Shader("data/shaders/expand.shader","vertex_vexpand",NULL);
	hexpand_shader = new Shader("data/shaders/expand.shader","vertex_hexpand",NULL);
	vblur_shader = new Shader("data/shaders/blur.shader","vertex_vblur",NULL);
	hblur_shader = new Shader("data/shaders/blur.shader","vertex_hblur",NULL);
	
	// meshes
	room_mesh = new Mesh("data/meshes/room.mesh");
	
	// textures
	wall_b_tex = new Texture("data/textures/wall_b.jpg",Texture::TEXTURE_2D,Texture::RGB | Texture::LINEAR_MIPMAP_LINEAR);
	wall_ns_tex = new Texture("data/textures/wall_ns.png",Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR);
	floor_b_tex = new Texture("data/textures/floor_b.jpg",Texture::TEXTURE_2D,Texture::RGB | Texture::LINEAR_MIPMAP_LINEAR);
	floor_ns_tex = new Texture("data/textures/floor_ns.png",Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR);
	ceiling_b_tex = new Texture("data/textures/ceiling_b.jpg",Texture::TEXTURE_2D,Texture::RGB | Texture::LINEAR_MIPMAP_LINEAR);
	ceiling_ns_tex = new Texture("data/textures/ceiling_ns.png",Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR);
	normalize_tex = new Texture("data/textures/normalize/normalize_%s.png",Texture::TEXTURE_CUBE,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR_MIPMAP_LINEAR);
	flare_tex = new Texture("data/textures/flare.png",Texture::TEXTURE_2D,Texture::RGBA | Texture::CLAMP_TO_EDGE | Texture::LINEAR_MIPMAP_LINEAR);
	
	// gui
	gui = new Gui("data/textures/gui/font.png","data/textures/gui/");
	
	fps_label = new Label(gui,"",vec3(1,1,1));
	gui->addWidget(fps_label,Gui::ALIGN_LEFT);
	
	config_window = new Window(gui,200,200);
	
	Label *label = new Label(gui,GREEN"GPU RealTime LightMaps demo"DEFAULT,vec3(1,1,1));
	config_window->addWidget(label,Gui::ALIGN_LEFT);
	label = new Label(gui,BLUE UNDERLINE_ON"http://frustum.org\n",vec3(1,1,1));
	config_window->addWidget(label,Gui::ALIGN_RIGHT);
	label = new Label(gui,"",vec3(1,1,1));
	label->printf("%s",glGetString(GL_RENDERER));
	config_window->addWidget(label);
	label = new Label(gui,"",vec3(1,1,1));
	label->printf("%s\n",glGetString(GL_VERSION));
	config_window->addWidget(label);
	
	CheckBox *cb = new CheckBox(gui,"FullScreen",vec3(1,1,1));
	cb->addCallBack(Gui::CHANGED,fullscreen_callback);
	config_window->addWidget(cb);
	
	cb = new CheckBox(gui,"4x Antialiasing",vec3(1,1,1));
	cb->addCallBack(Gui::CHANGED,antialiasing_callback);
	config_window->addWidget(cb);
	
	cb = new CheckBox(gui,"Blur LightMaps",vec3(1,1,1));
	cb->setChecked(1);
	cb->addCallBack(Gui::CHANGED,blur_callback);
	config_window->addWidget(cb);
	
	cb = new CheckBox(gui,"Show LightMaps",vec3(1,1,1));
	cb->addCallBack(Gui::CHANGED,show_callback);
	config_window->addWidget(cb);
	
	HBox *hbox = new HBox(gui,32,16);
	config_window->addWidget(hbox,Gui::ALIGN_EXPAND);

	VBox *vbox = new VBox(gui,0,0);
	hbox->addWidget(vbox,Gui::ALIGN_LEFT | Gui::ALIGN_TOP);
	
	{
		label = new Label(gui,"Shadows size",vec3(1,1,1));
		vbox->addWidget(label);
		CheckBox *cb_0 = new CheckBox(gui,"256",vec3(1,1,1));
		cb_0->setChecked(1);
		cb_0->addCallBack(Gui::CHANGED,shadows_callback,(void*)1);
		vbox->addWidget(cb_0);
		CheckBox *cb_1 = new CheckBox(gui,"512",vec3(1,1,1));
		cb_1->addCallBack(Gui::CHANGED,shadows_callback,(void*)2);
		vbox->addWidget(cb_1);
		cb_0->attachCheckBox(cb_1);
	}
	
	vbox = new VBox(gui,0,0);
	hbox->addWidget(vbox,Gui::ALIGN_RIGHT | Gui::ALIGN_TOP);
	
	{
	
		label = new Label(gui,"LightMaps size",vec3(1,1,1));
		vbox->addWidget(label);
		CheckBox *cb_0 = new CheckBox(gui,"256",vec3(1,1,1));
		cb_0->addCallBack(Gui::CHANGED,lightmaps_callback,(void*)1);
		vbox->addWidget(cb_0);
		CheckBox *cb_1 = new CheckBox(gui,"512",vec3(1,1,1));
		cb_1->setChecked(1);
		cb_1->addCallBack(Gui::CHANGED,lightmaps_callback,(void*)2);
		vbox->addWidget(cb_1);
		CheckBox *cb_2 = new CheckBox(gui,"1024",vec3(1,1,1));
		cb_2->addCallBack(Gui::CHANGED,lightmaps_callback,(void*)3);
		vbox->addWidget(cb_2);
		cb_0->attachCheckBox(cb_1);
		cb_0->attachCheckBox(cb_2);
	}
	
	Button *quit = new Button(gui," Quit ",vec3(1,1,1));
	quit->addCallBack(Gui::CLICKED,quit_callback);
	config_window->addWidget(quit,Gui::ALIGN_RIGHT);
	
	error();
	
	return 1;
}

/*****************************************************************************/
/*                                                                           */
/* rendering                                                                 */
/*                                                                           */
/*****************************************************************************/

/*
 */
void GLAppMain::render_shadow(Texture *texture,const vec3 &light_pos) {
	
	float matrix[6][16] = {
		{ 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 1 },
		{ 0, 0, 1, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 1 },
		{ 1, 0, 0, 0, 0, -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1 },
		{ -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }
	};
	
	GLuint target[6] = {
		GL_TEXTURE_CUBE_MAP_POSITIVE_X,
		GL_TEXTURE_CUBE_MAP_NEGATIVE_X,
		GL_TEXTURE_CUBE_MAP_POSITIVE_Y,
		GL_TEXTURE_CUBE_MAP_NEGATIVE_Y,
		GL_TEXTURE_CUBE_MAP_POSITIVE_Z,
		GL_TEXTURE_CUBE_MAP_NEGATIVE_Z,
	};
	
	shadow_pbuffer->enable();
	
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90.0,1.0,0.01,100.0);
	glMatrixMode(GL_MODELVIEW);
	
	shadow_shader->enable();
	shadow_shader->bind();
	shadow_shader->setParameter("light_pos:3",light_pos);
	shadow_shader->setParameter("light_radius:1",&light_radius);
	
	for(int i = 0; i < 6; i++) {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		glLoadIdentity();
		glMultMatrixf(matrix[i]);
		glTranslatef(-light_pos.x,-light_pos.y,-light_pos.z);
		
		room_mesh->render(-1);
		
		texture->bind(0);
		texture->copy(target[i]);
	}
	
	shadow_shader->disable();
	
	shadow_pbuffer->disable();
}

/*
 */
void GLAppMain::render_lightmap() {
	
	lightmap_pbuffer->enable();
	
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0,1,0,1,-1,1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glClearColor(1,1,1,1);
	glClear(GL_COLOR_BUFFER_BIT);
	
	// create lightmap
	lightmap_shader->enable();
	lightmap_shader->bind();
	lightmap_shader->setParameter("light_0_pos:3",light_pos[0]);
	lightmap_shader->setParameter("light_1_pos:3",light_pos[1]);
	lightmap_shader->setParameter("light_2_pos:3",light_pos[2]);
	lightmap_shader->setParameter("light_3_pos:3",light_pos[3]);
	lightmap_shader->setParameter("light_radius:1",&light_radius);
	shadow_tex[0]->bind(0);
	shadow_tex[1]->bind(1);
	shadow_tex[2]->bind(2);
	shadow_tex[3]->bind(3);
	room_mesh->render(-1);
	lightmap_shader->disable();
	
	lightmap_tex->bind(0);
	lightmap_tex->copy();
	
	for(int i = 0; i < 4; i++) {
		
		Shader *shader = NULL;
		if(i == 0) shader = vexpand_shader;
		else if(i == 1) shader = hexpand_shader;
		else if(i == 2) shader = vblur_shader;
		else if(i == 3) shader = hblur_shader;
		
		if(blur_toggle == 0 && shader == vblur_shader) break;
		
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-1,1,-1,1,-1,1);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		shader->enable();
		shader->bind();
		float size = lightmap_tex->width;
		shader->setParameter("size:1",&size);
		lightmap_tex->bind(0);
		lightmap_tex->render(-1,-1,1,1);
		shader->disable();
		
		lightmap_tex->bind(0);
		lightmap_tex->copy();
	}
	
	lightmap_pbuffer->disable();
}

/*
 */
void GLAppMain::render_scene() {
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	
	ambient_shader->enable();
	ambient_shader->bind();
	room_mesh->render();
	ambient_shader->disable();
	
	glDepthFunc(GL_EQUAL);
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE,GL_ONE);
	
	light_shader->enable();
	light_shader->bind();
	light_shader->setParameter("camera_pos:3",camera);
	light_shader->setParameter("light_radius:1",&light_radius);
	for(int i = 0; i < 4; i++) {
		
		vec4 shadow_mask;
		if(i == 0) shadow_mask = vec4(1,0,0,0);
		else if(i == 1) shadow_mask = vec4(0,1,0,0);
		else if(i == 2) shadow_mask = vec4(0,0,1,0);
		else if(i == 3) shadow_mask = vec4(0,0,0,1);
		
		light_shader->setParameter("light_pos:3",light_pos[i]);
		light_shader->setParameter("light_color:3",light_colors[i]);
		light_shader->setParameter("shadow_mask:4",shadow_mask);
		
		wall_b_tex->bind(0);
		wall_ns_tex->bind(1);
		lightmap_tex->bind(2);
		normalize_tex->bind(3);
		room_mesh->renderVertexClip(room_mesh->findSurface("wall"));
		
		floor_b_tex->bind(0);
		floor_ns_tex->bind(1);
		lightmap_tex->bind(2);
		normalize_tex->bind(3);
		room_mesh->renderVertexClip(room_mesh->findSurface("floor"));
		
		ceiling_b_tex->bind(0);
		ceiling_ns_tex->bind(1);
		lightmap_tex->bind(2);
		normalize_tex->bind(3);
		room_mesh->renderVertexClip(room_mesh->findSurface("ceiling"));
	}
	light_shader->disable();
	
	glDisable(GL_BLEND);
	glDepthFunc(GL_LESS);
}

/*
 */
void GLAppMain::render_particle(const vec3 &light_pos,float radius,float angle) {
	mat4 tmodelview = modelview.transpose();
	vec3 x = tmodelview * vec3(radius,0,0);
	vec3 y = tmodelview * vec3(0,radius,0);
	glPushMatrix();
	glTranslatef(light_pos.x,light_pos.y,light_pos.z);
	glMatrixMode(GL_TEXTURE);
	glTranslatef(0.5,0.5,0.0);
	glRotatef(angle,0,0,1);
	glTranslatef(-0.5,-0.5,0.0);
	glBegin(GL_TRIANGLE_STRIP);
	glTexCoord2f(0,1);
	glVertex3fv(-x - y);
	glTexCoord2f(1,1);
	glVertex3fv(x - y);
	glTexCoord2f(0,0);
	glVertex3fv(-x + y);
	glTexCoord2f(1,0);
	glVertex3fv(x + y);
	glEnd();
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

/*
 */
void GLAppMain::render_flare(const vec3 &light_pos,float radius,float angle,const vec3 &color) {
	glDepthMask(GL_FALSE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE,GL_ONE);
	flare_tex->enable();
	flare_tex->bind();
	glColor3fv(saturate(color));
	render_particle(light_pos,radius,angle);
	glColor3fv(saturate(color * 0.8 + vec3(0.1,0.1,0.1)));
	render_particle(light_pos,radius * 0.8,-angle);
	flare_tex->disable();
	glDisable(GL_BLEND);
	glDepthMask(GL_TRUE);
}

/*
 */
void GLAppMain::render() {
	
	render_shadow(shadow_tex[0],light_pos[0]);
	render_shadow(shadow_tex[1],light_pos[1]);
	render_shadow(shadow_tex[2],light_pos[2]);
	render_shadow(shadow_tex[3],light_pos[3]);
	
	render_lightmap();
	
	glMatrixMode(GL_PROJECTION);
    glLoadMatrixf(projection);
    glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf(modelview);
	
	render_scene();
	
	render_flare(light_pos[0],1.2,time * 30,light_colors[0]);
	render_flare(light_pos[1],1.2,time * 23,light_colors[1]);
	render_flare(light_pos[2],1.2,time * 27,light_colors[2]);
	render_flare(light_pos[3],1.2,time * 25,light_colors[3]);
	
	if(show_toggle) {
		glDepthFunc(GL_ALWAYS);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(1024,0,768,0,-1,1);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		glColor3f(1,1,1);
		lightmap_tex->enable();
		lightmap_tex->bind();
		lightmap_tex->render(0,0,256,256);
		lightmap_tex->disable();
	}
	
	fps_label->printf("FPS: %.1f",fps);
	
	gui->setAlpha(0.6);
	gui->render(2048,1536,2048 * mouse_x / window_width,1536 * mouse_y / window_height,mouse_button,ifps);
	
	error();
}

/*****************************************************************************/
/*                                                                           */
/* idle                                                                      */
/*                                                                           */
/*****************************************************************************/

/*
 */
void GLAppMain::idle() {
	
	// keyboard events
	if(keys[KEY_ESC]) {
		if(gui->isChild(config_window)) {
			gui->removeWidget(config_window);
		} else {
			gui->addWidget(config_window,Gui::ALIGN_OVERLAP);
		}
		keys[KEY_ESC] = 0;
	}
	
	if(keys[(int)' ']) {
		pause = !pause;
		keys[(int)' '] = 0;
	}
	if(pause == 0) time += ifps;
	
	if(video_flags != -1) {
		setVideoMode(window_width,window_height,video_flags);
		video_flags = -1;
	}
	
	// lights
	light_pos[0] = light_paths[0]->get(time,2.0);
	light_pos[1] = light_paths[1]->get(time,2.0);
	light_pos[2] = light_paths[2]->get(time,2.0);
	light_pos[3] = light_paths[3]->get(time,2.0);
	
	// free camera
	if(gui->getActivity() == 0 && grab_cursor == 0 && mouse_button & BUTTON_LEFT) {
		grab_mouse_x = mouse_x;
		grab_mouse_y = mouse_y;
		grab_cursor = 1;
		mouse_x = window_width / 2;
		mouse_y = window_height / 2;
		setMouse(mouse_x,mouse_y);
	}
	else if(grab_cursor == 1 && mouse_button & BUTTON_RIGHT) {
		setMouse(grab_mouse_x,grab_mouse_y);
		grab_cursor = 0;
	}
	
	if(grab_cursor) {
		showMouse(0);
		psi += (mouse_x - window_width / 2) * 0.2;
		phi += (mouse_y - window_height / 2) * 0.2;
		if(phi < -89) phi = -89;
		if(phi > 89) phi = 89;
		setMouse(window_width / 2,window_height / 2);
	} else {
		showMouse(1);
	}
	
	float vel = 50;
	if(keys[KEY_UP] || keys[(int)'w']) velocity.x += vel * ifps;
	if(keys[KEY_DOWN] || keys[(int)'s']) velocity.x -= vel * ifps;
	if(keys[KEY_LEFT] || keys[(int)'a']) velocity.y -= vel * ifps;
	if(keys[KEY_RIGHT] || keys[(int)'d']) velocity.y += vel * ifps;
	if(keys[KEY_SHIFT]) velocity.z += vel * ifps;
	if(keys[KEY_CTRL]) velocity.z -= vel * ifps;
	velocity -= velocity * 5.0 * ifps;
	
	dir = (quat(vec3(0,0,1),-psi) * quat(vec3(0,1,0),phi)).to_matrix() * vec3(1,0,0);
	vec3 x = dir;
	vec3 y = normalize(cross(dir,vec3(0,0,1)));
	vec3 z = normalize(cross(y,x));
	
	vec3 old = camera;
	camera += (x * velocity.x + y * velocity.y + z * velocity.z) * ifps;
	
	// simplest scene sliding don't make thus ;)
	for(int i = 0; i < 9; i++) {
		vec3 v;
		if(i == 0) v = dir;
		else if(i == 1) v = vec3(1,1,-1);
		else if(i == 2) v = vec3(1,-1,-1);
		else if(i == 3) v = vec3(-1,1,-1);
		else if(i == 4) v = vec3(-1,-1,-1);
		else if(i == 5) v = vec3(1,1,1);
		else if(i == 6) v = vec3(1,-1,1);
		else if(i == 7) v = vec3(-1,1,1);
		else if(i == 8) v = vec3(-1,-1,1);
		v *= 0.2;
		vec3 p,n;
		if(room_mesh->intersection(old + v,camera + v,p,n)) {
			float d = (camera - old) * n;
			if(d < 0) camera -= n * d;
		}
	}
	
	modelview.look_at(camera,camera + dir,vec3(0,0,1));
	projection.perspective(60.0,(float)window_width / (float)window_height,0.01,100.0);
}

/*****************************************************************************/
/*                                                                           */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

/*
 */
int main(int argc,char **argv) {
	
	GLAppMain *glApp = new GLAppMain;
	
	int width = 1024;
	int height = 768;
	int flags = 0;
	for(int i = 1; i < argc; i++) {
		if(!strcmp(argv[i],"-w") && i < argc - 1) sscanf(argv[++i],"%d",&width);
		else if(!strcmp(argv[i],"-h") && i < argc - 1) sscanf(argv[++i],"%d",&height);
		else if(!strcmp(argv[i],"-fs")) flags |= GLApp::FULLSCREEN;
		else if(!strcmp(argv[i],"-2x")) flags |= GLApp::MULTISAMPLE_2;
		else if(!strcmp(argv[i],"-4x")) flags |= GLApp::MULTISAMPLE_4;
		else {
			glApp->exit("unknown option \"%s\"",argv[i]);
			break;
		}
	}

	if(!glApp->done) {
		
		if(!glApp->setVideoMode(width,height,flags)) return 0;
		
		glApp->setTitle("GPU RealTime LightMaps http://frustum.org");
		
		if(!glApp->init()) glApp->exit("initialization failed\n");
		
		glApp->main();
	}
	
	delete glApp;
	
	return 0;
}
