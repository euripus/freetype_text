/* OpenGL pixel buffer
 *
 * Copyright (C) 2003-2005, Alexander Zaprjagaev <frustum@frustum.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _WIN32

/* linux
 */
#include <vector>
#include <GL/gl.h>
#include <GL/glx.h>
#include "texture.h"
#include "pbuffer.h"

/*
 */
struct PBuffer_data {
	Display *display;
	
	GLXPbuffer pbuffer;
	GLXContext context;
	
	GLXPbuffer old_pbuffer;
	GLXContext old_context;
};

/*
 */
PBuffer::PBuffer(int width,int height,int flags) : width(width), height(height), flags(flags), target(NULL) {
	
	Display *display = glXGetCurrentDisplay();
	int screen = DefaultScreen(display);
	GLXContext old_context = glXGetCurrentContext();
	
	int bits = 8;
	if(flags & FLOAT_16) bits = 16;
	if(flags & FLOAT_32) bits = 32;
	
	std::vector<int> attrib;
	attrib.push_back(GLX_RENDER_TYPE);
	attrib.push_back(GLX_RGBA_BIT);
	attrib.push_back(GLX_DRAWABLE_TYPE);
	attrib.push_back(GLX_PBUFFER_BIT);
	attrib.push_back(GLX_DOUBLEBUFFER);
	attrib.push_back(false);
	if((flags & LUMINANCE) || (flags & RGB) || (flags & RGBA)) {
		attrib.push_back(GLX_RED_SIZE);
		attrib.push_back(bits);
		if(flags & RGB) {
			attrib.push_back(GLX_GREEN_SIZE);
			attrib.push_back(bits);
			attrib.push_back(GLX_BLUE_SIZE);
			attrib.push_back(bits);
		}
		if(flags & RGBA) {
			attrib.push_back(GLX_ALPHA_SIZE);
			attrib.push_back(bits);
		}
	}
	if(flags & DEPTH) {
		attrib.push_back(GLX_DEPTH_SIZE);
		attrib.push_back(24);
	}
	if(flags & STENCIL) {
		attrib.push_back(GLX_STENCIL_SIZE);
		attrib.push_back(8);
	}
	if((flags & FLOAT_16) || (flags & FLOAT_32)) {
		attrib.push_back(GLX_FLOAT_COMPONENTS_NV);
		attrib.push_back(true);
	}
	if((flags & MULTISAMPLE_2) || (flags & MULTISAMPLE_4)) {
		attrib.push_back(GLX_SAMPLE_BUFFERS_ARB);
		attrib.push_back(true);
		attrib.push_back(GLX_SAMPLES_ARB);
		attrib.push_back(flags & MULTISAMPLE_2 ? 2 : 4);
	}
	attrib.push_back(0);
	
	std::vector<int> pattrib;
	
	pattrib.push_back(GLX_LARGEST_PBUFFER);
	pattrib.push_back(false);
	pattrib.push_back(0);
	
	GLXPbuffer pbuffer;
	GLXContext context;
	
	try {
		
		int count;
		GLXFBConfig *config;
		
		const char *extensions = glXQueryExtensionsString(display,screen);
		
		if(strstr(extensions,"GLX_SGIX_pbuffer") && strstr(extensions,"GLX_SGIX_fbconfig")) {
			pattrib.push_back(0);
			
			config = glXChooseFBConfigSGIX(display,screen,&attrib[0],&count);
			if(!config) throw("glXChooseFBConfigSGIX() failed");
			
			pbuffer = glXCreateGLXPbufferSGIX(display,config[0],width,height,&pattrib[0]);
			if(!pbuffer) throw("glXCreateGLXPbufferSGIX() failed");
			
			context = glXCreateContextWithConfigSGIX(display,config[0],GLX_RGBA_TYPE,old_context,true);
			if(!context) throw("glXCreateContextWithConfigSGIX() failed");
			
		} else {
			pattrib.push_back(GLX_PBUFFER_WIDTH);
			pattrib.push_back(width);
			pattrib.push_back(GLX_PBUFFER_HEIGHT);
			pattrib.push_back(height);
			pattrib.push_back(0);
			
			config = glXChooseFBConfig(display,screen,&attrib[0],&count);	
			if(!config) throw("glXChooseFBConfig() failed");
			
			pbuffer = glXCreatePbuffer(display,config[0],&pattrib[0]);
			if(!pbuffer) throw("glXCreatePbuffer() failed");
			
			XVisualInfo *visual = glXGetVisualFromFBConfig(display,config[0]);
			if(!visual) throw("glXGetVisualFromFBConfig() failed");
			
			context = glXCreateContext(display,visual,old_context,true);
			if(!context) throw("glXCreateContext() failed");
		}
	}
	catch(const char *error) {
		fprintf(stderr,"PBuffer::PBuffer(): %s\n",error);
		pbuffer = glXGetCurrentDrawable();
		context = old_context;
	}
	
	data = new PBuffer_data;
	data->display = display;
	
	data->pbuffer = pbuffer;
	data->context = context;
	
	data->old_pbuffer = glXGetCurrentDrawable();
	data->old_context = old_context;
}

/*
 */
PBuffer::~PBuffer() {
	if(data->context) glXDestroyContext(data->display,data->context);
	if(data->pbuffer) glXDestroyPbuffer(data->display,data->pbuffer);
	delete data;
}

/*
 */
void PBuffer::enable(Texture *target_) {
	data->old_pbuffer = glXGetCurrentDrawable();
	data->old_context = glXGetCurrentContext();
	target = target_;
	if(!glXMakeCurrent(data->display,data->pbuffer,data->context)) {
		fprintf(stderr,"PBuffer::enable(): glXMakeCurrent() failed\n");
	}
}

/*
 */
void PBuffer::disable() {
	if(target) {
		target->bind();
		target->copy();
	}
	if(!glXMakeCurrent(data->display,data->old_pbuffer,data->old_context)) {
		fprintf(stderr,"PBuffer::disable(): glXMakeCurrent() failed\n");
	}
}

#else

/* windows
 */
#include <vector>
#include <windows.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/wglext.h>
#include "texture.h"
#include "pbuffer.h"

/*
 */
struct PBuffer_data {
	HDC hdc;
	HPBUFFERARB pbuffer;
	HGLRC context;
	
	HDC old_hdc;
	HGLRC old_context;
};

static PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB = NULL;
static PFNWGLCREATEPBUFFERARBPROC wglCreatePbufferARB = NULL;
static PFNWGLGETPBUFFERDCARBPROC wglGetPbufferDCARB = NULL;
static PFNWGLRELEASEPBUFFERDCARBPROC wglReleasePbufferDCARB = NULL;
static PFNWGLDESTROYPBUFFERARBPROC wglDestroyPbufferARB = NULL;

/*
 */
PBuffer::PBuffer(int width,int height,int flags) : width(width), height(height), flags(flags), target(NULL) {
	
	HDC old_hdc = wglGetCurrentDC();
	HGLRC old_context = wglGetCurrentContext();
	
	int bits = 8;
	if(flags & FLOAT_16) bits = 16;
	if(flags & FLOAT_32) bits = 32;
	
	std::vector<int> attrib;
	attrib.push_back(WGL_PIXEL_TYPE_ARB);
	attrib.push_back((flags & FLOAT_16) ? WGL_TYPE_RGBA_FLOAT_ATI : WGL_TYPE_RGBA_ARB);
	attrib.push_back(WGL_DRAW_TO_PBUFFER_ARB);
	attrib.push_back(true);
	attrib.push_back(WGL_SUPPORT_OPENGL_ARB);
	attrib.push_back(true);
	attrib.push_back(WGL_DOUBLE_BUFFER_ARB);
	attrib.push_back(false);
	if((flags & RGB) || (flags & RGBA)) {
		attrib.push_back(WGL_RED_BITS_ARB);
		attrib.push_back(bits);
		attrib.push_back(WGL_GREEN_BITS_ARB);
		attrib.push_back(bits);
		attrib.push_back(WGL_BLUE_BITS_ARB);
		attrib.push_back(bits);
		if(flags & RGBA) {
			attrib.push_back(WGL_ALPHA_BITS_ARB);
			attrib.push_back(bits);
		}
	}
	if(flags & DEPTH) {
		attrib.push_back(WGL_DEPTH_BITS_ARB);
		attrib.push_back(24);
	}
	if(flags & STENCIL) {
		attrib.push_back(WGL_STENCIL_BITS_ARB);
		attrib.push_back(8);
	}
	if(flags & FLOAT_32) {
		attrib.push_back(WGL_FLOAT_COMPONENTS_NV);
		attrib.push_back(true);
	}
	if((flags & MULTISAMPLE_2) || (flags & MULTISAMPLE_4)) {
		attrib.push_back(WGL_SAMPLE_BUFFERS_ARB);
		attrib.push_back(true);
		attrib.push_back(WGL_SAMPLES_ARB);
		attrib.push_back(flags & MULTISAMPLE_2 ? 2 : 4);
	}
	attrib.push_back(0);
	
	std::vector<int> pattrib;
	
	pattrib.push_back(WGL_PBUFFER_LARGEST_ARB);
	pattrib.push_back(false);
	pattrib.push_back(0);

	HDC hdc;
	HPBUFFERARB pbuffer;
	HGLRC context;
	
	try {
		
		if(!wglChoosePixelFormatARB) wglChoosePixelFormatARB = (PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");
		if(!wglChoosePixelFormatARB) throw("wglGetProcAddress(\"wglChoosePixelFormatARB\") failed");
		
		if(!wglCreatePbufferARB) wglCreatePbufferARB = (PFNWGLCREATEPBUFFERARBPROC)wglGetProcAddress("wglCreatePbufferARB");
		if(!wglCreatePbufferARB) throw("wglGetProcAddress(\"wglCreatePbufferARB\") failed");
		
		if(!wglGetPbufferDCARB) wglGetPbufferDCARB = (PFNWGLGETPBUFFERDCARBPROC)wglGetProcAddress("wglGetPbufferDCARB");
		if(!wglGetPbufferDCARB) throw("wglGetProcAddress(\"wglGetPbufferDCARB\") failed");
		
		if(!wglReleasePbufferDCARB) wglReleasePbufferDCARB = (PFNWGLRELEASEPBUFFERDCARBPROC)wglGetProcAddress("wglReleasePbufferDCARB");
		if(!wglReleasePbufferDCARB) throw("wglGetProcAddress(\"wglReleasePbufferDCARB\") failed\n");
		
		if(!wglDestroyPbufferARB) wglDestroyPbufferARB = (PFNWGLDESTROYPBUFFERARBPROC)wglGetProcAddress("wglDestroyPbufferARB");
		if(!wglDestroyPbufferARB) throw("wglGetProcAddress(\"wglDestroyPbufferARB\") failed\n");
		
		int pixelformat;
		unsigned int count;
		wglChoosePixelFormatARB(old_hdc,&attrib[0],NULL,1,&pixelformat,&count);
		if(count == 0) throw("wglChoosePixelFormatARB() failed");
		
		pbuffer = wglCreatePbufferARB(old_hdc,pixelformat,width,height,&pattrib[0]);
		if(!pbuffer) throw("wglCreatePbufferARB() failed");
		
		hdc = wglGetPbufferDCARB(pbuffer);
		if(!hdc) throw("wglGetPbufferDCARB() failed");
		
		context = wglCreateContext(hdc);
		if(!context) throw("wglCreateContext() failed");
		
		if(!wglShareLists(old_context,context)) throw("wglShareLists() failed");
	}
	catch(const char *error) {
		fprintf(stderr,"PBuffer::PBuffer(): %s\n",error);
		hdc = old_hdc;
		context = old_context;
	}
	
	data = new PBuffer_data;
	data->hdc = hdc;
	data->pbuffer = pbuffer;
	data->context = context;
	
	data->old_hdc = old_hdc;
	data->old_context = old_context;
}

/*
 */
PBuffer::~PBuffer() {
	wglDeleteContext(data->context);
	wglReleasePbufferDCARB(data->pbuffer,data->hdc);
	wglDestroyPbufferARB(data->pbuffer);
}

/*
 */
void PBuffer::enable(Texture *target_) {
	data->old_hdc = wglGetCurrentDC();
	data->old_context = wglGetCurrentContext();
	target = target_;
	if(!wglMakeCurrent(data->hdc,data->context)) {
		fprintf(stderr,"PBuffer::disable(): wglMakeCurrent() failed\n");
	}
}

/*
 */
void PBuffer::disable() {
	if(target) {
		target->bind();
		target->copy();
	}
	if(!wglMakeCurrent(data->old_hdc,data->old_context)) {
		fprintf(stderr,"PBuffer::disable(): wglMakeCurrent() failed\n");
	}
}

#endif
