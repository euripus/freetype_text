/* Graphic user interface
 *
 * Copyright (C) 2003-2005, Alexander Zaprjagaev <frustum@frustum.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "glapp.h"
#include "gui.h"

/*****************************************************************************/
/*                                                                           */
/* Gui                                                                       */
/*                                                                           */
/*****************************************************************************/

/*
 */
Gui::Gui(const char *font_,const char *path) : alpha(0.8), time(0.0), focus(NULL), grab_mouse(0) {
	
	font = new Font(font_);
	vbox = new VBox(this);
	
	load(path);
}

Gui::Gui(Font *font,const char *path) : font(font), alpha(0.8), time(0.0), focus(NULL), grab_mouse(0) {
	
	vbox = new VBox(this);
	
	load(path);
}

Gui::~Gui() {
	
	delete vbox;
	
	delete window_tex;
	
	delete button_tex;
	delete button_pressed_tex;
	
	delete checkbox_tex;
	
	delete hslider_tex;
	delete hslider_button_tex;
}

/*
 */
void Gui::load(const char *path) {
	
	char buf[1024];
	
	sprintf(buf,"%s%s",path,"window.png");
	window_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR);
	
	sprintf(buf,"%s%s",path,"window_border.png");
	window_border_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
	
	sprintf(buf,"%s%s",path,"button.png");
	button_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
	sprintf(buf,"%s%s",path,"button_pressed.png");
	button_pressed_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
	
	sprintf(buf,"%s%s",path,"checkbox.png");
	checkbox_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
	
	sprintf(buf,"%s%s",path,"hslider.png");
	hslider_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
	sprintf(buf,"%s%s",path,"hslider_button.png");
	hslider_button_tex = new Texture(buf,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
}

/*
 */
void Gui::render(int width_,int height_,int mouse_x,int mouse_y,int mouse_button_,float ifps) {
	
	width = width_;
	height = height_;
	
	mouse_dx = mouse_x - old_mouse_x;
	mouse_dy = mouse_y - old_mouse_y;
	mouse_button = mouse_button_;
	
	time += ifps;
	
	font->enable(width,height);
	
	vbox->arrange();
	vbox->expand(width,height);
	vbox->render(mouse_x,mouse_y);
	
	font->disable();
	
	glColor4f(1,1,1,1);
	
	old_mouse_x = mouse_x;
	old_mouse_y = mouse_y;
	
	if(grab_mouse && (mouse_button & GLApp::BUTTON_LEFT) == 0) {
		focus = NULL;
		grab_mouse = 0;
	}
}

/*
 */
int Gui::getActivity() {
	return focus != NULL || grab_mouse == 1;
}

/*
 */
void Gui::setAlpha(float alpha_) {
	alpha = alpha_;
}

/*
 */
void Gui::addWidget(Widget *widget,int flags) {
	vbox->addWidget(widget,flags);
}

/*
 */
void Gui::removeWidget(Widget *widget) {
	vbox->removeWidget(widget);
}

/*
 */
int Gui::isChild(Widget *widget) {
	return vbox->isChild(widget);
}

/*****************************************************************************/
/*                                                                           */
/* Widget                                                                    */
/*                                                                           */
/*****************************************************************************/

/*
 */
Widget::Widget(Gui *gui) : gui(gui), parent(NULL), pos_x(0), pos_y(0), size_x(0), size_y(0), flags(0), time(-100.0f) {
	for(int i = 0; i < Gui::NUM_CALLBACKS; i++) {
		callbacks[i].func = NULL;
		callbacks[i].data = NULL;
	}
}

Widget::~Widget() {
	if(parent) parent->removeWidget(this);
	if(gui->focus == this) {
		gui->focus = NULL;
		gui->grab_mouse = 0;
	}
}

/*
 */
void Widget::addWidget(Widget *widget,int flags) {
	fprintf(stderr,"Widget::addWidget(): can't add Widget in to non container Widget\n");
}

void Widget::removeWidget(Widget *widget) {
	
}

void Widget::raiseWidget(Widget *widget) {
	
}

int Widget::isChild(Widget *widget) {
	if(this == widget) return 1;
	return 0;
}

/*
 */
void Widget::setParent(Widget *parent_) {
	if(parent) parent->removeWidget(this);
	parent = parent_;
}

void Widget::setFlags(int flags_) {
	flags = flags_;
}

/*
 */
void Widget::addCallBack(int callback,void (*func)(Widget *widget,void*),void *data) {
	if(callback < 0 || callback >= Gui::NUM_CALLBACKS) {
		fprintf(stderr,"Widget::addCallBack(): bad callback number\n",callback);
		return;
	}
	callbacks[callback].func = func;
	callbacks[callback].data = data;
}

/*
 */
void Widget::arrange() {
	
}

void Widget::expand(int width,int height) {
	
}

void Widget::check_callbacks(int mouse_x,int mouse_y) {
	
	if((flags & Gui::ALIGN_OVERLAP) == 0) {
		pos_x = 0;
		pos_y = 0;
	}
	
	// focus in
	if(gui->focus == NULL) {
		if(mouse_x >= pos_x && mouse_y >= pos_y && mouse_x < pos_x + size_x && mouse_y < pos_y + size_y) {
			gui->focus = this;
			if((flags & Gui::ALIGN_OVERLAP) && parent) parent->raiseWidget(this);
			time = gui->time;
			if(callbacks[Gui::FOCUS_IN].func) callbacks[Gui::FOCUS_IN].func(this,callbacks[Gui::FOCUS_IN].data);
		}
	}
	// focus out
	else if(gui->focus == this && gui->grab_mouse == 0) {
		if(mouse_x < pos_x || mouse_y < pos_y || mouse_x >= pos_x + size_x || mouse_y >= pos_y + size_y) {
			gui->focus = NULL;
			time = gui->time;
			if(callbacks[Gui::FOCUS_OUT].func) callbacks[Gui::FOCUS_OUT].func(this,callbacks[Gui::FOCUS_OUT].data);
		}
	}
}

void Widget::render_quad(int x0,int y0,float tx0,float ty0,int x1,int y1,float tx1,float ty1) {
	glBegin(GL_QUADS);
	glTexCoord2f(tx0,ty0);
	glVertex2i(x0,y0);
	glTexCoord2f(tx0,ty1);
	glVertex2i(x0,y1);
	glTexCoord2f(tx1,ty1);
	glVertex2i(x1,y1);
	glTexCoord2f(tx1,ty0);
	glVertex2i(x1,y0);
	glEnd();
}

/*****************************************************************************/
/*                                                                           */
/* Window                                                                    */
/*                                                                           */
/*****************************************************************************/

/*
 */
Window::Window(Gui *gui,int pos_x_,int pos_y_) : Widget(gui) {
	vbox = new VBox(gui,0);
	pos_x = pos_x_;
	pos_y = pos_y_;
}

Window::~Window() {
	delete vbox;
}

/*
 */
void Window::addWidget(Widget *widget,int flags) {
	vbox->addWidget(widget,flags);
}

void Window::removeWidget(Widget *widget) {
	vbox->removeWidget(widget);
}

int Window::isChild(Widget *widget) {
	if(this == widget) return 1;
	return vbox->isChild(widget);
}

/*
 */
void Window::setPos(int pos_x_,int pos_y_) {
	if((flags & Gui::ALIGN_OVERLAP) == 0) {
		fprintf(stderr,"Window::setPos(): can't set position for the not overlaped window\n");
		return;
	}
	pos_x = pos_x_;
	pos_y = pos_y_;
}

/*
 */
void Window::arrange() {
	vbox->arrange();
	size_x = vbox->size_x + gui->window_border_tex->width;
	size_y = vbox->size_y + gui->window_border_tex->height;
	vbox->expand(vbox->size_x,vbox->size_y);
}

void Window::render(int mouse_x,int mouse_y) {
	
	if(pos_x < 0) pos_x = 0;
	else if(pos_x + size_x > gui->width) pos_x = gui->width - size_x;
	if(pos_y < 0) pos_y = 0;
	else if(pos_y + size_y > gui->height) pos_y = gui->height - size_y;
	
	glPushMatrix();
	glTranslatef((float)(pos_x + gui->window_border_tex->width / 2),(float)(pos_y + gui->window_border_tex->height / 2),0);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_COLOR,GL_ONE_MINUS_SRC_ALPHA);
	
	glColor4fv(vec4(1,1,1,1) * gui->alpha);
	render_window();
	
	glDisable(GL_BLEND);
	
	// window widgets
	int window_focus = (gui->focus == this && gui->grab_mouse == 0);
	if(window_focus) gui->focus = NULL;
	vbox->render(mouse_x - pos_x - gui->window_border_tex->width / 2,mouse_y - pos_y - gui->window_border_tex->height / 2);
	if(window_focus && gui->focus == NULL) gui->focus = this;
	
	glPopMatrix();
	
	if(gui->focus == this) {
		if(gui->grab_mouse == 1) {
			if((gui->mouse_button & GLApp::BUTTON_LEFT) == 0) gui->grab_mouse = 0;
		} else {
			if(gui->mouse_button & GLApp::BUTTON_LEFT) gui->grab_mouse = 1;
		}
		if(gui->grab_mouse == 0) {
			mouse_pos_x = pos_x;
			mouse_pos_y = pos_y;
		} else {
			mouse_pos_x += gui->mouse_dx;
			mouse_pos_y += gui->mouse_dy;
			pos_x = mouse_pos_x;
			pos_y = mouse_pos_y;
		}
	}
}

/*
 */
void Window::render_window() {
	
	// background
	gui->window_tex->enable();
	gui->window_tex->bind();
	
	render_quad(0,0,0,0,
		size_x - gui->window_border_tex->width,size_y - gui->window_border_tex->height,
		(float)(size_x - gui->window_border_tex->width) / (float)gui->window_tex->width,
		(float)(size_y - gui->window_border_tex->height) / (float)gui->window_tex->height);
	
	gui->window_tex->disable();
	
	// border
	gui->window_border_tex->enable();
	gui->window_border_tex->bind();
	
	render_quad(-gui->window_border_tex->width / 2,-gui->window_border_tex->width / 2,0,0,0,0,0.5,0.5);
	render_quad(0,-gui->window_border_tex->width / 2,0.5,0,size_x - gui->window_border_tex->width,0,0.5,0.5);
	render_quad(size_x - gui->window_border_tex->width,-gui->window_border_tex->width / 2,0.5,0,size_x - gui->window_border_tex->width / 2,0,1.0,0.5);
	
	render_quad(-gui->window_border_tex->width / 2,0,0,0.5,0,size_y - gui->window_border_tex->height,0.5,0.5);
	render_quad(size_x - gui->window_border_tex->width,0,0.5,0.5,size_x - gui->window_border_tex->width / 2,size_y - gui->window_border_tex->height,1.0,0.5);
	
	render_quad(-gui->window_border_tex->width / 2,size_y - gui->window_border_tex->height,0,0.5,0,size_y - gui->window_border_tex->height / 2,0.5,1.0);
	render_quad(0,size_y - gui->window_border_tex->width,0.5,0.5,size_x - gui->window_border_tex->width,size_y - gui->window_border_tex->height / 2,0.5,1.0);
	render_quad(size_x - gui->window_border_tex->width,size_y - gui->window_border_tex->width,0.5,0.5,size_x - gui->window_border_tex->width / 2,size_y - gui->window_border_tex->width / 2,1.0,1.0);
	
	gui->window_border_tex->disable();
}

/*****************************************************************************/
/*                                                                           */
/* VBox                                                                      */
/*                                                                           */
/*****************************************************************************/

/*
 */
VBox::VBox(Gui *gui,int border_x,int border_y) : Widget(gui), border_x(border_x), border_y(border_y) {
	
}

VBox::~VBox() {
	// don't use ->setParent(NULL)
	for(int i = 0; i < (int)widgets.size(); i++) {
		widgets[i]->parent = NULL;
	}
	if(isChild(gui->focus)) {
		gui->focus = NULL;
		gui->grab_mouse = 0;
	}
}

/*
 */
void VBox::addWidget(Widget *widget,int flags) {
	widget->setParent(this);
	if(flags != 0) widget->setFlags(flags);
	widgets.push_back(widget);
}

void VBox::removeWidget(Widget *widget) {
	for(int i = 0; i < (int)widgets.size(); i++) {
		if(widgets[i] == widget) {
			widgets.erase(widgets.begin() + i);
			break;
		} else {
			widgets[i]->removeWidget(widget);
		}
	}
	if(widget->isChild(gui->focus)) {
		gui->focus = NULL;
		gui->grab_mouse = 0;
	}
}

void VBox::raiseWidget(Widget *widget) {
	for(int i = 0; i < (int)widgets.size(); i++) {
		if(widgets[i] == widget) {
			for(int j = i; j < (int)widgets.size() - 1; j++) widgets[j] = widgets[j + 1];
			widgets[widgets.size() - 1] = widget;
			break;
		}
	}
}

int VBox::isChild(Widget *widget) {
	if(this == widget) return 1;
	for(int i = 0; i < (int)widgets.size(); i++) {
		if(widgets[i]->isChild(widget)) return 1;
	}
	return 0;
}

/*
 */
void VBox::arrange() {
	size_x = 0;
	size_y = 0;
	for(int i = 0; i < (int)widgets.size(); i++) {
		widgets[i]->arrange();
		if(widgets[i]->flags & Gui::ALIGN_OVERLAP) continue;
		if(widgets[i]->size_x > size_x) size_x = widgets[i]->size_x;
		size_y += widgets[i]->size_y;
		size_y += border_y;
	}
	size_x += border_x * 2;
	size_y += border_y;
}

void VBox::expand(int width,int height) {
	if(width >= size_x && height >= size_y) {
		int num_expands = 0;
		for(int i = 0; i < (int)widgets.size(); i++) {
			if(widgets[i]->flags & Gui::ALIGN_EXPAND) num_expands++;
		}
		for(int i = 0; i < (int)widgets.size(); i++) {
			if(widgets[i]->flags & Gui::ALIGN_EXPAND) widgets[i]->expand(width - border_x * 2,widgets[i]->size_y + (height - size_y) / num_expands - border_y * 2);
		}
	}
	if(size_x < width) size_x = width;
	if(size_y < height) size_y = height;
}

void VBox::check_callbacks(int mouse_x,int mouse_y) {

}

void VBox::render(int mouse_x,int mouse_y) {
	
	for(int i = (int)widgets.size() - 1; i >= 0; i--) {
		Widget *w = widgets[i];
		if(w->flags & Gui::ALIGN_OVERLAP) {
			w->check_callbacks(mouse_x,mouse_y);
		}
	}
	
	int dx = 0;
	int dy = border_y;
	
	for(int i = 0; i < (int)widgets.size(); i++) {
		Widget *w = widgets[i];
		
		if(w->flags & Gui::ALIGN_OVERLAP) {
			w->render(mouse_x,mouse_y);
		}
		else {
			if(w->flags & Gui::ALIGN_LEFT) dx = border_x;
			else if(w->flags & Gui::ALIGN_RIGHT) dx = size_x - w->size_x - border_x;
			else dx = (size_x - w->size_x) / 2;
			
			if(w->flags & Gui::ALIGN_BOTTOM) {
				int height = 0;
				for(int j = i; j < (int)widgets.size(); j++) {
					if(widgets[j]->flags & Gui::ALIGN_OVERLAP) continue;
					height += widgets[j]->size_y + border_y;
				}
				dy = size_y - height;
			}
			
			w->check_callbacks(mouse_x - dx,mouse_y - dy);
			
			glPushMatrix();
			glTranslatef((float)dx,(float)dy,0);
			w->render(mouse_x - dx,mouse_y - dy);
			glPopMatrix();
			
			dy += w->size_y + border_y;
		}
	}
}

/*****************************************************************************/
/*                                                                           */
/* HBox                                                                      */
/*                                                                           */
/*****************************************************************************/

/*
 */
HBox::HBox(Gui *gui,int border_x,int border_y) : Widget(gui), border_x(border_x), border_y(border_y) {
	
}

HBox::~HBox() {
	for(int i = 0; i < (int)widgets.size(); i++) {
		widgets[i]->parent = NULL;
	}
	if(isChild(gui->focus)) {
		gui->focus = NULL;
		gui->grab_mouse = 0;
	}
}

/*
 */
void HBox::addWidget(Widget *widget,int flags) {
	widget->setParent(this);
	if(flags != 0) widget->setFlags(flags);
	widgets.push_back(widget);
}

void HBox::removeWidget(Widget *widget) {
	for(int i = 0; i < (int)widgets.size(); i++) {
		if(widgets[i] == widget) {
			widgets.erase(widgets.begin() + i);
			break;
		} else {
			widgets[i]->removeWidget(widget);
		}
	}
	if(widget->isChild(gui->focus)) {
		gui->focus = NULL;
		gui->grab_mouse = 0;
	}
}

void HBox::raiseWidget(Widget *widget) {
	for(int i = 0; i < (int)widgets.size(); i++) {
		if(widgets[i] == widget) {
			for(int j = i; j < (int)widgets.size() - 1; j++) widgets[j] = widgets[j + 1];
			widgets[widgets.size() - 1] = widget;
			break;
		}
	}
}

int HBox::isChild(Widget *widget) {
	if(this == widget) return 1;
	for(int i = 0; i < (int)widgets.size(); i++) {
		if(widgets[i]->isChild(widget)) return 1;
	}
	return 0;
}

/*
 */
void HBox::arrange() {
	size_x = 0;
	size_y = 0;
	for(int i = 0; i < (int)widgets.size(); i++) {
		widgets[i]->arrange();
		if(widgets[i]->flags & Gui::ALIGN_OVERLAP) continue;
		size_x += widgets[i]->size_x;
		size_x += border_x;
		if(widgets[i]->size_y > size_y) size_y = widgets[i]->size_y;
	}
	size_x += border_x;
	size_y += border_y * 2;
}

void HBox::expand(int width,int height) {
	if(width >= size_x && height >= size_y) {
		int num_expands = 0;
		for(int i = 0; i < (int)widgets.size(); i++) {
			if(widgets[i]->flags & Gui::ALIGN_EXPAND) num_expands++;
		}
		for(int i = 0; i < (int)widgets.size(); i++) {
			if(widgets[i]->flags & Gui::ALIGN_EXPAND) widgets[i]->expand(widgets[i]->size_x + (width - size_x) / num_expands - border_x * 2,height - border_y * 2);
		}
	}
	if(size_x < width) size_x = width;
	if(size_y < height) size_y = height;
}

void HBox::check_callbacks(int mouse_x,int mouse_y) {

}

void HBox::render(int mouse_x,int mouse_y) {
	
	for(int i = (int)widgets.size() - 1; i >= 0; i--) {
		Widget *w = widgets[i];
		if(w->flags & Gui::ALIGN_OVERLAP) {
			w->check_callbacks(mouse_x,mouse_y);
		}
	}
	
	int dx = border_x;
	int dy = 0;
	
	for(int i = 0; i < (int)widgets.size(); i++) {
		Widget *w = widgets[i];
		
		if(w->flags & Gui::ALIGN_OVERLAP) {
			w->render(mouse_x,mouse_y);
		}
		else {
			
			if(w->flags & Gui::ALIGN_TOP) dy = border_y;
			else if(w->flags & Gui::ALIGN_BOTTOM) dy = size_y - w->size_y - border_y;
			else dy = (size_y - w->size_y) / 2;
			
			if(w->flags & Gui::ALIGN_RIGHT) {
				int width = 0;
				for(int j = i; j < (int)widgets.size(); j++) {
					if(widgets[j]->flags & Gui::ALIGN_OVERLAP) continue;
					width += widgets[j]->size_x + border_x;
				}
				dx = size_x - width;
			}
			
			w->check_callbacks(mouse_x - dx,mouse_y - dy);
			
			glPushMatrix();
			glTranslatef((float)dx,(float)dy,0);
			w->render(mouse_x - dx,mouse_y - dy);
			glPopMatrix();
			
			dx += w->size_x + border_x;
		}
	}
}

/*****************************************************************************/
/*                                                                           */
/* Sprite                                                                    */
/*                                                                           */
/*****************************************************************************/

/*
 */
Sprite::Sprite(Gui *gui,const char *name,int pos_x_,int pos_y_,float scale_x,float scale_y) : Widget(gui), scale_x(scale_x), scale_y(scale_y), angle(0.0) {
	pos_x = pos_x_;
	pos_y = pos_y_;
	color = vec3(1,1,1);
	texture = new Texture(name,Texture::TEXTURE_2D,Texture::RGBA | Texture::LINEAR_MIPMAP_LINEAR | Texture::CLAMP_TO_EDGE);
}

Sprite::~Sprite() {
	delete texture;
}

/*
 */
void Sprite::setPos(int pos_x_,int pos_y_) {
	if((flags & Gui::ALIGN_OVERLAP) == 0) {
		fprintf(stderr,"Sprite::setPos(): can't set position for the not overlaped sprite\n");
		return;
	}
	pos_x = pos_x_;
	pos_y = pos_y_;
}

void Sprite::setScale(float scale_x_,float scale_y_) {
	scale_x = scale_x_;
	scale_y = scale_y_;
}

void Sprite::setRotation(float angle_) {
	angle = angle_;
}

void Sprite::setColor(const vec3 &color_) {
	color = color_;
}

/*
 */
void Sprite::arrange() {
	size_x = (int)((float)texture->width * scale_x);
	size_y = (int)((float)texture->height * scale_y);
}

void Sprite::check_callbacks(int mouse_x,int mouse_y) {

}

void Sprite::render(int mouse_x,int mouse_y) {
	
	if(gui->focus == this) {
		if(gui->grab_mouse == 1) {
			if((gui->mouse_button & GLApp::BUTTON_LEFT) == 0) gui->grab_mouse = 0;
		} else {
			if(gui->mouse_button & GLApp::BUTTON_LEFT) gui->grab_mouse = 1;
		}
	}
	
	glPushMatrix();
	glTranslatef((float)pos_x,(float)pos_y,0);
	glScalef(scale_x,scale_y,1.0f);
	glRotatef(angle,0,0,1);
	glTranslatef(-(float)texture->width / 2.0f,-(float)texture->height / 2.0f,0);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_COLOR,GL_ONE_MINUS_SRC_ALPHA);
	
	texture->enable();
	texture->bind();
	glColor4fv(vec4(color * gui->alpha,gui->alpha));
	render_quad(0,0,0,0,texture->width,texture->height,1,1);
	texture->disable();
	
	glDisable(GL_BLEND);
	
	glPopMatrix();
}

/*****************************************************************************/
/*                                                                           */
/* Label                                                                     */
/*                                                                           */
/*****************************************************************************/

/*
 */
Label::Label(Gui *gui,const char *str,const vec3 &color) : Widget(gui), color(color), size(0) {
	strncpy(text,str,sizeof(text));
}

Label::~Label() {
	
}

/*
 */
void Label::setColor(const vec3 &color_) {
	color = color_;
}

void Label::setSize(int size_) {
	size = size_;
}

void Label::setText(const char *str) {
	strncpy(text,str,sizeof(text));
}

void Label::printf(const char *format,...) {
	va_list argptr;
	va_start(argptr,format);
	vsprintf(text,format,argptr);
	va_end(argptr);
}

/*
 */
void Label::arrange() {
	gui->font->getSize(size,text,size_x,size_y);
}

void Label::check_callbacks(int mouse_x,int mouse_y) {

}

void Label::render(int mouse_x,int mouse_y) {
	
	if(gui->focus == this) {
		if(gui->grab_mouse == 1) {
			if((gui->mouse_button & GLApp::BUTTON_LEFT) == 0) gui->grab_mouse = 0;
		} else {
			if(gui->mouse_button & GLApp::BUTTON_LEFT) gui->grab_mouse = 1;
		}
	}
	
	glColor4fv(vec4(color * gui->alpha,gui->alpha));
	gui->font->puts(0,0,size,text);
}

/*****************************************************************************/
/*                                                                           */
/* Button                                                                    */
/*                                                                           */
/*****************************************************************************/

/*
 */
Button::Button(Gui *gui,const char *str,const vec3 &color,int toggle) : Widget(gui), color(color), size(0), toggle(toggle), pressed(0) {
	strncpy(text,str,sizeof(text));
}

Button::~Button() {

}

/*
 */
int Button::getPressed() {
	return pressed > 0;
}

void Button::setColor(const vec3 &color_) {
	color = color_;
}

void Button::setSize(int size_) {
	size = size_;
}

void Button::setText(const char *str) {
	strncpy(text,str,sizeof(text));
}

void Button::printf(const char *format,...) {
	va_list argptr;
	va_start(argptr,format);
	vsprintf(text,format,argptr);
	va_end(argptr);
}

/*
 */
void Button::arrange() {
	gui->font->getSize(size,text,size_x,size_y);
	if(size_x < gui->button_tex->width * 3 / 4) size_x = gui->button_tex->width * 3 / 4;
	else size_x = size_x * 4 / 3;
	if(size_y < gui->button_tex->height * 3 / 4) size_y = gui->button_tex->height * 3 / 4;
	else size_y = size_y * 4 / 3;
}

void Button::render(int mouse_x,int mouse_y) {
	
	if(gui->focus == this) {
		if(gui->grab_mouse == 1) {
			if((gui->mouse_button & GLApp::BUTTON_LEFT) == 0) {
				// toggle button
				if(toggle) {
					if(pressed == 2) {
						pressed = 1;
					} else if(pressed == -1) {
						pressed = 0;
					}
				}
				// push button
				else {
					pressed = 0;
				}
				gui->grab_mouse = 0;
			}
		} else {
			if(gui->mouse_button & GLApp::BUTTON_LEFT) {
				// toggle button
				if(toggle) {
					if(pressed == 0) {
						pressed = 2;
						if(callbacks[Gui::CLICKED].func) callbacks[Gui::CLICKED].func(this,callbacks[Gui::CLICKED].data);
						if(callbacks[Gui::ACTIVATED].func) callbacks[Gui::ACTIVATED].func(this,callbacks[Gui::ACTIVATED].data);
					} else if(pressed == 1) {
						pressed = -1;
						if(callbacks[Gui::CLICKED].func) callbacks[Gui::CLICKED].func(this,callbacks[Gui::CLICKED].data);
						if(callbacks[Gui::DEACTIVATED].func) callbacks[Gui::DEACTIVATED].func(this,callbacks[Gui::DEACTIVATED].data);
					}
				}
				// push button
				else {
					pressed = 1;
					if(callbacks[Gui::CLICKED].func) callbacks[Gui::CLICKED].func(this,callbacks[Gui::CLICKED].data);
				}
				gui->grab_mouse = 1;
			}
		}
	}
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
	
	glPushMatrix();
	
	if(gui->focus == this) glTranslatef(0,-4,0);
	
	if(pressed > 0) {
		
		gui->button_pressed_tex->enable();
		gui->button_pressed_tex->bind();
		glColor4fv(vec4(1,1,1,1) * gui->alpha);
		render_button();
		gui->button_pressed_tex->disable();
		
		if(toggle) glTranslatef(0,2,0);
		
		int x,y;
		gui->font->getSize(size,text,x,y);
		glColor4fv(vec4(color * gui->alpha * 0.5f,gui->alpha));
		gui->font->puts((size_x - x) / 2,(size_y - y) / 2 + 2,size,text);
		
	} else {
		
		gui->button_tex->enable();
		gui->button_tex->bind();
		glColor4fv(vec4(1,1,1,1) * gui->alpha);
		render_button();
		
		glBlendFunc(GL_ONE,GL_ONE);
		if(gui->focus == this) {
			float k = (gui->time - time) * GUI_FADE_IN_SPEED;
			if(k > 0.5f) k = 0.5f;
			glColor4fv(vec4(1,1,1,1) * k);
		} else {
			float k = 0.5f - (gui->time - time) * GUI_FADE_OUT_SPEED;
			if(k < 0.0) k = 0.0;
			glColor4fv(vec4(1,1,1,1) * k);
		}
		render_button();
		
		gui->button_tex->disable();
		
		int x,y;
		gui->font->getSize(size,text,x,y);
		glColor4fv(vec4(color * gui->alpha,gui->alpha));
		gui->font->puts((size_x - x) / 2,(size_y - y) / 2,size,text);
	}
	
	glPopMatrix();
	
	glDisable(GL_BLEND);
}

/*
 */
void Button::render_button() {
	if(size_x > gui->button_tex->width && size_x > size_y) {
		render_quad(0,0,0,0,size_y,size_y,0.5,1);
		render_quad(size_y,0,0.5,0,size_x - size_y,size_y,0.5,1);
		render_quad(size_x - size_y,0,0.5,0,size_x,size_y,1,1);
	} else {
		render_quad(0,0,0,0,size_x,size_y,1,1);
	}
}

/*****************************************************************************/
/*                                                                           */
/* CheckBox                                                                  */
/*                                                                           */
/*****************************************************************************/

/*
 */
CheckBox::CheckBox(Gui *gui,const char *str,const vec3 &color) : Widget(gui), color(color), size(0), checked(0) {
	strncpy(text,str,sizeof(text));
}

CheckBox::~CheckBox() {
	// remove item from radio buttons
	for(int i = 0; i < (int)checkboxes.size(); i++) {
		CheckBox *cb = checkboxes[i];
		for(int j = 0; j < (int)cb->checkboxes.size(); j++) {
			if(cb->checkboxes[j] == this) {
				cb->checkboxes.erase(cb->checkboxes.begin() + j);
				break;
			}
		}
	}
}

/*
 */
int CheckBox::getChecked() {
	return checked;
}

/*
 */
void CheckBox::setColor(const vec3 &color_) {
	color = color_;
}

void CheckBox::setSize(int size_) {
	size = size_;
}

void CheckBox::setText(const char *str) {
	strncpy(text,str,sizeof(text));
}

void CheckBox::printf(const char *format,...) {
	va_list argptr;
	va_start(argptr,format);
	vsprintf(text,format,argptr);
	va_end(argptr);
}


void CheckBox::setChecked(int check) {
	// radio buttons
	if(checkboxes.size() > 0) {
		if(check) {
			if(checked == 0) {
				checked = 1;
				for(int i = 0; i < (int)checkboxes.size(); i++) checkboxes[i]->setChecked(0);
				if(callbacks[Gui::CHANGED].func) callbacks[Gui::CHANGED].func(this,callbacks[Gui::CHANGED].data);
				if(callbacks[Gui::ACTIVATED].func) callbacks[Gui::ACTIVATED].func(this,callbacks[Gui::ACTIVATED].data);
			}
		} else {
			if(checked == 1) {
				checked = 0;
				if(callbacks[Gui::CHANGED].func) callbacks[Gui::CHANGED].func(this,callbacks[Gui::CHANGED].data);
				if(callbacks[Gui::DEACTIVATED].func) callbacks[Gui::DEACTIVATED].func(this,callbacks[Gui::DEACTIVATED].data);
			}
		}
	}
	// check box
	else {
		checked = check;
		if(callbacks[Gui::CHANGED].func) callbacks[Gui::CHANGED].func(this,callbacks[Gui::CHANGED].data);
		if(check) {
			if(callbacks[Gui::ACTIVATED].func) callbacks[Gui::ACTIVATED].func(this,callbacks[Gui::ACTIVATED].data);
		} else {
			if(callbacks[Gui::DEACTIVATED].func) callbacks[Gui::DEACTIVATED].func(this,callbacks[Gui::DEACTIVATED].data);
		}
	}
}

void CheckBox::attachCheckBox(CheckBox *cb) {
	for(int i = 0; i < (int)checkboxes.size(); i++) {
		if(checkboxes[i] == cb) {
			fprintf(stderr,"CheckBox::attachCheckBox(): already attached\n");
			return;
		}
	}
	// create new list of radio boxes
	for(int i = 0; i < (int)cb->checkboxes.size(); i++) {
		int j = 0;
		for(; j < (int)checkboxes.size(); j++) {
			if(cb->checkboxes[i] == checkboxes[j]) break;
		}
		if(j == (int)checkboxes.size()) checkboxes.push_back(cb->checkboxes[i]);
	}
	checkboxes.push_back(cb);
	// update old radio box lists
	for(int i = 0; i < (int)checkboxes.size(); i++) {
		CheckBox *cb = checkboxes[i];
		cb->checkboxes.clear();
		for(int j = 0; j < (int)checkboxes.size(); j++) {
			if(cb != checkboxes[j]) cb->checkboxes.push_back(checkboxes[j]);
		}
		cb->checkboxes.push_back(this);
	}
}

/*
 */
void CheckBox::arrange() {
	gui->font->getSize(size,text,size_x,size_y);
	size_x += gui->checkbox_tex->width * 2 / 3;
	if(size_y < gui->checkbox_tex->height / 2) size_y = gui->checkbox_tex->height / 2;
}

void CheckBox::render(int mouse_x,int mouse_y) {
	
	if(gui->focus == this) {
		if(gui->grab_mouse == 1) {
			if((gui->mouse_button & GLApp::BUTTON_LEFT) == 0) gui->grab_mouse = 0;
		} else {
			if(gui->mouse_button & GLApp::BUTTON_LEFT) {
				if(checkboxes.size() > 0) setChecked(1);
				else setChecked(!checked);
				gui->grab_mouse = 1;
			}
		}
	}
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
	
	gui->checkbox_tex->enable();
	gui->checkbox_tex->bind();
	// radio button
	if(checkboxes.size() > 0) {
		glColor4fv(vec4(1,1,1,1) * gui->alpha);
		if(checked) render_quad(0,0,0.5,0.5,gui->checkbox_tex->width / 2,gui->checkbox_tex->height / 2,1.0,1.0);
		else render_quad(0,0,0.5,0,gui->checkbox_tex->width / 2,gui->checkbox_tex->height / 2,1.0,0.5);
	}
	// check box
	else {
		glColor4fv(vec4(1,1,1,1) * gui->alpha);
		if(checked) render_quad(0,0,0,0.5,gui->checkbox_tex->width / 2,gui->checkbox_tex->height / 2,0.5,1.0);
		else render_quad(0,0,0,0,gui->checkbox_tex->width / 2,gui->checkbox_tex->height / 2,0.5,0.5);
	}
	gui->checkbox_tex->disable();
	
	glColor4fv(vec4(color * gui->alpha,gui->alpha));
	gui->font->puts(gui->checkbox_tex->width * 2 / 3,0,size,text);
	
	glDisable(GL_BLEND);
}

/*****************************************************************************/
/*                                                                           */
/* HSlider                                                                   */
/*                                                                           */
/*****************************************************************************/

/*
 */
HSlider::HSlider(Gui *gui,float min_value,float max_value,float value) : Widget(gui), min_value(min_value), max_value(max_value), value(value), extern_float(NULL), label(NULL) {
	width = gui->hslider_tex->width;
	memset(format,0,sizeof(format));
}

HSlider::~HSlider() {

}

/*
 */
float HSlider::getValue() {
	return value;
}

void HSlider::setValue(float value_) {
	if(value_ > max_value) value = max_value;
	else if(value_ < min_value) value = min_value;
	else value = value_;
	if(label) label->printf(format,value);
}

void HSlider::setWidth(int width_) {
	width = width_;
}

void HSlider::attachFloat(float *extern_float_) {
	extern_float = extern_float_;
	if(extern_float) *extern_float = value;
}

void HSlider::attachLabel(Label *label_,const char *format_) {
	label = label_;
	if(format_) strncpy(format,format_,sizeof(format));
	else strcpy(format,"%.1f");
	label->printf(format,value);
}

/*
 */
void HSlider::arrange() {
	size_x = width;
	size_y = gui->hslider_button_tex->height;
}

void HSlider::render(int mouse_x,int mouse_y) {
	
	int height = gui->hslider_tex->height;
	int button_width = gui->hslider_button_tex->width;
	int button_height = gui->hslider_button_tex->height;
	int x = (int)((float)(width - button_width) * (value - min_value) / (max_value - min_value));	
	
	if(gui->focus == this) {
		
		int changed = 0;
		
		if(gui->grab_mouse == 1) {
			if((gui->mouse_button & GLApp::BUTTON_LEFT) == 0) gui->grab_mouse = 0;
		} else {
			if(gui->mouse_button & GLApp::BUTTON_LEFT) {
				gui->grab_mouse = 1;
				// click on line
				if(mouse_x < x || mouse_x > x + button_width) {
					value = (float)(mouse_x - button_width / 2) / (width - button_width) * (max_value - min_value) + min_value;
					mouse_value = value;
					changed = 1;
				}
			}
		}
		
		// mouse button
		if(gui->grab_mouse == 0) {
			mouse_value = value;
		} else {
			mouse_value += (float)gui->mouse_dx / (width - button_width) * (max_value - min_value);
			value = mouse_value;
			changed = 1;
		}
		
		// mouse wheel
		if(gui->mouse_button & GLApp::BUTTON_UP) {
			value += (max_value - min_value) * 0.05f;
			changed = 1;
		}
		if(gui->mouse_button & GLApp::BUTTON_DOWN) {
			value -= (max_value - min_value) * 0.05f;
			changed = 1;
		}

		if(changed == 1) {
			if(value > max_value) value = max_value;
			else if(value < min_value) value = min_value;
			
			if(extern_float) *extern_float = value;
			if(label) label->printf(format,value);
			
			if(callbacks[Gui::CHANGED].func) callbacks[Gui::CHANGED].func(this,callbacks[Gui::CHANGED].data);
		}
	}
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
	
	// line
	glColor4fv(vec4(1,1,1,1) * gui->alpha);
	gui->hslider_tex->enable();
	gui->hslider_tex->bind();
	render_quad(0,(size_y - height) / 2,0,0,size_x,(size_y - height) / 2 + height,1,1);
	gui->hslider_tex->disable();
	
	// button
	gui->hslider_button_tex->enable();
	gui->hslider_button_tex->bind();
	glColor4fv(vec4(1,1,1,1) * gui->alpha);
	render_quad(x,(size_y - button_height) / 2,0,0,x + button_width,(size_y - button_height) / 2 + button_height,1,1);
	gui->hslider_button_tex->disable();
	
	if(gui->focus == this) {
		glBlendFunc(GL_ONE,GL_ONE);
		float k = (gui->time - time) * GUI_FADE_IN_SPEED;
		if(k > 0.5f) k = 0.5f;
		glColor4fv(vec4(1,1,1,1) * k);
		
		gui->hslider_tex->enable();
		gui->hslider_tex->bind();
		render_quad(0,(size_y - height) / 2,0,0,size_x,(size_y - height) / 2 + height,1,1);
		gui->hslider_tex->disable();
		
		gui->hslider_button_tex->enable();
		gui->hslider_button_tex->bind();
		render_quad(x,(size_y - button_height) / 2,0,0,x + button_width,(size_y - button_height) / 2 + button_height,1,1);
		gui->hslider_button_tex->disable();
	} else {
		glBlendFunc(GL_ONE,GL_ONE);
		float k = 0.5f - (gui->time - time) * GUI_FADE_OUT_SPEED;
		if(k < 0.0) k = 0.0;
		glColor4fv(vec4(1,1,1,1) * k);
		
		gui->hslider_tex->enable();
		gui->hslider_tex->bind();
		render_quad(0,(size_y - height) / 2,0,0,size_x,(size_y - height) / 2 + height,1,1);
		gui->hslider_tex->disable();
		
		gui->hslider_button_tex->enable();
		gui->hslider_button_tex->bind();
		render_quad(x,(size_y - button_height) / 2,0,0,x + button_width,(size_y - button_height) / 2 + button_height,1,1);
		gui->hslider_button_tex->disable();
	}
	
	glDisable(GL_BLEND);
}
