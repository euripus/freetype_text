# Контакты и поддержка

## Официальные контакты
- Web site: [https://libwui.org](https://libwui.org/main_ru)
- Telegram: [Official WUI channel](https://t.me/libwui)
- Email: [info@libwui.org](mailto:info@libwui.org)

## WUI поддерживается независимыми разработчиками:
### Антон Головков
- GitHub: [https://github.com/ud84](https://github.com/ud84)
- Telegram: [@udattsk](https://t.me/udattsk)
- Email: [udattsk@gmail.com](mailto:udattsk@gmail.com)

### Возможно вы?
- Напишите на [info@libwui.org](mailto:info@libwui.org) если хотите присоединиться 🤝

## Пожертвования ❤️
- Если вам понравился наш проект, будем признательны за любую посильную помощь: [https://libwui.org/donate_ru](https://libwui.org/donate_ru)
