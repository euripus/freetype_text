// TextureManager.h: interface for the CTextureManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTUREMANAGER_H__96464317_1758_4245_A2D2_1EE835A9219E__INCLUDED_)
#define AFX_TEXTUREMANAGER_H__96464317_1758_4245_A2D2_1EE835A9219E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

#include "Common.h"
#include "Material.h"

#include <GL/gl.h>
//! Texture structure entry (For texture database)
struct tTextureEntry
{
    tTexture *   m_pTexture;
    unsigned int m_iDbID;

    tTextureEntry()
    {
        m_iDbID    = 0;
        m_pTexture = NULL;
    };
};

//! Texture manager class
/*!
    Class that stores/retrieves textures by:\n\n
    Texture name\n
    Texture UID\n
    Index
*/
class CTextureManager : public CSingleton<CTextureManager>
{
public:
    CTextureManager();
    virtual ~CTextureManager();

    virtual int Parse(TiXmlNode * parent_node, char * filename = NULL);

    tTexture * GetTexture(int index, int db_index, int gl_tex_id);
    tTexture * GetTexture(char const * filename);

    bool RemoveTexture(tTexture * tex);

    int GetTextureCount();

private:
    CDoubleList<tTextureEntry *> m_lstTextureDb;   //! Textures entries list
    CDoubleList<tTexture *>      m_lstTextures;    //! Actual textures list
};

#endif   // !defined(AFX_TEXTUREMANAGER_H__96464317_1758_4245_A2D2_1EE835A9219E__INCLUDED_)
