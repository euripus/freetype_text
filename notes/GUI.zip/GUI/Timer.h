#ifndef TIMER_H
#define TIMER_H

#include "Singleton.h"

//! Timer class
/*!
    This class represents a common timer.
*/
class CTimer
{

public:
    CTimer();
    virtual ~CTimer();

private:
    __int64 m_dwFrequency;  /*!< Timer frequency */
    __int64 m_dwTimerStart; /*!<	Performance counter timer variables for start times */

    unsigned int m_uiTimerStart; /*!< Multimedia timer variables for start times */
    int          m_iPauseCount;  /*!<	How many times the timer has been paused successively */

    bool m_bUsePerformanceCounter; /*!<	Use performance counter timer or multimedia timer? */

    double m_fPauseTime;  /*!<	When the timer was paused */
    float  m_fResolution; /*!< Timer resolution */

public:
    //! Resets timer variables
    void Reset();

    //! Returns the time in milliseconds since the timer started.
    double GetTime();

    //! Returns absolute time (years, months, etc)
    double GetAbsoluteTime();

    //! Pauses the timer
    virtual void Pause();

    //! Unpauses the timer
    virtual void Unpause();
};

//! Global timer class
/*!
    This class represents a global timer.
*/
class CGlobalTimer : public CTimer,
                     public CSingleton<CGlobalTimer>
{
public:
    CGlobalTimer(){};
    virtual ~CGlobalTimer(){};
};

#endif   // ndef TIMER_H
