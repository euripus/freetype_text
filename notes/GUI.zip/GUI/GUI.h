#include <windows.h>    // Header File For Windows
#include <gl\gl.h>      // Header File For The OpenGL32 Library
#include <gl\glu.h>     // Header File For The GLu32 Library
#include <gl\glaux.h>   // Header File For The Glaux Library

#pragma warning(disable:4244)

#include "MaterialManager.h"
#include "TextureManager.h"
#include "Timer.h"
#include "FontEngine.h"
#include "AnimatedTexture.h"
#include "Common.h"

#include <string>
using namespace std;

class CGUIElement;

#define DEFAULT_BORDER_WIDTH   4   // Default border width
#define DEFAULT_BORDER_SPACING 1   // Spacing distance between border and it's parent element

#define DEFAULT_TITLEBAR_HEIGHT  10
#define DEFAULT_STATUSBAR_HEIGHT 8

#define TITLEBAR_BTN_SPACING 1

#define DEFAULT_PROGRESSBAR_SPACINGX 3
#define DEFAULT_PROGRESSBAR_SPACINGY 3

#define MINIMUM_WIDTH  16   // Minimum width for element rectangle
#define MINIMUM_HEIGHT 16   // Minimum height for element rectangle

// Border elements IDs - CONSTANTS
#define BORDER_ELEMENT_TOPLEFT     25
#define BORDER_ELEMENT_TOP         26
#define BORDER_ELEMENT_TOPRIGHT    27
#define BORDER_ELEMENT_RIGHT       28
#define BORDER_ELEMENT_BOTTOMRIGHT 29
#define BORDER_ELEMENT_BOTTOM      30
#define BORDER_ELEMENT_BOTTOMLEFT  31
#define BORDER_ELEMENT_LEFT        32

//....
//....

#define PROGRESSBAR_ELMNT_POSITIVE 36
#define PROGRESSBAR_ELMNT_NEGATIVE 37

//....
//....

#define SCROLLBAR_BTN_DRAG 53
#define SCROLLBAR_BTN_DEC  54
#define SCROLLBAR_BTN_INC  55

// An element ID value
#define WINDOW_CLOSE_BTN  70
#define WINDOW_RESIZE_BTN 71
#define WINDOW_MIN_BTN    72

#define WINDOW_STATUS_FULL      102 /*!< Full size */
#define WINDOW_STATUS_NOTFULL   103 /*!< Not full size */
#define WINDOW_STATUS_MINIMIZED 104 /*!< Minimized */

// Space between rectangle and its inside text
#define GUI_STATIC_SPACINGX 2
#define GUI_STATIC_SPACINGY 2

#define MENU_MAX_SUBS 32

//! Control Type Enum
/*!
    This enum holds values for different control types.
*/
enum eControlType
{
    Simple = 1,            /*!< Simple element (by default) */
    Border,                /*!< Border element */
    Static,                /*!< Static Control */
    TextBox,               /*!< TextBox Control */
    Button,                /*!< Button Control */
    RadioGroup,            /*!< RadioGroup Control */
    DropList,              /*!< Droplist Control */
    ListBox,               /*!< Listbox Control */
    HorizontalScrollBar,   /*!< Horizontal Scrollbar Control */
    VerticalScrollBar,     /*!< Vertical Scrollbar Control */
    HorizontalProgressBar, /*!< Horizontal Progressbar Control */
    VerticalProgressBar,   /*!< Vertical Progressbar Control */
    WindowTitleBar,        /*!< Window Title Bar Element */
    WindowStatusBar,       /*!< Window Status Bar Element */
    Window,                /*!< Window Control */
    TabControl,            /*!< Tab Control */
    TabButton,             /*!< Tab Button (switch) */
    Menu,                  /*!< Menu Control */
    // Custom ones
    Caret, /*!< TextBox Caret Element */
    GUI    /*!< GUI (Root) Element */
};

//! Message Enum
/*!
    This enum holds values for different messages.
*/
enum eMessage
{

    MouseMove = 0, /*!< Mouse is moving (obsolete) */
    MouseOver,     /*!<  Mouse over the element' rectangle */
    MouseOut,      /*!< Mouse is out of the element (partially obsolete) */
    LMouseDown,    /*!< Left mouse button is down in element' rectangle */
    RMouseDown,    /*!< Right mouse button is down in element' rectangle */
    LMouseUp,      /*!< Left mouse button is up in element' rectangle */
    RMouseUp,      /*!< Right mouse button is up in element' rectangle */
    KeyDown,       /*!< Key is down (obsolete) */
    KeyUp,         /*!< Key is up (obsolete) */
    KeyPress,      /*!< Key is presses (obsolete) - up and then down */
    AquireFocus,   /*!< Element has aquired focus */
    LostFocus,     /*!< Element has lost focus (obsolete) */
    SizeX,         /*!< Element is resized on X units only */
    SizeY,         /*!< Element is resized on Y units only */
    SizeXY,        /*!< Element is resized on X AND Y units */
    MoveX,         /*!< Element is moved X units only */
    MoveY,         /*!< Element is moved Y units only */
    MoveXY,        /*!< Element is moved X AND Y units */
    Visible,       /*!< Element' visibility has changed (visible) */
    Hidden,        /*!< Element' visibility has changed (invlsible) */
    // Custom ones
    ButtonPressed, /*!< Button has been pressed (mouseDown and mouseUp) */
    Scrolled,      /*!< Scrollbar Thumb button has been moved */
    Progressed,    /*!< Progressbar value has changed */
    TextChanged,   /*!< Text has been changed */
    DeleteMe,      /*!< Notifies that the element must be deleted */
    AppResize      /*!< Notifies that the application window has been resized */

};

//! Textbox Enum
/*!
    This enum holds values for different types of textbox entry data.
*/
enum eTextBoxMode
{
    None,         /*!< No specific mode */
    PasswordMode, /*!<Password mode */
    NumberMode    /*!< Numbers only mode */
};

//! Flags Enum
/*!
    This enum holds values for different control states.
*/
enum eFlags
{
    Default       = 250, /*!< Default value for flag */
    RestrictSizeX = 251, /*!< Control cannot be resized on X axis */
    RestrictSizeY = 252, /*!< Control cannot be resized in Y axis */
    RestrictMoveX = 253, /*!< Control cannot be moved on X axis */
    RestrictMoveY = 254, /*!< Control cannot be moved on Y axis */
    Menu_ExpandPosX,     /*!< Menu is to be expanded in positive X direction */
    Menu_ExpandNegX,     /*!< Menu is to be expanded in negative X direction */
    Menu_ExpandPosY,     /*!< Menu is to be expanded in positive Y direction */
    Menu_ExpandNegY      /*!< Menu is to be expanded in negative Y direction */
};

//! Flag Structure
/*!
    This enum holds 4 flags. (DWORD)
*/
struct tFlag
{
    tFlag() { Reset(); };

    virtual ~tFlag(){};

    union
    {
        struct
        {
            unsigned int m_iFlag0; /*!< Flag 0 */
            unsigned int m_iFlag1; /*!< Flag 1 */
            unsigned int m_iFlag2; /*!< Flag 2 */
            unsigned int m_iFlag3; /*!< Flag 3 */
        };

        unsigned int m_iFlags[4]; /*!< An array holding values for 4 flags (by index) */
        DWORD        m_dwFlags;   /*!< An array holding values for 4 flags (DWORD) */
    };

    /*!
        Resets flag values to Default.
    */
    __inline void Reset() { m_iFlag0 = m_iFlag1 = m_iFlag2 = m_iFlag3 = Default; };
};

//! Vertex structure (integer based)
/*!
    This structure holds 2 integer values for 2D vertex.
*/
struct tVERTEX2d
{
    tVERTEX2d(int x = 0, int y = 0) : x(x), y(y){};
    int x; /*!< X value */
    int y; /*!< Y value */
};

//! Vertex structure (float based)
/*!
    This structure holds 2 float values for 2D vertex.
*/
struct tVERTEX2f
{
    tVERTEX2f(float x = 0, float y = 0) : x(x), y(y){};
    float x; /*!< X value */
    float y; /*!< Y value */
};

//! Button animation structure
/*!
    This structure holds data for button animation - \n
    Animation\n
    AND\n
    Event when it should be activated upon.
*/
struct tButtonAnimation
{
    CAnimatedTexture m_Animation;  /*!< Reference to animation data */
    int              m_iEventType; /*!< Triggers this animation on certain event */
};

//! Button State structure
/*!
    This structure holds a list of events.\n\n

// There are N states for button\n
// Each state has a M events (e.g MOUSEOVER, MOUSEDOWN, KEYDOWN etc)\n

// m_pState[0] - DISABLED State\n

// Button wasn't pressed\n
// m_pState[1] - NORMAL State\n
// m_pState[2] - MOUSEOVER State\n
// m_pState[3] - MOUSEDOWN State\n

// Button was pressed once (1)\n
// m_pState[4] - NORMAL State\n
// m_pState[5] - MOUSEOVER State\n
// m_pState[6] - MOUSEDOWN State\n
*/
struct tButtonState
{
    CDoubleList<tButtonAnimation *> m_lstEvents; /*!< List of events for this state */

    tButtonState(){};

    virtual ~tButtonState() { m_lstEvents.erase(); };
};

//! Message structure
/*!
    This structure attributes necessary to convey\n
    important data along with the message.
*/
struct tMessage
{
    eMessage      m_eMsg;         /*!< Actual message */
    CGUIElement * m_pSender;      /*!< Who sent the message */
    CGUIElement * m_pReceiver;    /*!< Who receives message */
    DWORD         m_dwParam[2];   /*!< Various data passed using those */
    double        m_dwCreateTime; /*!< Time of creation of this message */
    double        m_dwTimeout;    /*!< How long this message exists in a queue */
};

//! GUI Event Handler class
/*!
    This structure manages all messages that are sent.\n
    It stores them and checks for their expirity.
*/
class CGUIEventHandler
{
public:
    CGUIEventHandler();
    virtual ~CGUIEventHandler();

    //! Posts message into this event handler with passed parameters
    /*! \param sender Who sent the message
        \param receiver Who receives it (NULL if for everybody)
        \param msg Message to be sent
        \param lParam additional parameter
        \param wParam additional parameter
        \param Timeout Time (msecs) until messages expires
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int PostMessage(CGUIElement * sender, CGUIElement * receiver, eMessage msg, DWORD lParam = 0,
                            DWORD wParam = 0, int Timeout = 0);
    //! Dispatches messages which' timeout has been reached
    void Dispatch();

    //! Next Message
    /*! \param prev pointer to previous message (NULL to return first message)
        \return Next message after given pointer
    */
    tMessage * GetNextMsg(tMessage * prev = NULL);
    //! Removes passed pointed message
    /*! \param msg removes this message
     */
    void RemoveMessage(tMessage * msg);

    //! Removes references from messages to
    /*! \param element - element specified
     */
    void RemoveReferences(CGUIElement * element);

    //! Removes messages who's timeout is reached
    virtual void Flush();
    //! Removes ALL messages
    virtual void Erase();

private:
    CDoubleList<tMessage *> m_lstMessages; /*!< A list of messages */
};

//! Main GUI class
/*!
    This class holds all GUIs that are loaded/parsed,\n
    passes mouse/keyboard events to them\n
    and renders elements.
*/
class CGUI : public CSingleton<CGUI>
{
public:
    CGUI();
    virtual ~CGUI();

    //! Drawing function
    virtual void OnDraw();
    //! Parsing function
    /*! \param this_node XML node with data for this GUI
        \param filename XML file with data for this GUI
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");

    //! Saves this GUI to XML node/file
    /*! \param filename - XML file name and path with data for this GUI
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(string filename);

    //! Destruction function
    virtual void OnDestroy();
    //! Returns GUI by index
    /*! \param index index of GUI to be returned
     */
    CGUIElement * GetGUI(int index = -1);
    //! Sets current active GUI by index
    /*! \param index index of GUI to be set active
     */
    void SetGUI(unsigned int index);
    //! Returns element by his XML node (recursive!)
    /*! \param node The XML node for the child to contain
        \return Node that contains the passed XML node
    */

    virtual void ProcessMessages();

    CGUIElement * GetElementByXML(TiXmlNode * node);

private:
    CDoubleList<CGUIElement *> m_lstGUI;   /*!< List of GUIs (elements in CGUIElement?) */
    CGUIElement *              m_pDesktop; /*!< Current active GUI that takes whole screen (maybe more) */
    string                     m_TexturesDb, m_MaterialsDb;
    TiXmlNode *                m_pXMLNode;
};

//! GUI Utility class
/*!
    This class tracks and passes keyboard/mouse messages.
*/
class CGUIUtility : public CSingleton<CGUIUtility>   // Only one must exist!
{
public:
    CGUIUtility();
    virtual ~CGUIUtility();

    //! Mouse movement handlnig function
    virtual int OnMouseMove(int x, int y);
    //! Left mouse button (down) handling function
    virtual int OnLMouseDown(int x, int y);
    //! Left mouse button (up) handlnig function
    virtual int OnLMouseUp(int x, int y);
    //! Right mouse button (down) handlnig function
    virtual int OnRMouseDown(int x, int y);
    //! Right mouse button (up) handlnig function
    virtual int OnRMouseUp(int x, int y);
    //! Keyboard handling function
    virtual int OnKeyDown(int CharCode);
    //! Keyboard handling function
    virtual int OnKeyUp(int CharCode);
    //! Returns current mouse position
    tVERTEX2d GetMousePos();
    //! Return previous mouse position
    tVERTEX2d GetPrevMousePos();
    //! Returns last position where mouse was down (left button)
    tVERTEX2d GetLMouseDown();
    //! Returns last position where mouse was up (left button)
    tVERTEX2d GetLMouseUp();

    //! Returns last position where mouse was down (right button)
    tVERTEX2d GetRMouseDown();
    //! Returns last position where mouse was up (right button)
    tVERTEX2d GetRMouseUp();
    //! Returns the key state (by index)
    unsigned int GetKeyDown(unsigned int index = 0);

    //! Mouse.Flag 0 - MouseOver or not\n
    //! Mouse.Flag 1 - LMouseDown or not\n
    //! Mouse.Flag 2 - RMouseDown or not\n
    //! Mouse.Flag 3 - Reserved\n
    tFlag m_MouseMessages;       /*!< Mouse messages control structure */
    tFlag m_KeyboardMessages[2]; /*!< Shift(2), CTRL(2), ALT(2) + other flags */

    //! Returns pointer to active GUI receiving all messages (kbd, mouse)
    CGUIElement * GetActiveElement();
    //! Sets element who's to receive all messages (kbd, mouse)
    void SetActiveElement(CGUIElement * element);

private:
    tVERTEX2d m_MousePos, /*!< Current mouse position */
        m_PrevMousePos;   /*!< Previous mouse position */

    tVERTEX2d m_LMouseDown; /*!< Left mouse button down position */
    tVERTEX2d m_LMouseUp;   /*!< Left mouse button up position */

    tVERTEX2d m_RMouseDown; /*!< Right mouse button down position */
    tVERTEX2d m_RMouseUp;   /*!< Right mouse button up position */

    unsigned int m_iKeys[256]; /*!< Keyboard flags */

    CGUIElement * m_pActiveElement; /*!< Current active element */
};

//! GUI Element class
/*!
    This class represents a basic building block of GUI.
*/
class CGUIElement
{
public:
    CGUIElement();
    virtual ~CGUIElement();

    //! Aquire element' rectangle
    tRect & GetRect();
    //! Sets element' rectangle
    void SetRect(tRect & r);

    //! Drawing function for this element (recursive)
    virtual void OnDraw();
    //! Default creation function - event handler, parent and rectangle (recursive)
    /*! \param parent Parent node
        \param rect Rectangle for the element
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int OnCreate(CGUIElement * parent, tRect * rect = NULL);
    //! Parsing XML function - data aquisition
    /*! \param this_node XML node with data for this element
        \param filename XML file with data for this element
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Call this function when defining a new rectangle for the element
    /*! \param newRect New rectangle for the element
        \return SizeX on resizing along X axis only
        \return SizeY on resizing along Y axis only
        \return SizeXY on resizing along X AND Y axes
    */
    virtual int OnSize(tRect newRect);

    //! Call to destroy the element
    virtual void OnDestroy();

    //! Keyboard (KeyDown) handling function
    virtual int OnKeyDown(int KeyCode);
    //! Keyboard (KeyUp) handling function
    virtual int OnKeyUp(int KeyCode);

    //! Call this function to move element x/y units
    virtual int OnMove(int x, int y);

    //! Mouse movement handling function
    virtual int OnMouseMove(int x, int y);

    //! Left mouse button (down) handling function
    virtual int OnLMouseDown(int x, int y);
    //! Left mouse button (up) handling function
    virtual int OnLMouseUp(int x, int y);

    //! Right mouse button (down) handling function
    virtual int OnRMouseDown(int x, int y);
    //! Right mouse button (up) handling function
    virtual int OnRMouseUp(int x, int y);

    //! Returns width of the element
    int GetWidth();
    //! Sets width of the element
    void SetWidth(unsigned int width);

    //! Returns height of the element
    int GetHeight();
    //! Sets height of the element
    void SetHeight(unsigned int height);

    //! Find child by type or id
    /*! \param type Element type
        \param id Element ID
        \return Child if found by passed parameters (NULL if not)
    */
    CGUIElement * FindChild(eControlType type, unsigned int id = 0);
    //! Returns true if such child exists
    /*! \param element Element to check
        \return True if it exists, False if not
    */
    bool FindChild(CGUIElement * element);
    //! Returns an element who's XML node is equal to 'node'
    /*! \param node XML Node reference
        \return Element that has XML node
    */
    CGUIElement * FindChild(TiXmlNode * node);
    //! Returns element by index
    CGUIElement * GetChild(int index);
    //! Returns child count
    int GetChildCount();

    //! Adds child to child list
    bool AddChild(CGUIElement * element);
    //! Removes specified child from child list
    bool RemoveChild(CGUIElement * element);

    //! Returns element type
    eControlType GetType();
    //! Sets element type
    void SetType(eControlType type);

    TiXmlNode * GetXMLNode();

    //! Sets element ID
    void SetID(int id);
    //! Returns element ID
    int GetID();

    //! Returns element visiblity flag
    bool Visible();

    //! Hides element
    void Hide();
    //! Makes an element visible
    void Show();

    //! Hides element' children N levels deep
    void HideSiblings(int deep = -1);
    //! Shows element' children N levels deep
    void ShowSiblings(int deep = -1);

    //! Sets element Z Order (moves it up or down the list)
    void SetZOrder(unsigned int order);
    //! Sets element Z Order (moves it up or down the list)
    unsigned int GetZOrder();

    //! Returns element' parent
    CGUIElement * GetParent();
    //! Sets element' parent
    void SetParent(CGUIElement * elmnt);

    //! Returns element' material
    tMaterial * GetActiveMaterial();
    //! Sets element' material
    void SetActiveMaterial(tMaterial * mat);

    //! Processes message that is relevant to this element
    virtual void ProcessMessage(tMessage * msg);
    //! Processes messages that is relevant to this element
    virtual void ProcessMessages();

    //! Sets specified texture coordinate
    /*! \param index - index of coordinate
        \param U - U coordinate
        \param V - V Coordinate
    */
    void SetTexCoord(unsigned int index, float U, float V);

    tVERTEX2f GetTexCoord(unsigned int index);

    //! Sets event handler for the element
    void SetEventHandler(CGUIEventHandler * handler);
    //! Returns event handler
    CGUIEventHandler * GetEventHandler();

    char * GetExtRef();

    //! Broadcasts message
    void BroadcastMessage(CGUIElement * sender, eMessage msg, DWORD prm1 = 0, DWORD prm2 = 0,
                          double delay = 0, CGUIElement * receiver = NULL);

    tFlag m_RestrictionFlags, /*!< Movement and resizing flags */
        m_ReservedFlags;      /*!< Flags reserved for future use */

protected:
    tRect       m_Rect;                /*!< The actual element rectangle structure */
    TiXmlNode * m_pXMLNode;            /*!< This node' XML data reference for saving/reloading */
    tRGBA       m_Color;               /*!< Color */
    tMaterial * m_pBackgroundMaterial; /*!< Background material */
    tVERTEX2f   m_fTexCoord[4];        /*!< Texture coordinates for 4 corners */

    bool                       m_bVisible;    /*!< Visibility flag */
    CDoubleList<CGUIElement *> m_lstChildren; /*!< Element' children */
    int                        m_iElementID;  /*!< Element ID */

    CGUIElement *      m_pParent;      /*!< The parent element pointer */
    eControlType       m_eElementType; /*!< Textbox, scrollbar, element type. */
    CGUIEventHandler * m_pHEvent;
    char               m_strExternRef[256]; /*!< External reference to this control (filename and path) */
};

//! Border class
/*!
    This class resizes the element it belongs to.
*/
class CGUIBorder : public CGUIElement
{
public:
    CGUIBorder();
    virtual ~CGUIBorder();

    //! Drawing function
    virtual void OnDraw();

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * node, string filename = "");
    //! Resizing function
    virtual int OnSize(tRect newSizeRect);   // Border needs a custom OnSize() routine, since it has to assign
                                             // rectangles to it's border elements

    //! Left mouse down handler
    virtual int OnLMouseDown(int x, int y);
    //! Left mouse up handler
    virtual int OnLMouseUp(int x, int y);
    //! Mouse move handler
    virtual int OnMouseMove(int x, int y);

    //! Sets border width
    void SetBorderWidth(unsigned int width);
    //! Returns border width
    unsigned int GetBorderWidth();

    //! Sets border spacing (space between border and element)
    void SetBorderSpacing(unsigned int spacing);
    //! Returns border spacing
    unsigned int GetBorderSpacing();

    // Messages processing function
    virtual void ProcessMessages();

private:
    unsigned int m_iBorderWidth,     /*!< Border Width */
        m_iBorderSpacing;            /*!< Border Spacing */
    unsigned int m_iBorderElmntDrag; /*!< Imdex of dragged element */
    CGUIElement  m_BorderElmnt[8];   /*!< Border elements */
};

//! Static Control class
/*!
    This class is a simple text renderer wrapper.
*/
class CGUIStatic : public CGUIElement
{
public:
    CGUIStatic();
    virtual ~CGUIStatic();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * node, string filename = "");

    //! Drawing function
    virtual void OnDraw();
    // Destruction function
    virtual void OnDestroy();

    // Draw text
    void DrawText();

    //! Returns font this control uses
    CBitmapFont * GetFont();
    //! Sets font for this control
    void SetFont(CBitmapFont * font);

    //! Returns text for this control
    string GetText();
    //! Sets text
    void SetText(string strtext);

    //! Sets text alignment
    void SetTextAlign(int horiz = 0, int vert = 1);
    //! Returns text alignment
    int GetTextAlign(bool vert = false);

    //! Returns text length
    int GetTextLength();
    //! Returns number of lines in text
    int GetLineCount();
    // Returns line lengh (by index)
    int GetLineLength(int line_index);

private:
    tVERTEX2d     m_TextPos;   /*!< Text Position */
    bool          m_bWrapText; /*!< Are we wrapping text?*/
    CBitmapFont * m_pFont;     /*!< Font pointer for this control*/
    string        m_strText;   /*!< The TEXT!*/
    bool          m_bEditable; /*!< Is this control editable?*/

    int m_iTextHAlign, /*!< 0 - top, 1 - center, 2 - bottom*/
        m_iTextVAlign; /*!< 0 - left, 1 - center, 2 - right*/

    //! Returns text line (by index)
    string GetLine(int line, int char_count = -1);
};

//! TextBox Control class
/*!
    This class is a simple text renderer wrapper\n
    where text can be edited.
*/
class CGUITextBox : public CGUIStatic
{
public:
    CGUITextBox();
    virtual ~CGUITextBox();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * node, string filename = "");

    //! Drawing function
    virtual void OnDraw();

    //! Key up function handler
    virtual int OnKeyDown(int KeyCode);

    //! Used to determine caret position
    virtual int OnLMouseDown(int x, int y);
    //! Used to determine caret position
    virtual int OnLMouseUp(int x, int y);
    //! Used for multiple character selection (not implemented yet!)
    virtual int OnMouseMove(int x, int y);

    //! Messages processing function
    virtual void ProcessMessages();

protected:
    //! Returns current character the caret is at
    int GetCurChar();

private:
    tVERTEX2d m_CaretPos;     /*!< Caret Position - In characters offset */
    tVERTEX2d m_CaretCharPos; /*!< Caret Position - X/Y coordinates */
    tVERTEX2d m_CaretPosAbs;  /*!< Caret Position - in units(pixels?) */

    //! The main function that is called every time when:\n
    //! 1. Mouse is up (un-pressed) in the control rectangle to aquire caret position\n
    //! 2. Character key is pressed - left/right/up/down/enter/delete to displace caret\n
    void SetCharSel(int line, int row);

    unsigned int m_iSelStart,  /*!< Selection start - NOT IMPLEMENTED YET! */
        m_uiSelEnd;            /*!< Selection end - NOT IMPLEMENTED YET! */
    bool         m_bOverWrite; /*!< If Insert was pressed - when Insert key was pressed, swaps value. */
    eTextBoxMode m_eMode;      /*!< Textbox mode - password, numbers only, etc - NOT IMPLEMENTED YET! */
};

//! Button Control class
/*!
    This class is a plain old button.
*/
class CGUIButton : public CGUIStatic
{
public:
    CGUIButton();
    virtual ~CGUIButton();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * node, string filename);
    //! Mouse up handling function
    virtual int OnLMouseUp(int x, int y);
    //! Drawing function
    virtual void OnDraw();
    //! Destruction function
    virtual void OnDestroy();

    //! Returns current event
    tButtonAnimation * GetEvent(int event);

    //! Returns button state (how many times it was pressed)
    int GetButtonState();
    //! Sets button state
    void SetButtonState(bool loopanim, int state);

private:
    CDoubleList<tButtonState *> m_lstButtonStates; /*!< List of button states */
    int                         m_iButtonState;    /*!< Current state */
    bool                        m_bLoopState;      /*!< Do we have to loop states? */

    //! Returns current animation
    CAnimatedTexture * GetCurrentAnimation();
    //! Parses button states
    bool ParseBtnStates(TiXmlNode * btn_xml_node);
    //! Parses button events
    bool ParseStateEvents(tButtonState * state, TiXmlNode * state_xml_node);
};

//! RadioGroup Control class
/*!
    This class is a collection of buttons that are part of\n
    this radio group.
*/
class CGUIRadioGroup : public CGUIStatic
{
public:
    CGUIRadioGroup();
    virtual ~CGUIRadioGroup();

    //! Mouse up handler function
    virtual int OnLMouseUp(int x, int y);

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * node, string filename = "");
    //! Drawing function
    virtual void OnDraw();

    //! Sets current button selection
    void SetCurSel(int index = 0);
    //! Returns current selection
    int GetCurSel();

private:
    int m_iCurBtnSel; /*!< Current selection index - '-1' if none is selected */
};

//! Progressbar Control class
/*!
    This class is a typical progressbar.
*/
class CGUIProgressBar : public CGUIStatic
{
public:
    CGUIProgressBar();
    virtual ~CGUIProgressBar();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * node, string filename = "");
    //! Drawing function
    virtual void OnDraw();

    //! Sets range of progress bar
    void SetRange(int min, int max, bool mintomax = true);
    //! Returns range
    tVERTEX2f GetRange();

    //! Returns current position (value)
    int GetCurPos();
    //! Sets current position
    void SetCurPos(float pos);
    //! Resizing function
    virtual int OnSize(tRect newRect);

    //! Message processing handler function
    virtual void ProcessMessages();

private:
    //! Update function
    void OnUpdate(float curpos);

    int  m_iProgressBarType; /*!< Progress bar type - vertical or horizontal */
    bool m_bMinToMax; /*!< Direction in which it progesses	-	if negative then it goes from right to left
                         (top to bottom), positive - left to right (bottom to top)*/
    int m_iCurPos,    /*!< Current progressbar position */
        m_iMinPos,    /*!< Min value */
        m_iMaxPos;    /*!< Max value */
    double m_fCurPos, /*!< Floating current position (see PPV) */
        m_fPPV;       /*!< Pixel Per Value attribute */
};

//! Scrollbar Control class
/*!
    This class is a typical scrollbar.
*/
class CGUIScrollBar : public CGUIStatic
{
public:
    CGUIScrollBar();
    virtual ~CGUIScrollBar();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");
    //! Resizing function
    virtual int OnSize(tRect newRect);
    //! Drawing function
    virtual void OnDraw();
    //! Message processing function
    virtual void ProcessMessages();
    //! Updating function (when scrolled)
    virtual int OnUpdate(float curpos);
    //! Returns current position
    int GetCurPos();
    //! Sets current position
    void SetCurPos(float x);
    //! Sets scrollbar range
    void SetRange(int min, int max);
    //! Returns range values
    tVERTEX2d GetRange();

protected:
    int m_iCurPos,   /*!< Current scrollbar (thumb) position */
        m_iPrevPos;  /*!< Previous scrollbar (Thumb) position*/
    float m_fCurPos; /*!< Current floating position*/

    float m_fPPV;    /*!< Pixel Per Value*/
    int   m_iMinPos, /*!< Minimum position counted on scrollbar (e.g top)*/
        m_iMaxPos,   /*!< Maximum position counted on scrollbar (e.g bottom)*/

        m_iBtnInc; /*!< Increments that much when clicked on button (either top - bottom, or left - right)*/
};

//! Droplist Control class
/*!
    The droplist class where each entry is a button.
*/
class CGUIDropList : public CGUIButton
{
public:
    CGUIDropList();
    virtual ~CGUIDropList();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");
    //! Drawing function
    virtual void OnDraw();

    //! Expands the elements when droplist is clicked
    virtual void Expand();
    //! Collapses when any sub-element is clicked, or when droplist is clicked
    virtual void Collapse();
    //! Utility function
    virtual void OnPrepare();
    //! Message processing function
    virtual void ProcessMessages();
    //! Sets current element selection
    void SetCurSel(int sel);
    //! Returns current selection index
    int GetCurSel();

private:
    int m_iSpacing,   //! Spacing between each entry (vertical) and list type
        m_iListType;
    /*!< List types:\n
    Value = 0: All entries are of the same width\n
    Value = 1: All entries are of the same width of maximum entry and droplist is of that max width\n
    Value = 2: All entries are own width, but droplist becomes of max width */
    bool m_bExpanded, /*!< Indicates when list is expanded */
        m_bIdentSize; /*!< All entries are of the same size? */
    int m_iCurSel;    /*!< Current selection index */
};

//! Listbox Control class
/*!
    The listbox control where each listbox item is a button.
*/
class CGUIListBox : public CGUIElement
{
public:
    CGUIListBox();
    virtual ~CGUIListBox();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");
    //! Utility function
    virtual void OnPrepare();
    //! Message processing function
    virtual void ProcessMessages();
    //! Sets current element selection
    void SetCurSel(int sel);
    //! Returns current selection index
    int GetCurSel();

private:
    bool m_bIdentSize; /*!< All entries of the same size? */
    int  m_iSpacing;   /*!< Spacing between items */
    int  m_iCurSel;    /*!< Current item selected index */
};

//! Tab Control class
/*!
A tab control has a list of elements that in turn contain child elements/controls\n
and each element has an associated button that has to be clicked in order to turn the element\n
This button goes with name of "TabButton" and element goes with name of "TabElement". Simple.\n
When button is clicked, it's associated element' children are shown, while all others are hidden.\n
*/
class CGUITabControl : public CGUIRadioGroup
{
public:
    CGUITabControl();
    virtual ~CGUITabControl();

    //! Messages processing function
    virtual void ProcessMessages();
    //! Drawing function
    virtual void OnDraw();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);
    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");
};

//! Menu Control class
/*!
A Simple menu class, where each element is being\n
expanded if mouse is over it and it has children elements.
*/
class CGUIMenu : public CGUIButton
{
public:
    CGUIMenu();
    virtual ~CGUIMenu();

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);
    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");
    //! Messages processing function
    virtual void ProcessMessages();
    //! Drawing function
    virtual void OnDraw();

private:
    CGUIElement * m_piListExp[MENU_MAX_SUBS]; /*!< Pointers to last expanded elements */
    int           m_iMaxLen;                  /*!< Maximum depth of menu */
    int           m_iLastExpanded;            /*!< Index to lastly epanded element */

protected:
    //! Expands the passed element
    void Expand(CGUIElement * child);
    //! Collapses the passed element
    void Collapse(CGUIElement * child);

private:
    //! Returns the last element that has been expanded
    CGUIElement * GetLastExpanded(CGUIElement * root, int index);
};

//! Window Control class
/*!
A Window class is simply an element consisting of optional status bar,\n
title bar and its children.
*/
class CGUIWindow : public CGUIElement
{
public:
    CGUIWindow();
    virtual ~CGUIWindow();

    virtual int OnSize(tRect newRect);

    //! Saves this element to XML node/file
    /*! \param parent_node - XML node of the parent
        \param this_element - element where derived classes will save their attributes
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Save(TiXmlNode * parent_node, TiXmlElement * this_element);

    //! Parsing function
    /*! \param this_node XML node with data for this control
        \param filename XML file with data for this control
        \return 1 on success, 0 on minor error, -1 on critical error
    */
    virtual int Parse(TiXmlNode * this_node, string filename = "");
    //! Drawing function
    virtual void OnDraw();
    //! Messages handlnig function
    virtual void ProcessMessages();

protected:
    //! Restores window to previous rectangle
    void Restore();
    //! Maximizes window
    void Maximize();
    //! Closes (destroys?) window
    void Close();

private:
    tRect m_BackupRect; /*!< The rectangle that is used to store previous rectangle when window is resized. */
};

//! Is point inside rectangle?
bool PointInRect(tRect rect, int x, int y);
