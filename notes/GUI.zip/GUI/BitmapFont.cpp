#include "FontEngine.h"

CBitmapFont::CBitmapFont()
{
    m_pFontMat = NULL;
    m_iNI = m_iCharLengthX = m_iCharLengthY = m_iQuadLengthX = m_iQuadLengthY = m_iSpaceChar = m_dwFlags = 0;
}

CBitmapFont::~CBitmapFont()
{
    glDeleteLists(m_iFontBase, m_iNumLists);
    Destroy();
}

/*!
    Creates font by using passed parameters:\n\n
    normal_italic - offset for bitmap coord.\n
    charx -  character width in bitmap (in pixels)\n
    chary -  character height in bitmap (in pixels)\n
    quadx - quad width (in OpenGL units)\n
    quady - quad height (in OpenGL units)\n
    space - spacing between quads (in OpenGL units)\n
*/
int CBitmapFont::CreateBitmapFont(unsigned int normal_italic, unsigned int charx, unsigned int chary,
                                  unsigned int quadx, unsigned int quady, unsigned int space)
{
    m_iQuadLengthX = quadx;
    m_iQuadLengthY = quady;
    m_iCharLengthX = charx;
    m_iCharLengthY = chary;
    m_iSpaceChar   = space;
    m_iNI          = normal_italic;

    m_iNumLists = 256;

    glPushMatrix();
    float cx;   // Holds Our X Character Coord
    float cy;   // Holds Our Y Character Coord
    float quad_x = (float)m_iQuadLengthX, quad_y = (float)m_iQuadLengthY;
    int   lx = m_iCharLengthX, ly = m_iCharLengthY;

    m_iFontBase = glGenLists(m_iNumLists);   // Creating 256 Display Lists
    // glBindTexture(GL_TEXTURE_2D, texture[0]);		// Select Our Font Texture
    for(int loop = 0; loop < m_iNumLists; loop++)   // Loop Through All 256 Lists
    {
        cx = float(loop % lx) * 0.0625f;   // X Position Of Current Character
        cy = float(loop / ly) * 0.0625f;   // Y Position Of Current Character

        glNewList(m_iFontBase + loop, GL_COMPILE);           // Start Building A List
        glBegin(GL_QUADS);                                   // Use A Quad For Each Character
        glTexCoord2f(cx, 1 - cy - 0.0625f);                  // Texture Coord (Bottom Left)
        glVertex2i(0, 0);                                    // Vertex Coord (Bottom Left)
        glTexCoord2f(cx + 0.0625f, 1 - cy - 0.0625f);        // Texture Coord (Bottom Right)
        glVertex2i(quad_x, 0);                               // Vertex Coord (Bottom Right)
        glTexCoord2f(cx + 0.0625f, 1 - cy);                  // Texture Coord (Top Right)
        glVertex2i(quad_x, quad_y);                          // Vertex Coord (Top Right)
        glTexCoord2f(cx, 1 - cy);                            // Texture Coord (Top Left)
        glVertex2i(0, quad_y);                               // Vertex Coord (Top Left)
        glEnd();                                             // Done Building Our Quad (Character)
        glTranslated(m_iQuadLengthX + m_iSpaceChar, 0, 0);   // Move To The Right Of The Character
        glEndList();                                         // Done Building The Display List
    }                                                        // Loop Until All 256 Are Built
    glDisable(GL_TEXTURE_2D);
    glPopMatrix();

    return 1;
}

/*!
    Draws a character at specified location.
*/
void CBitmapFont::DrawChar(float x, float y, char c)
{
    // BeginOrtho must be called before, and EndOrtho after
    glPushMatrix();

    ApplyMaterial(m_pFontMat, TEX_COLOR, NULL);

    glLoadIdentity();   // Reset The Modelview Matrix
    glTranslatef(x, y, 0);

    glListBase(m_iFontBase - 32 + (128 * m_iNI));   // Choose The Font Set (0 or 1)
    glCallLists(1, GL_UNSIGNED_BYTE, &c);           // Write The Text To The Screen

    glPopMatrix();
}

/*!
    Composes and draws entire text by using format and passed variables.
*/
void CBitmapFont::Draw(char const * fmt, ...)
{
    if(m_pFontMat == NULL)
        return;

    if(fmt == NULL)   // If There's No Text
        return;       // Do Nothing

    char    text[256];   // Holds Our String
    va_list ap;          // Pointer To List Of Arguments

    va_start(ap, fmt);         // Parses The String For Variables
    vsprintf(text, fmt, ap);   // And Converts Symbols To Actual Numbers
    va_end(ap);                // Results Are Stored In Text

    glPushMatrix();
    ApplyMaterial(m_pFontMat, TEX_COLOR, NULL);

    BeginBlend();
    BeginOrtho();

    glLoadIdentity();   // Reset The Modelview Matrix

    glTranslated(CFontEngine::GetSingleton().GetTextPos().x, CFontEngine::GetSingleton().GetTextPos().y, 0);

    glListBase(m_iFontBase - 32 + (128 * m_iNI));        // Choose The Font Set (0 or 1)
    glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);   // Write The Text To The Screen

    EndOrtho();
    EndBlend();

    glPopMatrix();
}

/*!
    Parses bitmap font data from:\n\n
    node - XML Node\n
    OR\n
    filename - XML File.

*/
int CBitmapFont::Parse(TiXmlNode * node, char * filename)
{
    if(node == NULL && filename == NULL)
        return -1;

    if(filename != NULL)
    {
        TiXmlDocument doc;
        if(!doc.LoadFile(filename))
            return -1;
        else
            return Parse(doc.FirstChild(), NULL);
    }

    TiXmlElement * element       = NULL;
    TiXmlNode *    font_material = NULL;
    char const *   value         = NULL;

    element = node->ToElement();

    value = element->Attribute("Type");
    if(value != NULL)
    {
        if(stricmp(value, "bitmap") != 0)   // Not bitmap font
            return 0;

        m_eFontType = Bitmap_Font;
        value       = NULL;
    }

    // Font MUST have a name, otherwise it will be undistinguishable from the rest!
    value = element->Attribute("Name");
    if(value != NULL)
    {
        strcpy((char *)m_strFontName, value);

        value = NULL;
    }
    else
        return -1;

    value = element->Attribute("CX");
    if(value != NULL)
    {
        m_iCharLengthX = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("CharSizeX");
    if(value != NULL)
    {
        m_iCharLengthX = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("ID");
    if(value != NULL)
    {
        SetUserFontID(atoi(value));

        value = NULL;
    }

    value = element->Attribute("CY");
    if(value != NULL)
    {
        m_iCharLengthY = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("CharSizeY");
    if(value != NULL)
    {
        m_iCharLengthY = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("QX");
    if(value != NULL)
    {
        m_iQuadLengthX = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("QuadSizeX");
    if(value != NULL)
    {
        m_iQuadLengthX = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("QY");
    if(value != NULL)
    {
        m_iQuadLengthY = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("QuadSizeY");
    if(value != NULL)
    {
        m_iQuadLengthY = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("Spacing");
    if(value != NULL)
    {
        m_iSpaceChar = atoi(value);
        value        = NULL;
    }

    value = element->Attribute("NI");
    if(value != NULL)
    {
        if((stricmp(value, "normal") == 0) || (stricmp(value, "n") == 0))
            m_iNI = 0;
        else if((stricmp(value, "italic") == 0) || (stricmp(value, "i") == 0))
            m_iNI = 1;

        value = NULL;
    }

    font_material = node->FirstChild();
    if(font_material == NULL)   // Has no texture/material for font!
        return -1;
    else
    {
        CMaterialManager::GetSingleton().Parse(element, NULL);
        value = font_material->ToElement()->Attribute("RefID");
        if(value != NULL)
        {
            m_pFontMat = CMaterialManager::GetSingleton().GetMaterial(-1, atoi(value));
            value      = NULL;
        }
    }

    if(filename != NULL)
        strncpy(m_strFilename, filename, 128);
    else
        strncpy(m_strFilename, node->GetDocument()->Value(), 128);

    return CreateBitmapFont(m_iNI, m_iCharLengthX, m_iCharLengthY, m_iQuadLengthX, m_iQuadLengthY,
                            m_iSpaceChar);
}

/*!
    Commences blending mode in OpenGL
*/
void BeginBlend()
{
    glDisable(GL_DEPTH_TEST);                            // Disable Depth Testing
    glEnable(GL_BLEND);                                  // Enable Blending
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);                   // Type Of Blending To Perform
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);   // Really Nice Perspective Calculations
    glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);             // Really Nice Point Smoothing
}

/*!
Ends blending mode in OpenGL
*/
void EndBlend()
{
    glBlendFunc(GL_ONE, GL_ZERO);   // Reset to previous settings
    glEnable(GL_DEPTH_TEST);        // (restore)
}
