#include "Logger.h"

CGlobalLogger::CGlobalLogger() {}

CGlobalLogger::CGlobalLogger(char * filename)
{
    CLogger::Open(filename, true, false);
}

CGlobalLogger::~CGlobalLogger()
{
    Close();
}

int CGlobalLogger::Open(char * path_and_file, bool keep_open)
{
    return CLogger::Open(path_and_file, true, false);
}

int CGlobalLogger::Close()
{
    return 0;
}