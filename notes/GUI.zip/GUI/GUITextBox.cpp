#include "GUI.h"

CGUITextBox::CGUITextBox()
{
    m_bOverWrite = false;
    SetType(TextBox);
    m_CaretPos    = tVERTEX2d(0, 0);
    m_CaretPosAbs = tVERTEX2d(0, 0);
}

CGUITextBox::~CGUITextBox()
{
    OnDestroy();
}

int CGUITextBox::Parse(TiXmlNode * this_node, string filename)
{
    if(CGUIStatic::Parse(this_node, filename))
    {
        TiXmlDocument doc(filename.c_str());
        if(filename != "")
        {
            bool loadOkay = doc.LoadFile();

            if(!loadOkay)
                return false;

            m_pXMLNode = doc.FirstChild();
        }
        else
            m_pXMLNode = this_node;

        // START PARSING ELEMENT PROPERTIES
        char const *   value   = NULL;
        TiXmlElement * element = NULL;
        element                = m_pXMLNode->ToElement();

        m_eMode = None;

        value = element->Attribute("Mode");
        if(value != NULL)
        {
            if(stricmp(value, "Password") == 0)
                m_eMode = PasswordMode;
            else if(stricmp(value, "Numbers") == 0)
                m_eMode = NumberMode;

            value = NULL;
        }

        if(FindChild(Caret) == NULL)
        {
            CGUIElement * caret = this->FindChild(Simple, 0);
            if(caret != NULL)
                caret->SetType(Caret);
        }
        else
            RemoveChild(FindChild(Simple, 0));

        return 1;
    }

    return 0;
}

int CGUITextBox::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("TextBox");

    if(this_element != NULL)
        element = this_element;

    // Wrapping text?
    if(m_eMode != None)
    {
        if(m_eMode == PasswordMode)
            element->SetAttribute("Mode", "Password");
        else if(m_eMode == NumberMode)
            element->SetAttribute("Mode", "Numbers");
    }

    if(this_element != NULL)
        CGUIStatic::Save(NULL, this_element);
    else
    {
        CGUIStatic::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUITextBox::OnDraw()
{
    ProcessMessages();

    CGUIElement * caret = this->FindChild(Caret, 0);
    if(caret != NULL)
    {
        // Set up caret rectangle
        tRect CaretRect;
        CaretRect.m_iLeft   = m_CaretPosAbs.x + m_CaretPos.x;
        CaretRect.m_iRight  = m_CaretPosAbs.x + m_CaretPos.x + GetFont()->m_iQuadLengthX / 2;
        CaretRect.m_iTop    = m_CaretPosAbs.y + m_CaretPos.y;
        CaretRect.m_iBottom = m_CaretPosAbs.y + m_CaretPos.y - GetFont()->m_iQuadLengthY;

        caret->SetRect(CaretRect);
        if(!PointInRect(GetRect(), (CaretRect.m_iLeft + CaretRect.m_iRight) / 2,
                        (CaretRect.m_iTop + CaretRect.m_iBottom) / 2))
            caret->Hide();

        if(!(CGUIUtility::GetSingleton().GetActiveElement() == this))
            caret->Hide();
    }

    CGUIStatic::OnDraw();
}

int CGUITextBox::OnKeyDown(int KeyCode)
{
    string text = GetText();

    switch(KeyCode)
    {
        case 8:   // Backspace
            {
                string left_string, right_string;
                int    count = 0, cur_char = GetCurChar() - 1;
                if(cur_char < 0)
                    return 0;

                for(int i = 0; i < GetTextLength(); i++)
                {
                    if(i < cur_char)
                    {
                        left_string.insert(count, 1, GetText()[i]);
                        count++;
                    }
                    else if(i == cur_char)
                        count = 0;
                    else if(i > cur_char)
                    {
                        right_string.insert(count, 1, GetText()[i]);
                        count++;
                    }
                }

                SetText(left_string + right_string);
                m_CaretCharPos.x--;
                if(m_CaretCharPos.x <= 0)
                {
                    m_CaretCharPos.y--;
                    if(m_CaretCharPos.y <= 0)
                        m_CaretCharPos.y = 0;
                    else
                        m_CaretCharPos.x = GetLineLength(m_CaretCharPos.y);
                }

                SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
            }
            break;

        case 46:   // Delete char + 1
            {
                string left_string, right_string;
                int    count = 0, cur_char = GetCurChar();
                for(int i = 0; i < GetTextLength(); i++)
                {
                    if(i < cur_char)
                    {
                        left_string.insert(count, 1, GetText()[i]);
                        count++;
                    }
                    else if(i == cur_char)
                        count = 0;
                    else if(i > cur_char)
                    {
                        right_string.insert(count, 1, GetText()[i]);
                        count++;
                    }
                }

                SetText(left_string + right_string);
                SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
            }
            break;

        case 13:   // Enter - new line!
            text.insert(GetCurChar(), 1, '\n');
            m_CaretCharPos.x = 0;
            m_CaretCharPos.y++;

            SetText(text);
            SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
            return 1;
            break;

        case 37:   // Left key
            m_CaretCharPos.x--;
            if((m_CaretCharPos.x - 1) < 0)   // Scroll to upper line end
            {
                m_CaretCharPos.y--;
                if(m_CaretCharPos.y < 0)
                {
                    m_CaretCharPos.y = 0;
                    m_CaretCharPos.x = 0;
                }
                else
                    m_CaretCharPos.x = GetLineLength(m_CaretCharPos.y);
            }

            SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
            break;

        case 39:                                                               // Right key
            if((m_CaretCharPos.x + 1) > GetLineLength(m_CaretCharPos.y) - 1)   // Scroll to upper line end
            {
                if(GetLineLength(m_CaretCharPos.y + 1) != 0)
                {
                    m_CaretCharPos.y++;
                    m_CaretCharPos.x = 0;
                }

                if(m_CaretCharPos.x > GetLineLength(m_CaretCharPos.y))
                    m_CaretCharPos.x = GetLineLength(m_CaretCharPos.y);
            }
            else
                m_CaretCharPos.x++;

            SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
            break;

        case 38:   // Up key
            if((m_CaretCharPos.y - 1) >= 0)
            {
                if((m_CaretCharPos.x > GetLineLength(m_CaretCharPos.y - 1)))
                {
                    m_CaretCharPos.x = GetLineLength(m_CaretCharPos.y - 1) - 1;
                    m_CaretCharPos.y--;
                    if(m_CaretCharPos.y < 0)
                        m_CaretCharPos.y = 0;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
                else if(GetLineLength(m_CaretCharPos.y - 1) == 0 && (m_CaretCharPos.y - 1) > 0)
                {
                    m_CaretCharPos.x = 0;
                    m_CaretCharPos.y--;
                    if(m_CaretCharPos.y < 0)
                        m_CaretCharPos.y = 0;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
                else
                {
                    m_CaretCharPos.y--;
                    if(m_CaretCharPos.y < 0)
                        m_CaretCharPos.y = 0;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
            }
            break;

        case 40:   // Down key
            if((m_CaretCharPos.y + 1) <= (GetLineCount() - 1))
            {
                if((m_CaretCharPos.x > GetLineLength(m_CaretCharPos.y + 1)))
                {
                    m_CaretCharPos = GetLineLength(m_CaretCharPos.y + 1) - 1;
                    m_CaretCharPos.y++;
                    if(m_CaretCharPos.y > GetLineCount() - 1)
                        m_CaretCharPos.y = GetLineCount() - 1;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
                else if(
                    GetLineLength(m_CaretCharPos.y + 1) == 0 && (m_CaretCharPos.y + 1) < (GetLineCount() - 1))
                {
                    m_CaretCharPos.y++;
                    if(m_CaretCharPos.y > GetLineCount() - 1)
                        m_CaretCharPos.y = GetLineCount() - 1;
                    m_CaretCharPos.x = 0;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
                else
                {
                    m_CaretCharPos.y++;
                    if(m_CaretCharPos.y > GetLineCount() - 1)
                        m_CaretCharPos.y = GetLineCount() - 1;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
            }
            break;

        case 45:   // Insert key
            m_bOverWrite = !m_bOverWrite;
            break;

        default:
            {
                if(m_bOverWrite) {}
                else
                {
                    text.insert(GetCurChar(), 1, KeyCode);
                    SetText(text);
                    m_CaretCharPos.x++;
                    SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                }
                break;
            }
    }

    return 0;
}

int CGUITextBox::OnLMouseDown(int x, int y)
{
    return CGUIStatic::OnLMouseDown(x, y);
}

int CGUITextBox::OnLMouseUp(int x, int y)
{
    if(PointInRect(GetRect(), x, y))
    {
        CGUIElement * caret = this->FindChild(Caret, 0);
        if(caret != NULL)
            caret->Show();

        int ttl_length = 0;
        for(int i = 0; i < GetLineCount(); i++)
        {
            int  line_length = GetLineLength(i);
            char line[255]   = "";

            int text_width = GetLineLength(i) * GetFont()->m_iQuadLengthX;

            int align_x_pixels = 0, align_y_pixels = 0;

            int max_width_chars  = (GetWidth() / GetFont()->m_iQuadLengthX) + 1;
            int max_height_chars = (GetHeight() / GetFont()->m_iQuadLengthY) + 1;

            if((line_length * GetFont()->m_iQuadLengthX) < GetWidth())
            {
                if(GetTextAlign() == 0)
                    align_x_pixels = 0;

                if(GetTextAlign() == 1)
                    align_x_pixels = (GetWidth() - (line_length * GetFont()->m_iQuadLengthX)) / 2;

                if(GetTextAlign() == 2)
                    align_x_pixels = GetWidth() - (line_length * GetFont()->m_iQuadLengthX);
            }

            if(GetTextAlign(true) == 1)
            {
                // A one line text, align in pixels!
                if(GetHeight() > GetFont()->m_iQuadLengthY && GetHeight() < 2 * GetFont()->m_iQuadLengthY)
                    align_y_pixels = (GetHeight() - GetFont()->m_iQuadLengthY) / 2;
                else   // More than one line, align in lines!
                    align_y_pixels = ((max_height_chars - GetLineCount()) / 2) * GetFont()->m_iQuadLengthY;
            }

            if(GetTextAlign(true) == 2)
                align_y_pixels = (max_height_chars - GetLineCount()) * GetFont()->m_iQuadLengthY;

            for(int j = 0; j < GetLineLength(i); j++)
            {
                tRect CharRect;
                CharRect.m_iLeft   = GetRect().m_iLeft + j * GetFont()->m_iQuadLengthX + align_x_pixels;
                CharRect.m_iRight  = CharRect.m_iLeft + GetFont()->m_iQuadLengthX;
                CharRect.m_iBottom = GetRect().m_iTop - (i + 1) * GetFont()->m_iQuadLengthY - align_y_pixels;
                CharRect.m_iTop    = CharRect.m_iBottom + GetFont()->m_iQuadLengthY;

                if(PointInRect(CharRect, x, y))
                {
                    m_CaretPos.x = CharRect.m_iLeft;
                    m_CaretPos.y = CharRect.m_iTop;

                    m_CaretCharPos.x = j;
                    m_CaretCharPos.y = i;
                    m_CaretPosAbs.x = m_CaretPosAbs.y = 0;
                    break;
                }
                ttl_length++;
            }

            ttl_length++;
        }
    }

    return CGUIStatic::OnLMouseUp(x, y);
}

int CGUITextBox::OnMouseMove(int x, int y)
{
    return CGUIStatic::OnMouseMove(x, y);
}

void CGUITextBox::ProcessMessages()
{
    tMessage * msg = m_pHEvent->GetNextMsg();
    while(msg != NULL)
    {
        switch(msg->m_eMsg)
        {
            case MoveX:
            case MoveY:
            case MoveXY:
                {
                    if(msg->m_pSender == this)
                    {
                        m_CaretPosAbs.x += msg->m_dwParam[0];
                        m_CaretPosAbs.y += msg->m_dwParam[1];
                        SetRect(GetRect());

                        m_pHEvent->RemoveMessage(msg);
                        msg = NULL;
                    }
                    break;
                }

            case SizeX:
            case SizeY:
            case SizeXY:
                {
                    if(msg->m_pSender == this)
                    {
                        SetCharSel(m_CaretCharPos.x, m_CaretCharPos.y);
                        m_pHEvent->RemoveMessage(msg);
                        msg = NULL;
                    }
                    break;
                }
        }

        msg = m_pHEvent->GetNextMsg(msg);
    }

    CGUIStatic::ProcessMessages();
}

void CGUITextBox::SetCharSel(int x, int y)
{
    int ttl_length = 0;
    for(int i = 0; i < GetLineCount(); i++)
    {
        int  line_length = GetLineLength(i);
        char line[255]   = "";

        int text_width = GetLineLength(i) * GetFont()->m_iQuadLengthX;

        int align_x_pixels = 0, align_y_pixels = 0;

        int max_width_chars  = (GetWidth() / GetFont()->m_iQuadLengthX) + 1;
        int max_height_chars = (GetHeight() / GetFont()->m_iQuadLengthY) + 1;

        if((line_length * GetFont()->m_iQuadLengthX) < GetWidth())
        {
            if(GetTextAlign() == 0)
                align_x_pixels = 0;

            if(GetTextAlign() == 1)
                align_x_pixels = (GetWidth() - (line_length * GetFont()->m_iQuadLengthX)) / 2;

            if(GetTextAlign() == 2)
                align_x_pixels = GetWidth() - (line_length * GetFont()->m_iQuadLengthX);
        }

        if(GetTextAlign(true) == 1)
        {
            // A one line text, align in pixels!
            if(GetHeight() > GetFont()->m_iQuadLengthY && GetHeight() < 2 * GetFont()->m_iQuadLengthY)
                align_y_pixels = (GetHeight() - GetFont()->m_iQuadLengthY) / 2;
            else   // More than one line, align in lines!
                align_y_pixels = ((max_height_chars - GetLineCount()) / 2) * GetFont()->m_iQuadLengthY;
        }

        if(GetTextAlign(true) == 2)
            align_y_pixels = (max_height_chars - GetLineCount()) * GetFont()->m_iQuadLengthY;

        for(int j = 0; j <= GetLineLength(i); j++)
        {
            tRect CharRect;
            CharRect.m_iLeft   = GetRect().m_iLeft + j * GetFont()->m_iQuadLengthX + align_x_pixels;
            CharRect.m_iRight  = CharRect.m_iLeft + GetFont()->m_iQuadLengthX;
            CharRect.m_iBottom = GetRect().m_iTop - (i + 1) * GetFont()->m_iQuadLengthY - align_y_pixels;
            CharRect.m_iTop    = CharRect.m_iBottom + GetFont()->m_iQuadLengthY;

            if(j == x && i == y)
            {
                m_CaretPos.x = CharRect.m_iLeft;
                m_CaretPos.y = CharRect.m_iTop;

                m_CaretCharPos.x = j;
                m_CaretCharPos.y = i;
                m_CaretPosAbs.x = m_CaretPosAbs.y = 0;
                break;
            }
            ttl_length++;
        }

        ttl_length++;
    }
}

int CGUITextBox::GetCurChar()
{
    int line_length = 0, ttl_count = 0;
    for(int i = 0; i < GetLineCount(); i++)
    {
        if(i == m_CaretCharPos.y)
            return ttl_count + m_CaretCharPos.x;

        line_length = GetLineLength(i) + 1;
        ttl_count += line_length;
    }

    return 0;
}
