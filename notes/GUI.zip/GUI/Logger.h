// Logger.h: interface for the CLogger class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOGGER_H__D5C75D23_D1A5_43BE_A6F3_3778FDD8A669__INCLUDED_)
#define AFX_LOGGER_H__D5C75D23_D1A5_43BE_A6F3_3778FDD8A669__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

#include "Config.h"
#include "Singleton.h"
#include <stdarg.h>
#include <string.h>
#include <stdio.h>

//! Logger class.
/*!
    This class logs passed messages (that can be formatted) into the\n
    specified file. It has the ability to overwrite, append, and keep the\n
    specified file open until the explicit command to close is given.
*/
class CLogger
{
public:
    CLogger();
    CLogger(char * filename, bool keep_open = false, bool append = false);
    virtual ~CLogger();

    /*!
        Opens file for write access\n
        path_and_file - The path and file name of the file\n
        keep_open - keep the file open until the Close() is called\n
        append - append to the end of file
    */
    virtual int Open(char * path_and_file, bool keep_open = false, bool append = false);

    /*!
        Writes string in format specified to opened file\n
        format - as in printf, sprintf, and the rest (uses va_start, va_end)
    */
    virtual int Write(char const * format, ...);

    /*!
        Appends specified string in given format to opened file\n
        format - as in printf, sprintf, and the rest (uses va_start, va_end)
    */
    virtual int Append(char const * format, ...);

    /*!
        Erases opened file
    */
    virtual int Erase();
    /*!
        Closes opened file
    */
    virtual int Close();

    /*! Returns an error code */
    int GetError();

private:
    FILE * m_pFile;            /*!< This variable stores a pointer to the opened file. */
    char   m_strFilename[256]; /*!< This variable stores a file name. */
    bool m_bKeepOpen; /*!< This variable indicates whether the file should be open until Close() is called or
                         not. */
};
#endif   // !defined(AFX_LOGGER_H__D5C75D23_D1A5_43BE_A6F3_3778FDD8A669__INCLUDED_)

#ifdef USE_GLOBAL_LOGGER
//! Global Logger class.
/*!
    This class logs passed messages (that can be formatted) into the\n
    globally specified file that is open until the Close() is called, or\n
    CGlobalLogger is destroyed.
*/
class CGlobalLogger : public CLogger,
                      public CSingleton<CGlobalLogger>
{
public:
    CGlobalLogger();
    CGlobalLogger(char * filename);
    virtual ~CGlobalLogger();

    /*!
      This function opens the given file (path and file name) and keeps it open
    */
    virtual int Open(char * path_and_file, bool keep_open = true);
    /*!
      This function closes the file.
    */
    virtual int Close();
};

#endif