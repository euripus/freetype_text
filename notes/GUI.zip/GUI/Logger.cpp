// Logger.cpp: implementation of the CLogger class.
//
//////////////////////////////////////////////////////////////////////

#include "Logger.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLogger::CLogger()
{
    m_pFile = NULL;
}

CLogger::CLogger(char * filename, bool keep_open, bool append)
{
    m_pFile = NULL;
    Open(filename, keep_open, append);
}

CLogger::~CLogger()
{
    Close();
}

int CLogger::Open(char * path_and_file, bool keep_open, bool append)
{
    if(path_and_file == NULL)
        return -1;

    m_bKeepOpen = keep_open;
    // Firstly, we open that file, and if it doesn't exist, we create it
    if(append)
        m_pFile = fopen(path_and_file, "a+t");
    else
        m_pFile = fopen(path_and_file, "w+t");

    if(!keep_open)   // If do not keep it open, close it, but we've already created it if it wasn't there with
                     // code above!
    {
        Close();

        if(strlen(path_and_file) > 256)
            strncpy(m_strFilename, path_and_file, 256);
        else
            strcpy(m_strFilename, path_and_file);
    }

    return 1;
}

//!
int CLogger::Write(char const * format, ...)
{
    if(format == NULL)   // If There's No Text
        return -1;       // Do Nothing

    char    text[256];   // Holds Our String
    va_list ap;          // Pointer To List Of Arguments

    va_start(ap, format);         // Parses The String For Variables
    vsprintf(text, format, ap);   // And Converts Symbols To Actual Numbers
    va_end(ap);

    if(m_pFile == NULL)
    {
        if(m_strFilename == NULL)
            return -1;

        m_pFile = fopen(m_strFilename, "w+t");
        if(m_pFile == NULL)
            return -1;

        fprintf(m_pFile, "%s", text);

        if(!m_bKeepOpen)
            Close();

        // All written OK, return OK too
        return 1;
    }
    else
    {
        fprintf(m_pFile, "%s", text);

        if(!m_bKeepOpen)
            Close();

        return 1;
    }

    // File doesn't exist or haven't been open, return error
    return -1;
}

int CLogger::Append(char const * fmt, ...)
{
    if(fmt == NULL)   // If There's No Text
        return -1;    // Do Nothing

    char    text[256];   // Holds Our String
    va_list ap;          // Pointer To List Of Arguments

    va_start(ap, fmt);         // Parses The String For Variables
    vsprintf(text, fmt, ap);   // And Converts Symbols To Actual Numbers
    va_end(ap);

    if(m_pFile == NULL)
    {
        if(m_strFilename == NULL)
            return -1;

        m_pFile = fopen(m_strFilename, "a+t");
        if(m_pFile == NULL)
            return -1;

        fprintf(m_pFile, "%s", text);

        if(!m_bKeepOpen)
            Close();

        // All written OK, return OK too
        return 1;
    }
    else
    {
        fprintf(m_pFile, "%s", text);

        if(!m_bKeepOpen)
            Close();

        return 1;
    }

    return -1;
}

int CLogger::Erase()
{
    if(m_pFile == NULL)
        return -1;

    fseek(m_pFile, 0, SEEK_SET);
    fprintf(m_pFile, "");

    return 1;
}

int CLogger::Close()
{
    if(m_pFile == NULL)
        return -1;

    fclose(m_pFile);
    m_pFile = NULL;

    return 1;
}

int CLogger::GetError()
{
    if(m_pFile == NULL)
        return -1;

    return ferror(m_pFile);
}