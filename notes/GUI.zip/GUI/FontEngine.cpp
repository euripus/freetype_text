// FontEngine.cpp: implementation of the CFontEngine class.
//
//////////////////////////////////////////////////////////////////////

#include "FontEngine.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFontEngine::CFontEngine()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - Font Engine: Initialized.\n");
#endif

    m_iLastFontUID = 0;
}

CFontEngine::~CFontEngine()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - Font Engine: Exiting.\n");
#endif
    m_lstFonts.erase();
}

/*!
    Parses the:\n
    XML Node OR XML file\n
    into font class. \n

    this_node - XML Node to parse for font data aquisition.
    filename - XML file to parse for XML node (up)

    Returns 1 on success, 0 on no success, -1 on critical error

*/
int CFontEngine::Parse(TiXmlNode * this_node, char * filename)
{
    TiXmlNode *    node    = NULL;
    TiXmlElement * element = NULL;
    char const *   value   = NULL;

    TiXmlDocument doc(filename);
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        node = doc.FirstChild();
    }
    else
        node = this_node;

    if(node == NULL)
        return -1;

    int ttl_count = 0;

    if(node != NULL)
    {
        TiXmlNode * child_node = NULL;

        child_node = node->FirstChild();
        element    = child_node->ToElement();

        while(child_node != NULL)
        {
            if(AddFont(child_node, NULL))
                ttl_count++;

            child_node = node->IterateChildren(child_node);
        }
    }

    return ttl_count;
}

/*!
    Adds font by using passed XML data.\n
    Returns 1 on success, 0 on no success, -1 on critical error
*/
int CFontEngine::AddFont(TiXmlNode * this_node, char * filename)
{
    TiXmlNode *    node    = NULL;
    TiXmlElement * element = NULL;
    char const *   value   = NULL;

    TiXmlDocument doc(filename);
    if(filename != NULL)
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        node = doc.FirstChild();
    }
    else
        node = this_node;

    if(node == NULL)
        return -1;

    element               = node->ToElement();
    CCustomFont * newFont = NULL;

    value = element->Attribute("Type");
    if(value != NULL)
    {
        if(stricmp(value, "bitmap") == 0)
        {
            newFont = new CBitmapFont;
            if(newFont->Parse(node, NULL))
            {
#ifdef USE_GLOBAL_LOGGER
                CGlobalLogger::GetSingleton().Write(
                    "GUI Framework - Font Engine: Bitmap Font added successfully. (%s, %s)\n",
                    newFont->m_strFontName, newFont->m_strFilename);
#endif

                m_lstFonts.push_back(newFont);
                return 1;
            }
            else
            {
#ifdef USE_GLOBAL_LOGGER
                CGlobalLogger::GetSingleton().Write(
                    "GUI Framework - Font Engine: Unable to parse(load) font! (%s, %s)\n",
                    newFont->m_strFontName, newFont->m_strFilename);
#endif
            }
        }
        else if(stricmp(value, "std") == 0) {}

        value = NULL;
    }
    else
        return -1;

    return 1;
}

/*!
    Returns a unique ID (unique to font engine only!)
*/
unsigned int CFontEngine::GetNextUID()
{
    m_iLastFontUID++;
    return m_iLastFontUID;
}

/*!
    Returns a font by reference of:\n
    index - index in font list\n
    uid - unique font ID\n
*/
CCustomFont * CFontEngine::GetFont(int index, int uid)
{
    if(index == -1 && uid != -1)
    {
        CCustomFont * tmp = m_lstFonts.begin();
        m_lstFonts.set_ptr(tmp);

        while(tmp != NULL)
        {
            if(tmp->GetUserFontID() == uid)
                return tmp;

            tmp = m_lstFonts.next();
        }
    }
    else if(index != -1 && uid == -1)
        return m_lstFonts.at(index);

    return NULL;
}

/*!
    Returns a font by reference of:\n
    name - font name.
*/
CCustomFont * CFontEngine::GetFont(char const * name)
{
    CCustomFont * tmp = m_lstFonts.begin();
    m_lstFonts.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(stricmp(name, tmp->GetFontName()) == 0)
            return tmp;

        tmp = m_lstFonts.next();
    }

    return NULL;
}

/*!
    Returns font printing position (3D)\n
*/
CVector3 CFontEngine::GetTextPos()
{
    return m_TextPos;
}

/*!
    Sets text printing position.
*/
void CFontEngine::SetTextPos(CVector3 pos)
{
    m_TextPos = pos;
}