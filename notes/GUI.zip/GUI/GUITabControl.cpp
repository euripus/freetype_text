#include "GUI.h"

CGUITabControl::CGUITabControl()
{
    SetType(TabControl);
}

CGUITabControl::~CGUITabControl()
{
    OnDestroy();
}

int CGUITabControl::Parse(TiXmlNode * this_node, string filename)
{
    if(CGUIRadioGroup::Parse(this_node, filename))
    {
        int           btn_index = 0;
        CGUIElement * btn       = m_lstChildren.begin();
        m_lstChildren.set_ptr(btn);

        while(btn != NULL)
        {
            if(btn->GetType() == Button)
            {
                btn->SetID(btn_index);
                btn->SetType(TabButton);
                btn_index++;
            }

            btn = m_lstChildren.next();
        }

        CGUIElement * elmnt = m_lstChildren.begin();
        m_lstChildren.set_ptr(elmnt);

        while(elmnt != NULL)
        {
            if(elmnt->GetType() != TabButton)
            {
                if(elmnt->GetID() == GetCurSel())
                    elmnt->Show();
                else
                    elmnt->Hide();
            }

            elmnt = m_lstChildren.next();
        }
        return 1;
    }
    return 0;
}

int CGUITabControl::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("TabControl");

    if(this_element != NULL)
        element = this_element;

    if(this_element != NULL)
        CGUIRadioGroup::Save(NULL, this_element);
    else
    {
        CGUIRadioGroup::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUITabControl::OnDraw()
{
    ProcessMessages();
    CGUIStatic::OnDraw();
}

void CGUITabControl::ProcessMessages()
{
    tMessage * tmp = m_pHEvent->GetNextMsg();
    while(tmp != NULL)
    {
        if(tmp->m_eMsg == ButtonPressed && FindChild(tmp->m_pSender)
           && tmp->m_pSender->GetType() == TabButton)
        {
            ((CGUIButton *)tmp->m_pSender)->SetButtonState(false, 1);

            int           cur_sel = 0;
            CGUIElement * elmnt   = m_lstChildren.begin();
            m_lstChildren.set_ptr(elmnt);

            while(elmnt != NULL)
            {
                if(elmnt->GetType() == TabButton)
                {
                    if(elmnt != tmp->m_pSender)
                        ((CGUIButton *)elmnt)->SetButtonState(false, 0);
                    else
                        SetCurSel(cur_sel);

                    cur_sel++;
                }

                elmnt = m_lstChildren.next();
            }

            elmnt = m_lstChildren.begin();
            m_lstChildren.set_ptr(elmnt);

            while(elmnt != NULL)
            {
                if(elmnt->GetType() != TabButton)
                {
                    if(elmnt->GetID() == GetCurSel())
                        elmnt->Show();
                    else
                        elmnt->Hide();
                }

                elmnt = m_lstChildren.next();
            }
        }

        tmp = m_pHEvent->GetNextMsg(tmp);
    }
}
