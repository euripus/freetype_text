#ifndef DOUBLE_LIST_TEMPLATE_INCLUDED
#define DOUBLE_LIST_TEMPLATE_INCLUDED

#include <stdio.h>
#include <malloc.h>

//! Doubly linked list
/*!
    A usual double-linked list.
*/
template<class T>
class CDoubleList
{
private:
    //! A node of the linked list
    struct tNode
    {
        T       Data;
        tNode * m_pPrev;
        tNode * m_pNext;

        tNode()
        {
            m_pPrev = NULL;
            m_pNext = NULL;
        }
    };

    tNode * m_pHead;
    tNode * m_pTail;
    tNode * pPtr;

    int m_iSize;


public:
    CDoubleList()
    {
        m_pHead = NULL;
        m_pTail = NULL;
        m_iSize = 0;
        pPtr    = NULL;
    }
    virtual ~CDoubleList(){};

    void push_front(T data)
    {
        tNode * Temp = (tNode *)malloc(sizeof(tNode));   // CREATE NEW CONTAINER FOR DATA
        Temp->Data   = data;   // ASSIGN DATA FROM CONTAINER TO POINT TO THE PASSED DATA

        if(m_pHead == NULL && m_pTail == NULL)   // IF OUR LIST IS EMPTY
        {
            Temp->m_pNext = NULL;
            Temp->m_pPrev = NULL;
            m_pHead       = Temp;   // ASSIGN HEAD AND TAIL TO NEWLY ADDED CONTAINER
            m_pTail       = Temp;
        }
        else
        {
            Temp->m_pNext    = m_pHead;   // OTHERWISE MAKE TEMP A NEW HEAD
            m_pHead->m_pPrev = Temp;
            Temp->m_pPrev    = NULL;
            m_pHead          = Temp;
        }
        m_iSize++;   // WE SUCCESSEFULLY ADDED A CONTAINER, INCREMENT COUNT BY 1
    }

    void push_back(T data)
    {
        tNode * Temp = (tNode *)malloc(sizeof(tNode));   // CREATE NEW CONTAINER FOR DATA
        Temp->Data   = data;   // ASSIGN DATA FROM CONTAINER TO POINT TO THE PASSED DATA

        if(m_pHead == NULL && m_pTail == NULL)   // IF OUR LIST IS EMPTY
        {
            Temp->m_pNext = NULL;
            Temp->m_pPrev = NULL;
            m_pHead       = Temp;   // ASSIGN HEAD AND TAIL TO NEWLY ADDED CONTAINER
            m_pTail       = Temp;
        }
        else
        {
            Temp->m_pPrev    = m_pTail;   // OTHERWISE MAKE TEMP A NEW TAIL
            Temp->m_pNext    = NULL;
            m_pTail->m_pNext = Temp;
            m_pTail          = Temp;
        }
        m_iSize++;   // WE SUCCESSEFULLY ADDED A CONTAINER, INCREMENT COUNT BY 1
    }

    T pop_front()
    {
        if(m_pHead != NULL)   // IF OUR HEAD ISNT NULL (WHAT MEANS THAT OUR LIST IS EMPTY)
        {
            T       data     = m_pHead->Data;      // MAKE TEMPORARY STORAGE FOR DATA
            tNode * new_head = m_pHead->m_pNext;   // CREATE NEW HEAD
            free(m_pHead);                         // DELETE OLD HEAD
            m_pHead = new_head;                    // ASSIGN HEAD TO POINT TO NEW HEAD

            if(m_pHead == NULL)   // IF ITS NULL, MAKE SURE OUR TAIL IS ALSO NULL
            {
                m_pTail = NULL;
                m_iSize = 0;
            }
            else
                m_pHead->m_pPrev =
                    NULL;   // MAKE SURE ITS NOT A CIRCULAR LINKED LIST, SO PREVIOUS OF THE HEAD IS NOTHING

            m_iSize--;     // WE SUCCESSEFULLY REMOVED A CONTAINER, DECREMENT COUNT BY 1
            return data;   // RETURN OUR REMOVED DATA
        }
        return NULL;   // IF LIST IS EMPTY, RETURN NULL
    }

    T pop_back()
    {
        if(m_pTail != NULL)
        {
            T       data     = m_pTail->Data;
            tNode * new_tail = m_pTail->m_pPrev;
            free(m_pTail);
            m_pTail = new_tail;

            if(m_pTail == NULL)
                m_pHead = NULL;
            else
                m_pTail->m_pNext = NULL;

            m_iSize--;
            return data;
        }

        return NULL;
    }

    T at(int i)   // note that array starts at 0, not 1!!! So, to get member index = 5, pass 4 here
    {
        if(this == NULL)
            return NULL;

        tNode * tmp = m_pHead;   // MAKE TEMPORARY NODE POINTING TO HEAD

        int count = 0;
        while(
            tmp != NULL
            && count
                   != i)   // LOOP THRU LIST AND INCREMENT THE COUNT UNTIL COUNT ISNT EQUAL TO PASSED INTEGER
        {
            tmp = tmp->m_pNext;
            count++;
        }

        if(tmp != NULL)   // IF OUR NODE ISNT NULL, RETURN ITS DATA
            return tmp->Data;
        else
            return NULL;   // OTHERWISE RETURN NULL
    }

    T remove_from(int i)
    {
        if(i >= 0)
        {
            tNode * tmp = m_pHead;

            int count = 0;
            while(tmp != NULL && count != i)
            {
                tmp = tmp->m_pNext;
                count++;
            }

            if(tmp != NULL)
            {
                T       ret_data = tmp->Data;
                tNode * tmp1     = tmp->m_pPrev;
                tNode * tmp2     = tmp->m_pNext;
                if(tmp2 == NULL)   // we got the tail
                {
                    return pop_back();
                }

                if(tmp1 == NULL)   // we hit the head
                {
                    return pop_front();
                }

                if(tmp1 != NULL && tmp2 != NULL)
                {
                    tmp1->m_pNext = tmp2;
                    tmp2->m_pPrev = tmp1;
                    free(tmp);
                    m_iSize--;
                    return ret_data;
                }
            }
        }
        return NULL;
    }

    tNode * remove_raw(T data)
    {
        tNode * tmp = m_pHead;
        while(tmp != NULL)
        {
            if(tmp->Data == data)
            {
                tNode * prev = tmp->m_pPrev;
                tNode * next = tmp->m_pNext;

                if(prev != NULL)
                    prev->m_pNext = next;

                if(next != NULL)
                    next->m_pPrev = prev;

                if(tmp == m_pHead && tmp == m_pTail)
                    m_pHead = m_pTail = pPtr = NULL;

                m_iSize--;
                return tmp;
            }

            tmp = tmp->m_pNext;
        }

        return NULL;
    }

    void add_raw(tNode * node)
    {
        tNode * head  = m_pHead;
        node->m_pNext = head;
        node->m_pPrev = NULL;

        if(head != NULL)
        {
            head->m_pPrev = node;
            m_pHead       = head;
        }
        else
            m_pHead = m_pTail = node;

        m_iSize++;
    }

    T remove(T data)
    {
        tNode * tmp   = m_pHead;
        int     count = 0;

        while(tmp != NULL)
        {
            if(tmp->Data == data)
                return remove_from(count);
            else
            {
                tmp = tmp->m_pNext;
                count++;
            }
        }
        return NULL;
    }

    T operator[](int i) { return at(i); }

    void erase()
    {
        if(m_pHead == NULL && m_pTail == NULL)
            return;
        else
        {
            tNode * tmp = m_pHead;

            while(tmp != NULL)
            {
                tNode * next = tmp->m_pNext;
                free(tmp->Data);

                if(tmp->Data != NULL)
                    free(tmp);

                tmp = next;
            }
            m_pTail = NULL;
            m_pHead = NULL;
            m_iSize = 0;
        }
    }

    void set_ptr(T data)
    {
        tNode * find = m_pHead;

        while(find != NULL)
        {
            if(find->Data == data)
            {
                pPtr = find;
                return;
            }
            else
                find = find->m_pNext;
        }

        pPtr = NULL;
    }

    T next()
    {
        if(pPtr != NULL)
        {
            pPtr = pPtr->m_pNext;
            if(pPtr)
                return pPtr->Data;
        }

        return NULL;
    }

    T prev()
    {
        if(pPtr != NULL)
        {
            pPtr = pPtr->m_pPrev;
            if(pPtr)
                return pPtr->Data;
        }

        return NULL;
    }

    T ptr()
    {
        if(pPtr != NULL)
            return pPtr->Data;

        return NULL;
    }

    int size() { return m_iSize; }
    T   begin()
    {
        if(m_pHead == NULL)
            return NULL;

        return m_pHead->Data;
    }
    T end()
    {
        if(m_pTail == NULL)
            return NULL;

        return m_pTail->Data;
    }
};

#endif