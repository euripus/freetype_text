#include "GUI.h"

CGUI::CGUI()
{
    m_pDesktop = NULL;

#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - GUI: Initialized.\n");
#endif
}

CGUI::~CGUI()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - GUI: Exiting.\n");
#endif

    OnDestroy();
}

void CGUI::OnDraw()
{
    ProcessMessages();

    if(m_pDesktop != NULL)
        m_pDesktop->OnDraw();
}

int CGUI::Parse(TiXmlNode * this_node, string filename)
{
    TiXmlElement * element = NULL;
    TiXmlNode *    node    = NULL;
    char const *   value   = NULL;

    TiXmlDocument doc;
    bool          bExternalLoad = false;

    // If a user passed a filename, use it as an external link to our data for this element
    if(filename != "")
    {
        if(!doc.LoadFile(filename.c_str()))   // Try to parse data using given filename
        {
#ifdef USE_GLOBAL_LOGGER
            CGlobalLogger::GetSingleton().Write(
                "GUI Framework - Parsing Failed! Element Type: %d, TinyXML Error: %s\n", GUI,
                doc.ErrorDesc());
#endif

            return 0;
        }

        node          = doc.FirstChild();   // Aquire first data node
        bExternalLoad = true;
    }

    if(this_node != NULL)
    {
        element = this_node->ToElement();

        if(element->Attribute("Filename") != NULL)
        {
            if(!doc.LoadFile(element->Attribute("Filename")))
            {
#ifdef USE_GLOBAL_LOGGER
                CGlobalLogger::GetSingleton().Write(
                    "GUI Framework - Remote File Parsing Failed! Element Type: %d, TinyXML Error: %s\n", GUI,
                    doc.ErrorDesc());
#endif

                return 0;
            }

            node          = doc.FirstChild();
            bExternalLoad = true;
        }
    }

    if(bExternalLoad)
    {
        element = node->ToElement();

        value = element->Attribute("TexturesDatabase");
        if(value != NULL)
        {
            CTextureManager::GetSingleton().Parse(NULL, (char *)value);
            value = NULL;
        }

        value = element->Attribute("MaterialsDatabase");
        if(value != NULL)
        {
            CMaterialManager::GetSingleton().Parse(NULL, (char *)value);
            value = NULL;
        }

        Parse(node, "");
    }
    else
    {
        int viewport[4];
        glGetIntegerv(GL_VIEWPORT, viewport);

        element = this_node->ToElement();

        value = element->Attribute("TexturesDatabase");
        if(value != NULL)
        {
            CTextureManager::GetSingleton().Parse(NULL, (char *)value);
            m_TexturesDb = value;

            value = NULL;
        }

        value = element->Attribute("MaterialsDatabase");
        if(value != NULL)
        {
            CMaterialManager::GetSingleton().Parse(NULL, (char *)value);
            m_MaterialsDb = value;

            value = NULL;
        }

        TiXmlNode * child_node = NULL;
        child_node             = this_node->FirstChild();

        while(child_node != NULL)
        {
            CGUIElement * newElement = NULL;
            if(stricmp(child_node->Value(), "element") == 0)   // We got a simple element
                newElement = new CGUIElement;
            if(stricmp(child_node->Value(), "static") == 0)   // We got a static control
                newElement = new CGUIStatic;

            if(newElement->Parse(child_node, ""))
            {
                // Each desktop will have a full screen for its needs
                newElement->SetRect(tRect(0, viewport[2], viewport[3], 0));
                newElement->m_RestrictionFlags.m_iFlag2 = RestrictMoveX;
                newElement->m_RestrictionFlags.m_iFlag3 = RestrictMoveY;

                newElement->SetType(GUI);
                m_lstGUI.push_back(newElement);
                m_pDesktop = newElement;
            }
            else
                delete newElement;

            child_node = this_node->IterateChildren(child_node);
        }
    }

    m_pXMLNode = this_node;
    if(this_node == NULL)
        m_pXMLNode = node;

    return 1;
}

int CGUI::Save(string filename)
{
    TiXmlDocument doc;

    TiXmlElement root("GUI");

    char const value[256] = "";

    if(m_TexturesDb != "")
        root.SetAttribute("TexturesDatabase", (char *)m_TexturesDb.c_str());

    if(m_MaterialsDb != "")
        root.ToElement()->SetAttribute("MaterialsDatabase", (char *)m_MaterialsDb.c_str());

    doc.SaveFile(filename.c_str());

    CGUIElement * gui = m_lstGUI.begin();
    m_lstGUI.set_ptr(gui);

    while(gui != NULL)
    {
        gui->Save(&root, NULL);
        gui = m_lstGUI.next();
    }

    doc.InsertEndChild(root);
    doc.SaveFile(filename.c_str());

    return 1;
}

CGUIElement * CGUI::GetGUI(int index)
{
    if(index == -1)
        return m_pDesktop;
    else
    {
        if(index < m_lstGUI.size())
            return m_lstGUI.at(index);
    }

    return NULL;
}

CGUIElement * CGUI::GetElementByXML(TiXmlNode * node)
{
    CGUIElement * child = m_lstGUI.begin();
    m_lstGUI.set_ptr(child);

    while(child != NULL)
    {
        CGUIElement * found = child->FindChild(node);
        if(found)
            return found;

        child = m_lstGUI.next();
    }

    return NULL;
}

void CGUI::ProcessMessages()
{
    if(m_pDesktop == NULL)
        return;

    tMessage * msg = m_pDesktop->GetEventHandler()->GetNextMsg();
    while(msg != NULL)
    {
        switch(msg->m_eMsg)
        {
            case AppResize:
                {
                    int viewport[4];
                    glGetIntegerv(GL_VIEWPORT, viewport);
                    m_pDesktop->SetRect(tRect(0, viewport[2], viewport[3], 0));

                    break;
                }
        }

        msg = m_pDesktop->GetEventHandler()->GetNextMsg(msg);
    }
}

void CGUI::OnDestroy()
{
    m_lstGUI.erase();
}
