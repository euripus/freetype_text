// TextureManager.cpp: implementation of the CTextureManager class.
//
//////////////////////////////////////////////////////////////////////

#include "TextureManager.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTextureManager::CTextureManager()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - Texture Manager: Initialized.\n");
#endif
}

CTextureManager::~CTextureManager()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - Texture Manager: Exiting.\n");
#endif
    m_lstTextureDb.erase();
    m_lstTextures.erase();
}

int CTextureManager::GetTextureCount()
{
    return m_lstTextures.size();
}

int CTextureManager::Parse(TiXmlNode * parent_node, char * filename)
{
    int tex_count = 0;

    char const *   value = NULL, *tex_filename = NULL;
    TiXmlElement * tex_element = NULL;
    TiXmlNode *    tex_node    = NULL;

    TiXmlDocument doc(filename);

    if(filename != NULL)
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return tex_count;

        tex_node = doc.FirstChildElement();
    }
    else
        tex_node = parent_node->FirstChild();

    if(tex_node == NULL)
        return tex_count;

    while(tex_node != NULL)
    {
        tex_element = tex_node->ToElement();
        if(stricmp(tex_element->Value(), "texture") == 0)
        {
            tex_filename = tex_element->Attribute("Filename");
            if(!(tex_filename == NULL || strlen(tex_filename) == 0))
            {
                tTexture * newTexture = NULL;
                tTexture * exists     = CTextureManager::GetSingleton().GetTexture((char *)value);
                if(exists == NULL)
                {
                    newTexture = new tTexture;

                    TiXmlElement * child_element = NULL;
                    TiXmlNode *    child_node    = tex_element->FirstChild();
                    int            count         = 0;
                    while(child_node != NULL)
                    {
                        if(stricmp(child_node->Value(), "texparam") == 0)
                            count++;

                        child_node = tex_element->IterateChildren(child_node);
                    }

                    if(count > 0)
                    {
                        newTexture->m_uiTexParamCount = count;
                        if(count > 1)
                        {
                            newTexture->m_uiTexParamCount = count;
                            newTexture->m_pTexParams      = new tTexParam[count];
                        }
                        else
                            newTexture->m_pTexParams = new tTexParam;

                        child_node    = tex_element->FirstChild();
                        int cur_index = 0;
                        while(child_node != NULL)
                        {
                            child_element = child_node->ToElement();

                            value = child_element->Attribute("Target");
                            if(value == NULL)
                                break;
                            else
                            {
                                if((stricmp(value, "GL_TEXTURE_2D") == 0) || (stricmp(value, "2D") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiTarget = GL_TEXTURE_2D;
                                else if((stricmp(value, "GL_TEXTURE_1D") == 0) || (stricmp(value, "1D") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiTarget = GL_TEXTURE_1D;
                                value = NULL;
                            }

                            value = child_element->Attribute("Name");
                            if(value == NULL)
                                break;
                            else
                            {
                                if((stricmp(value, "GL_TEXTURE_MIN_FILTER") == 0)
                                   || (stricmp(value, "MIN_FILTER") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiName = GL_TEXTURE_MIN_FILTER;
                                else if((stricmp(value, "GL_TEXTURE_MAG_FILTER") == 0)
                                        || (stricmp(value, "MAG_FILTER") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiName = GL_TEXTURE_MAG_FILTER;
                                else if((stricmp(value, "GL_TEXTURE_WRAP_S") == 0)
                                        || (stricmp(value, "WRAP_S") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiName = GL_TEXTURE_WRAP_S;
                                else if((stricmp(value, "GL_TEXTURE_WRAP_T") == 0)
                                        || (stricmp(value, "WRAP_T") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiName = GL_TEXTURE_WRAP_T;

                                value = NULL;
                            }

                            value = child_element->Attribute("Value");
                            if(value == NULL)
                                break;
                            else
                            {
                                if((stricmp(value, "GL_NEAREST") == 0) || (stricmp(value, "NEAREST") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_NEAREST;
                                else if((stricmp(value, "GL_LINEAR") == 0) || (stricmp(value, "LINEAR") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_LINEAR;
                                else if((stricmp(value, "GL_NEAREST_MIPMAP_NEAREST") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_NEAREST_MIPMAP_NEAREST;
                                else if((stricmp(value, "GL_LINEAR_MIPMAP_NEAREST") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_LINEAR_MIPMAP_NEAREST;
                                else if((stricmp(value, "GL_NEAREST_MIPMAP_LINEAR") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_NEAREST_MIPMAP_LINEAR;
                                else if((stricmp(value, "GL_LINEAR_MIPMAP_LINEAR") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_LINEAR_MIPMAP_LINEAR;
                                else if((stricmp(value, "GL_REPEAT") == 0) || (stricmp(value, "REPEAT") == 0))
                                    newTexture->m_pTexParams[cur_index].m_uiParam = GL_REPEAT;

                                value = NULL;
                            }

                            child_node = tex_element->IterateChildren(child_node);
                            cur_index++;
                        }
                    }

                    if(::LoadTexture((char *)tex_filename, newTexture))
                    {
#ifdef USE_GLOBAL_LOGGER
                        CGlobalLogger::GetSingleton().Write(
                            "GUI Framework - Texture Manager: Texture Loaded Successfully (%s).\n",
                            newTexture->m_strFilename);
#endif

                        tex_count++;

                        value = NULL;
                        value = tex_element->Attribute("RefID");
                        if(value != NULL)
                        {
                            tTextureEntry * newEntry = new tTextureEntry;
                            newEntry->m_iDbID        = atoi(value);
                            newEntry->m_pTexture     = newTexture;
                            m_lstTextureDb.push_back(newEntry);

                            value = NULL;
                        }

                        value        = NULL;
                        tex_filename = NULL;
                        tRGBA mask;
                        value = tex_element->Attribute("Mask");
                        if(value != NULL)
                        {
                            int r = -1, g = -1, b = -1;
                            sscanf(value, "%d,%d,%d", &r, &g, &b);

                            if(r != -1 && g != -1 && b != -1)
                            {
                                mask.m_fR = (float)r / 255.0f;
                                mask.m_fG = (float)g / 255.0f;
                                mask.m_fB = (float)b / 255.0f;

                                CreateAlpha(newTexture, mask);
                                newTexture->m_MaskTexID = 1;
                            }

                            value = NULL;
                        }

                        m_lstTextures.push_back(newTexture);
                    }
                    else
                    {
#ifdef USE_GLOBAL_LOGGER
                        CGlobalLogger::GetSingleton().Write(
                            "GUI Framework - Texture Manager: Unable to load texture! (%s)\n", (char *)value);
#endif
                    }
                }
                else
                {
                    value = NULL;
                    value = tex_element->Attribute("RefID");
                    if(value != NULL)
                    {
                        if(CTextureManager::GetSingleton().GetTexture(-1, atoi(value), -1) == NULL)
                        {
                            tTextureEntry * newEntry = new tTextureEntry;
                            newEntry->m_iDbID        = atoi(value);
                            newEntry->m_pTexture     = exists;
                            m_lstTextureDb.push_back(newEntry);
                        }

                        value = NULL;
                    }
                }
            }
        }

        if(parent_node == NULL)
            tex_node = doc.IterateChildren(tex_node);
        else
            tex_node = parent_node->IterateChildren(tex_node);
    }

    return tex_count;
}

tTexture * CTextureManager::GetTexture(int index, int db_index, int gl_tex_id)
{
    if(db_index == -1 && gl_tex_id == -1 && index != -1)   // by index
    {
        tTexture * tex = m_lstTextures.begin();
        m_lstTextures.set_ptr(tex);

        int count = 0;
        while(tex != NULL)
        {
            if(index == count)
                return tex;

            tex = m_lstTextures.next();
            count++;
        }
    }
    else if(index == -1 && gl_tex_id == -1 && db_index != -1)
    {
        tTextureEntry * tex_entry = m_lstTextureDb.begin();
        m_lstTextureDb.set_ptr(tex_entry);

        while(tex_entry != NULL)
        {
            if(tex_entry->m_iDbID == db_index)
                return tex_entry->m_pTexture;

            tex_entry = m_lstTextureDb.next();
        }
    }
    else if(index == -1 && db_index == -1 && gl_tex_id != -1)
    {
        tTexture * tex = m_lstTextures.begin();
        m_lstTextures.set_ptr(tex);

        while(tex != NULL)
        {
            if(tex->m_id == gl_tex_id)
                return tex;

            tex = m_lstTextures.next();
        }
    }

    return NULL;
}

tTexture * CTextureManager::GetTexture(char const * filename)
{
    if(filename == NULL)
        return NULL;

    if(strlen(filename) == 0)
        return NULL;

    tTexture * tex = m_lstTextures.begin();
    m_lstTextures.set_ptr(tex);

    while(tex != NULL)
    {
        if(strstr(tex->m_strFilename, filename) != NULL)
            return tex;

        tex = m_lstTextures.next();
    }

    return NULL;
}

bool CTextureManager::RemoveTexture(tTexture * tex)
{
    if(tex == NULL)
        return false;

    tTexture * to_be_removed = m_lstTextures.remove(tex);
    if(to_be_removed != NULL)
    {
        tTextureEntry * entry_with_tex_ptr = m_lstTextureDb.begin();
        m_lstTextureDb.set_ptr(entry_with_tex_ptr);

        while(entry_with_tex_ptr != NULL)
        {
            if(entry_with_tex_ptr->m_pTexture == to_be_removed)
                delete m_lstTextureDb.remove(entry_with_tex_ptr);

            entry_with_tex_ptr = m_lstTextureDb.next();
        }

        delete to_be_removed;
        return true;
    }

    return false;
}