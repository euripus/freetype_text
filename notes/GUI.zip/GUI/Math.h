#include <float.h>   // for min/max

#include "Vector3.h"
#include "Vector4.h"
