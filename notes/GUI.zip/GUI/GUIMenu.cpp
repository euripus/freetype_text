#include "GUI.h"

CGUIMenu::CGUIMenu()
{
    SetType(Menu);

    for(int i = 0; i < MENU_MAX_SUBS; i++)
        m_piListExp[i] = NULL;

    m_iMaxLen       = MENU_MAX_SUBS;
    m_iLastExpanded = -1;
}

CGUIMenu::~CGUIMenu() {}

int CGUIMenu::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIButton::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    TiXmlElement * element = NULL;
    TiXmlNode *    node    = m_pXMLNode;
    char const *   value   = NULL;

    element = m_pXMLNode->ToElement();

    // Load menu type here (whether it's expanded onmouseover, or onlmousedown, or whatever)
    // Also load the way it expands
    // The menu don't have it's own rectangle to draw, only it's children! (True only for popup menu!)
    // RemoveChild(FindChild(Border));

    /*
    value = element->Attribute("EqualSized");
    if(value !=NULL)
    {
        if(stricmp(value, "true") == 0 || atoi(value) == 1)
            m_iListType = 1;

        value = NULL;
    }

    value = element->Attribute("CurSel");
    if(value !=NULL)
    {
        if(atoi(value) !=-1)
            SetCurSel(atoi(value));

        value = NULL;
    }
    */

    // OK, now count the total max number of expandable elements

    HideSiblings();
    return 1;
}

int CGUIMenu::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("Menu");

    if(this_element != NULL)
        element = this_element;

    if(this_element != NULL)
        CGUIButton::Save(NULL, this_element);
    else
    {
        CGUIButton::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIMenu::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);

    while(tmp != NULL)
    {
        switch(tmp->m_eMsg)
        {
            case ButtonPressed:
                {
                    if(tmp->m_pSender == this)
                    {
                        if(m_iLastExpanded == -1)
                            Expand(this);
                        else
                            Collapse(this);

                        GetEventHandler()->RemoveMessage(tmp);
                        tmp = NULL;
                    }

                    break;
                }
        }

        tmp = GetEventHandler()->GetNextMsg(tmp);
    }
}

void CGUIMenu::Expand(CGUIElement * child)
{
    // The general format of this thing is:
    // A Menu is simply (normal menu) a droplist, so
    // here how it looks like:
    /*

        Entry #1
        Entry #2 - >	Sub #2 - Entry #1
        Entry #3		Sub #2 - Entry #2 ->	Sub #2 Sub #2 - Entry #1
        ...				Sub #2 - Entry #3		Sub #2 Sub #2 - Entry #2
        ...										Sub #2 Sub #2 - Entry #1
        ETC

        So, how we are tracking the expanded ones? Simple!
        If for example, we actually showing menu, and it's sub-menu 2, then m_piListExp[0] will be equal to
       child(1) (2 - 1) Or if we are showing Sub 2 Sub2, then our m_piListExp will be [child(1)][child(1)]...
        It stores the sequential pointers of children that are expanded
        If it is collapsing, then all its sub-children will be collapsed
    */
    // Aquire the current
    // Nothing to expand, exit the function because what, we going to expand border??? LOL
    int child_count = child->GetChildCount();
    if(child->FindChild(Border) != NULL)
        child_count--;

    int PrevDisplacementX = 0, PrevDisplacementY = 0;

    if(child_count > 0)   // Do not count border
    {
        for(int i = 0; i < child_count; i++)
        {
            CGUIElement * sub_child      = child->GetChild(i);
            tRect         child_rect     = sub_child->GetRect();
            tRect         new_child_rect = child->GetRect();

            if(child == this)
            {
                if(child->m_ReservedFlags.m_iFlag2 == Menu_ExpandNegY)   // Down
                    PrevDisplacementY += -(child_rect.m_iTop - child_rect.m_iBottom);
                else if(child->m_ReservedFlags.m_iFlag2 == Menu_ExpandPosY)   // Up
                    PrevDisplacementY += child_rect.m_iTop - child_rect.m_iBottom;

                if(child->m_ReservedFlags.m_iFlag1 == Menu_ExpandPosX)   // Right
                    PrevDisplacementX = child_rect.m_iRight - child_rect.m_iLeft;
                else if(child->m_ReservedFlags.m_iFlag1 == Menu_ExpandNegX)   // Left
                    PrevDisplacementX = -(child_rect.m_iRight - child_rect.m_iLeft);

                new_child_rect.m_iLeft  = PrevDisplacementX + child->GetRect().m_iLeft;
                new_child_rect.m_iRight = new_child_rect.m_iLeft + (child_rect.m_iRight - child_rect.m_iLeft);
                new_child_rect.m_iTop   = PrevDisplacementY + child->GetRect().m_iTop;
                new_child_rect.m_iBottom = new_child_rect.m_iTop - (child_rect.m_iTop - child_rect.m_iBottom);
            }
            else
            {
                if(child->m_ReservedFlags.m_iFlag1 == Menu_ExpandPosX)   // Right
                    PrevDisplacementX = child_rect.m_iRight - child_rect.m_iLeft;
                else if(child->m_ReservedFlags.m_iFlag1 == Menu_ExpandNegX)   // Left
                    PrevDisplacementX = -(child_rect.m_iRight - child_rect.m_iLeft);

                new_child_rect.m_iLeft  = PrevDisplacementX + child->GetRect().m_iLeft;
                new_child_rect.m_iRight = new_child_rect.m_iLeft + (child_rect.m_iRight - child_rect.m_iLeft);
                new_child_rect.m_iTop   = PrevDisplacementY + child->GetRect().m_iTop;
                new_child_rect.m_iBottom = new_child_rect.m_iTop - (child_rect.m_iTop - child_rect.m_iBottom);

                if(child->m_ReservedFlags.m_iFlag2 == Menu_ExpandNegY)   // Down
                    PrevDisplacementY += -(child_rect.m_iTop - child_rect.m_iBottom);
                else if(child->m_ReservedFlags.m_iFlag2 == Menu_ExpandPosY)   // Up
                    PrevDisplacementY += child_rect.m_iTop - child_rect.m_iBottom;
            }

            sub_child->SetRect(new_child_rect);
            sub_child->Show();
        }

        m_iLastExpanded++;
        m_piListExp[m_iLastExpanded] = child;
    }
}

void CGUIMenu::Collapse(CGUIElement * child)
{
    for(int i = 0; i < m_iMaxLen; i++)
    {
        if(m_piListExp[i] == child)
        {
            child->HideSiblings();
            m_piListExp[i]  = NULL;
            m_iLastExpanded = i - 1;
            break;
        }
    }
}

void CGUIMenu::OnDraw()
{
    // This is the hardest to understand logic, so take your time
    if(CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag0 == MouseOver && m_iLastExpanded >= 0)
    {
        // Let's aquire the last expanded item
        CGUIElement * last_expand = m_piListExp[m_iLastExpanded];
        CGUIElement * prev_expand = NULL;

        // Our menu (By Example)
        /*
            Entry #1 - >	Sub #1 - Entry #1
            Entry #2		Sub #1 - Entry #2 ->	Sub #1 Sub #2 - Entry #1
            Entry #3								Sub #1 Sub #2 - Entry #2
            ...
            ...
            ETC
        */

        // Let's say, our last expansion is Sub #2 Entry #2
        // And our mouse is over Entry #2
        // So, we are looking through whole menu (starting from root)
        // and finding out that if a mouse is over a child that has a less depth value (e.g Entry #1 has depth
        // of 0, Sub #1 Entry #1 has 1, etc) and if it is, we rolling back our selection to the least depth of
        // the element the mouse is currently over So, we are going to rollback to Root if a mouse is over
        // Entry #1 (depth 0), or if our mouse is over Sub #1 Entry #1, we are rolling back to depth 1

        for(int i = 0; i < m_iLastExpanded; i++)   // Loop through all expanded nodes
        {
            prev_expand = m_piListExp[i];

            if(prev_expand != NULL)   // Assure there's no some error
            {
                for(int j = 0; j < prev_expand->GetChildCount(); j++)
                {
                    CGUIElement * child = prev_expand->GetChild(
                        j);   // Loop through each child and find if mouse is over some element of that node
                    if(child->GetType() != Border && child != last_expand)
                    {
                        if(PointInRect(child->GetRect(), CGUIUtility::GetSingleton().GetMousePos().x,
                                       CGUIUtility::GetSingleton().GetMousePos().y))
                        {
                            Collapse(last_expand);   // OK, the selection has changed, collapse current node
                            break;
                        }
                    }
                }
            }
        }

        for(i = 0; i < last_expand->GetChildCount(); i++)
        {
            CGUIElement * child = last_expand->GetChild(i);
            if(child->GetType() != Border
               && PointInRect(child->GetRect(), CGUIUtility::GetSingleton().GetMousePos().x,
                              CGUIUtility::GetSingleton().GetMousePos().y))
                Expand(child);
        }
    }

    CGUIButton::OnDraw();
}

CGUIElement * CGUIMenu::GetLastExpanded(CGUIElement * root, int index)
{
    return m_piListExp[m_iLastExpanded];
}

/*
OK, so how we are going to do it?
With OnLMouseDown we are going to catch the expansion of the root element
and with OnMouseOver we are going to expand the child it's floating over
When a child K of parent P is expanded, and a mouse is floating over some other child N of parent P,
the child K is collapsed (and all his sub-children that may be expanded) and child N is expanded instead.
How are we going to track the children that are expanded currently?
Well, each time a child is expanded, it's added to the list of m_piListExp
*/