// MaterialManager.h: interface for the CMaterialManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATERIALMANAGER_H__D517E860_D1C7_4FD8_A95C_E137F1A6EE0F__INCLUDED_)
#define AFX_MATERIALMANAGER_H__D517E860_D1C7_4FD8_A95C_E137F1A6EE0F__INCLUDED_

#include "TextureManager.h"

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

//! Material Entry Structure
/*!
    A MaterialManager entry that contains data to store/retrieve material.
*/
struct tMaterialEntry
{
    tMaterial *  m_pMaterial;      //! Material pointer (in database)
    unsigned int m_iDbID;          //! Material Database UID
    char         m_strName[128];   //! Material name (user name)

    tMaterialEntry()
    {
        m_iDbID = 0;
        ZeroMemory(m_strName, 128);
        m_pMaterial = NULL;
    };
};

//! Material manager class
/*!
    Class that stores/retrieves materials by:\n\n
    Material name\n
    Material UID\n
    Index
*/
class CMaterialManager : public CSingleton<CMaterialManager>
{
public:
    virtual int Parse(TiXmlNode * node = NULL, char * filename = NULL);

    tMaterial * GetMaterial(int index, int db_index = -1);
    tMaterial * GetMaterial(char const * name);

    bool RemoveMaterial(tMaterial * mat);

    int GetMaterialDbID(tMaterial * mat);

    int GetMaterialCount();

    CMaterialManager();
    virtual ~CMaterialManager();

private:
    CDoubleList<tMaterialEntry *> m_lstMaterialDb;   //! List of material entries (there can be more than one
                                                     //! material entry for 1 material)
    CDoubleList<tMaterial *> m_lstMaterials;         //! List of actual materials
};

#endif   // !defined(AFX_MATERIALMANAGER_H__D517E860_D1C7_4FD8_A95C_E137F1A6EE0F__INCLUDED_)
