#include "GUI.h"

CGUIElement::CGUIElement()
{
    m_pXMLNode = NULL;
    m_Rect     = tRect(0, 0, 0, 0);
    m_Color    = tRGBA(0.75, 0.75, 0.5);
    m_pParent  = NULL;
    SetType(Simple);
    m_pBackgroundMaterial = NULL;
    m_bVisible            = true;
    m_pHEvent             = NULL;

    m_fTexCoord[0].x = 0;
    m_fTexCoord[0].y = 1;

    m_fTexCoord[1].x = 1;
    m_fTexCoord[1].y = 1;

    m_fTexCoord[2].x = 1;
    m_fTexCoord[2].y = 0;

    m_fTexCoord[3].x = 0;
    m_fTexCoord[3].y = 0;

    m_iElementID = 0;

    m_RestrictionFlags.m_iFlags[0] = m_RestrictionFlags.m_iFlags[1] = m_RestrictionFlags.m_iFlags[2] =
        m_RestrictionFlags.m_iFlags[3]                              = Default;

    memset((void *)m_strExternRef, 0, 256);
}

CGUIElement::~CGUIElement()
{
    OnDestroy();
}

void CGUIElement::HideSiblings(int deep)
{
    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->GetType() != Border)
        {
            tmp->Hide();
            if(deep > 0)
                tmp->HideSiblings(deep - 1);
            else if(deep == -1)
                tmp->HideSiblings(deep);
            else if(deep == 0)
                return;
        }

        tmp = m_lstChildren.next();
    }
}

void CGUIElement::ShowSiblings(int deep)
{
    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(deep > 0)
        {
            tmp->Show();
            tmp->ShowSiblings(deep - 1);
        }
        else if(deep == -1)
        {
            tmp->Show();
            tmp->ShowSiblings(deep);
        }
        else if(deep == 0)
            return;

        tmp = m_lstChildren.next();
    }
}

void CGUIElement::Show()
{
    m_bVisible = true;
}

void CGUIElement::Hide()
{
    m_bVisible = false;
}

bool CGUIElement::Visible()
{
    return m_bVisible;
}

int CGUIElement::OnCreate(CGUIElement * parent, tRect * rect)
{
    m_pParent = parent;

    if(rect != NULL)
        OnSize(*rect);

    return 1;
}

/******************************************* NEW !!!!!
 * ***************************************************************/
// This function parses XML node data into the element attributes: colour, textures, state etc
// Filename is also required if no node reference is passed.
int CGUIElement::Parse(TiXmlNode * this_node, string filename)
{
    if(this_node == NULL && filename == "")
        return -1;

    bool bExternalLoad = false;

    char const *   value   = NULL;
    TiXmlElement * element = NULL;
    TiXmlNode *    node    = NULL;
    TiXmlDocument  doc;

    if(filename != "")
    {
        if(!doc.LoadFile(filename.c_str()))
            return 0;

        node = doc.FirstChild();
        strncpy(m_strExternRef, filename.c_str(), 256);

        bExternalLoad = true;
    }

    if(this_node != NULL)
    {
        element = this_node->ToElement();

        if(element->Attribute("Filename") != NULL)
        {
            if(!doc.LoadFile(element->Attribute("Filename")))
            {
#ifdef USE_GLOBAL_LOGGER
                CGlobalLogger::GetSingleton().Write("GUI Framework - Parsing Failed! Element Type: %d, Error "
                                                    "Desc.: Unable to parse remote file(%s)!\n",
                                                    GetType(), element->Attribute("Filename"));
#endif

                return 0;
            }

            node = doc.FirstChild();
            strncpy(m_strExternRef, element->Attribute("Filename"), 256);
            bExternalLoad = true;
        }
    }

    if(bExternalLoad)
    {
        if(!Parse(node, ""))
        {
#ifdef USE_GLOBAL_LOGGER
            CGlobalLogger::GetSingleton().Write("GUI Framework - Parsing Failed! Element Type: %d, Error "
                                                "Desc.: Unable to parse XML Node(File: %s, Node: %s)!\n",
                                                GetType(), node->ToElement()->Attribute("Filename"),
                                                node->ToElement()->Value());
#endif

            return 0;
        }

        TiXmlNode * child_node = NULL;

        if(this_node != NULL)
        {
            child_node = this_node->FirstChild();

            while(child_node != NULL)
            {
                CGUIElement * newElement = NULL;
                if(stricmp(child_node->Value(), "element") == 0)   // We got a simple element
                    newElement = new CGUIElement;
                else if(stricmp(child_node->Value(), "static") == 0)   // We got a static control
                    newElement = new CGUIStatic;
                else if(stricmp(child_node->Value(), "textbox") == 0)   // We got a static control
                    newElement = new CGUITextBox;
                else if(stricmp(child_node->Value(), "button") == 0)   // We got a button
                    newElement = new CGUIButton;
                else if(stricmp(child_node->Value(), "radiogroup") == 0)   // We got radio group
                    newElement = new CGUIRadioGroup;
                else if(stricmp(child_node->Value(), "progressbar") == 0)   // We got progress bar
                    newElement = new CGUIProgressBar;
                else if(stricmp(child_node->Value(), "scrollbar") == 0)   // We got scroll bar
                    newElement = new CGUIScrollBar;
                else if(stricmp(child_node->Value(), "droplist") == 0)   // We got droplist
                    newElement = new CGUIDropList;
                else if(stricmp(child_node->Value(), "listbox") == 0)   // We got listbox
                    newElement = new CGUIListBox;
                else if(stricmp(child_node->Value(), "tabcontrol") == 0)   // We got tab control
                    newElement = new CGUITabControl;
                else if(stricmp(child_node->Value(), "menu") == 0)   // We got menu (std, not popup)
                    newElement = new CGUIMenu;
                else if(stricmp(child_node->Value(), "window") == 0)   // We got menu (std, not popup)
                    newElement = new CGUIWindow;

                if(newElement != NULL)
                {
                    newElement->OnCreate(this, NULL);
                    if(newElement->Parse(child_node, ""))
                        AddChild(newElement);
                    else
                        SAFEDEL(newElement)
                }

                child_node = this_node->IterateChildren(child_node);
            }
        }
    }
    else
    {
        TiXmlNode * child_node = NULL;

        if(this_node != NULL)
        {
            child_node = this_node->FirstChild();

            while(child_node != NULL)
            {
                CGUIElement * newElement = NULL;
                if(stricmp(child_node->Value(), "element") == 0)   // We got a simple element
                    newElement = new CGUIElement;
                else if(stricmp(child_node->Value(), "static") == 0)   // We got a static control
                    newElement = new CGUIStatic;
                else if(stricmp(child_node->Value(), "textbox") == 0)   // We got a static control
                    newElement = new CGUITextBox;
                else if(stricmp(child_node->Value(), "button") == 0)   // We got a button
                    newElement = new CGUIButton;
                else if(stricmp(child_node->Value(), "radiogroup") == 0)   // We got radio group
                    newElement = new CGUIRadioGroup;
                else if(stricmp(child_node->Value(), "progressbar") == 0)   // We got progress bar
                    newElement = new CGUIProgressBar;
                else if(stricmp(child_node->Value(), "scrollbar") == 0)   // We got scroll bar
                    newElement = new CGUIScrollBar;
                else if(stricmp(child_node->Value(), "droplist") == 0)   // We got droplist
                    newElement = new CGUIDropList;
                else if(stricmp(child_node->Value(), "listbox") == 0)   // We got listbox
                    newElement = new CGUIListBox;
                else if(stricmp(child_node->Value(), "tabcontrol") == 0)   // We got tab control
                    newElement = new CGUITabControl;
                else if(stricmp(child_node->Value(), "menu") == 0)   // We got menu (std, not popup)
                    newElement = new CGUIMenu;
                else if(stricmp(child_node->Value(), "window") == 0)   // We got menu (std, not popup)
                    newElement = new CGUIWindow;

                if(newElement != NULL)
                {
                    newElement->OnCreate(this, NULL);
                    if(newElement->Parse(child_node, ""))
                        AddChild(newElement);
                    else
                        SAFEDEL(newElement)
                }

                child_node = this_node->IterateChildren(child_node);
            }
        }
    }

    m_pXMLNode = this_node;
    if(this_node == NULL)
        m_pXMLNode = node;

    element = NULL;
    value   = NULL;

    element = m_pXMLNode->ToElement();

    // Parse our element' rectangle data
    value = element->Attribute("Rect");

    if(value != NULL)
    {
        tRect NewRect;

        sscanf(value, "%d,%d,%d,%d", &NewRect.m_iLeft, &NewRect.m_iRight, &NewRect.m_iTop,
               &NewRect.m_iBottom);
        OnSize(NewRect);
        value = NULL;   // Nullify pointer - precaution measures
    }

    // Alternative XML check if user wants to store data this way <Element m_iLeft="200" m_iRight="300" etc..
    // />
    if(element->Attribute("Left") != NULL && element->Attribute("Right") != NULL
       && element->Attribute("Top") != NULL && element->Attribute("Bottom") != NULL)
    {
        tRect NewRect;

        NewRect.m_iLeft   = atoi(element->Attribute("Left"));
        NewRect.m_iRight  = atoi(element->Attribute("Right"));
        NewRect.m_iTop    = atoi(element->Attribute("Top"));
        NewRect.m_iBottom = atoi(element->Attribute("Bottom"));

        OnSize(NewRect);
    }

    if(m_pXMLNode != NULL && !bExternalLoad)
    {
        if((m_Rect.m_iBottom == 0) && (m_Rect.m_iTop == 0) && (m_Rect.m_iLeft == 0) && (m_Rect.m_iRight == 0))
        {
            if(GetType() != GUI && GetType() != Border && GetType() != Caret)
            {
#ifdef USE_GLOBAL_LOGGER
                if(GetParent() != NULL)
                {
                    if(GetParent()->GetType() != Border)
                        CGlobalLogger::GetSingleton().Write("GUI Framework - Warning: Rectangle not "
                                                            "specified! (File: %s, Node: %s, Parent: %d)\n",
                                                            element->Attribute("Filename"), element->Value(),
                                                            GetParent()->GetType());
                }
#endif
            }
        }
    }

    value = element->Attribute("ID");
    if(value != NULL)
    {
        m_iElementID = atoi(value);
        value        = NULL;
    }

    value = element->Attribute("BorderFile");
    if(value != NULL)
    {
        CGUIElement * tmp = m_lstChildren.begin();
        m_lstChildren.set_ptr(tmp);

        while(tmp != NULL)
        {
            if(tmp->GetType() == Border)
                break;

            tmp = m_lstChildren.next();
        }

        CGUIBorder * newBorder = new CGUIBorder;
        newBorder->OnCreate(this, NULL);

        if(newBorder->Parse(NULL, (char *)value))
            m_lstChildren.push_back(newBorder);
        else
            delete newBorder;

        value = NULL;
    }

    value = element->Attribute("RestrictMoveX");
    if(value != NULL)
    {
        int mx = 0, my = 0;
        if(stricmp(value, "yes") == 0 || stricmp(value, "1") == 0)
            m_RestrictionFlags.m_iFlag2 = RestrictMoveX;

        value = NULL;
    }

    value = element->Attribute("RestrictMoveY");
    if(value != NULL)
    {
        int mx = 0, my = 0;
        if(stricmp(value, "yes") == 0 || stricmp(value, "1") == 0)
            m_RestrictionFlags.m_iFlag3 = RestrictMoveY;

        value = NULL;
    }

    value = element->Attribute("Color");
    if(value != NULL)
    {
        sscanf(value, "%f,%f,%f", &m_Color.m_fR, &m_Color.m_fG, &m_Color.m_fB);
        if(m_Color.m_fR > 1.0f)
            m_Color.m_fR /= 255.0f;
        if(m_Color.m_fG > 1.0f)
            m_Color.m_fG /= 255.0f;
        if(m_Color.m_fB > 1.0f)
            m_Color.m_fB /= 255.0f;
        if(m_Color.m_fA > 1.0f)
            m_Color.m_fA /= 255.0f;
        value = NULL;
    }

    // Parse UV data from XML
    value = element->Attribute("UV");
    if(value != NULL)
    {
        sscanf(value, "(%f,%f),(%f,%f),(%f,%f),(%f,%f)", &m_fTexCoord[0].x, &m_fTexCoord[0].y,
               &m_fTexCoord[1].x, &m_fTexCoord[1].y, &m_fTexCoord[2].x, &m_fTexCoord[2].y, &m_fTexCoord[3].x,
               &m_fTexCoord[3].y);

        value = NULL;
    }

    // Parse material/texture data..
    // If user specified reference ID, use it
    value = element->Attribute("MatByRefID");
    if(value != NULL)
    {
        m_pBackgroundMaterial = CMaterialManager::GetSingleton().GetMaterial(-1, atoi(value));
        value                 = NULL;
    }

    // Or if user specified the material's name, use it instead!
    value = element->Attribute("MatByName");
    if(value != NULL)
    {
        m_pBackgroundMaterial = CMaterialManager::GetSingleton().GetMaterial(value);
        value                 = NULL;
    }

    value = element->Attribute("R0");
    if(value != NULL)
    {
        m_ReservedFlags.m_iFlag0 = atoi(value);
        value                    = NULL;
    }

    value = element->Attribute("R1");
    if(value != NULL)
    {
        m_ReservedFlags.m_iFlag1 = atoi(value);
        value                    = NULL;
    }

    value = element->Attribute("R2");
    if(value != NULL)
    {
        m_ReservedFlags.m_iFlag2 = atoi(value);
        value                    = NULL;
    }

    value = element->Attribute("R3");
    if(value != NULL)
    {
        m_ReservedFlags.m_iFlag3 = atoi(value);
        value                    = NULL;
    }

    return 1;
}
/*********************************************************************************************************************/

int CGUIElement::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("Element");

    if(this_element != NULL)
        element = this_element;

    // Parse our element' rectangle data
    if(GetParent() != NULL)
    {
        if(GetParent()->GetType() != Border)
        {
            sprintf((char *)value, "%d,%d,%d,%d", GetRect().m_iLeft, GetRect().m_iRight, GetRect().m_iTop,
                    GetRect().m_iBottom);
            element->SetAttribute("Rect", value);

            memset((void *)value, 0, 128);
        }
    }

    if(FindChild(Border) != NULL)
        element->SetAttribute("BorderFile", FindChild(Border)->GetExtRef());

    if(GetID() != 0)
    {
        sprintf((char *)value, "%d", GetID());
        element->SetAttribute("ID", value);

        memset((void *)value, 0, 128);
    }

    if(m_RestrictionFlags.m_iFlag2 != Default)
        element->SetAttribute("RestrictMoveX", "1");

    if(m_RestrictionFlags.m_iFlag3 != Default)
        element->SetAttribute("RestrictMoveY", "1");

    if(m_Color.m_fR != 0.75f && m_Color.m_fG != 0.75f && m_Color.m_fB != 1.0f)
    {
        sprintf((char *)value, "%d,%d,%d", (int)(m_Color.m_fR * 255), (int)(m_Color.m_fG * 255),
                (int)(m_Color.m_fB * 255));
        element->SetAttribute("Color", value);

        memset((void *)value, 0, 128);
    }

    if((m_fTexCoord[0].x != 0 && m_fTexCoord[0].y != 1) && (m_fTexCoord[1].x != 1 && m_fTexCoord[1].y != 1)
       && (m_fTexCoord[2].x != 1 && m_fTexCoord[2].y != 0)
       && (m_fTexCoord[3].x != 0 && m_fTexCoord[3].y != 0))
    {
        sprintf((char *)value, "(%f,%f),(%f,%f),(%f,%f),(%f,%f)", m_fTexCoord[0].x, m_fTexCoord[0].y,
                m_fTexCoord[1].x, m_fTexCoord[1].y, m_fTexCoord[2].x, m_fTexCoord[2].y, m_fTexCoord[3].x,
                m_fTexCoord[3].y);

        element->SetAttribute("UV", value);

        memset((void *)value, 0, 128);
    }

    if(GetActiveMaterial() != NULL)
    {
        sprintf((char *)value, "%d", CMaterialManager::GetSingleton().GetMaterialDbID(GetActiveMaterial()));
        element->SetAttribute("MatByRefID", value);

        memset((void *)value, 0, 128);
    }

    if(m_ReservedFlags.m_iFlag0 != Default)
    {
        sprintf((char *)value, "%d", m_ReservedFlags.m_iFlag0);
        element->SetAttribute("R0", value);

        memset((void *)value, 0, 128);
    }

    if(m_ReservedFlags.m_iFlag1 != Default)
    {
        sprintf((char *)value, "%d", m_ReservedFlags.m_iFlag1);
        element->SetAttribute("R1", value);

        memset((void *)value, 0, 128);
    }

    if(m_ReservedFlags.m_iFlag2 != Default)
    {
        sprintf((char *)value, "%d", m_ReservedFlags.m_iFlag2);
        element->SetAttribute("R2", value);

        memset((void *)value, 0, 128);
    }

    if(m_ReservedFlags.m_iFlag3 != Default)
    {
        sprintf((char *)value, "%d", m_ReservedFlags.m_iFlag3);
        element->SetAttribute("R3", value);

        memset((void *)value, 0, 128);
    }

    if(this_element == NULL)
    {
        CGUIElement * elmnt = m_lstChildren.begin();
        m_lstChildren.set_ptr(elmnt);

        while(elmnt != NULL)
        {
            if(elmnt->GetType() != Border)
                elmnt->Save(element, NULL);

            elmnt = m_lstChildren.next();
        }

        parent_node->InsertEndChild(*element);
    }
    else
    {
        CGUIElement * elmnt = m_lstChildren.begin();
        m_lstChildren.set_ptr(elmnt);

        while(elmnt != NULL)
        {
            if(elmnt->GetType() != Border)
                elmnt->Save(this_element, NULL);

            elmnt = m_lstChildren.next();
        }
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIElement::OnDraw()
{
    ProcessMessages();

    if(m_bVisible)
    {
        int left   = m_Rect.m_iLeft;
        int right  = m_Rect.m_iRight;
        int top    = m_Rect.m_iTop;
        int bottom = m_Rect.m_iBottom;

        if(m_pBackgroundMaterial == NULL)
        {
            glDisable(GL_TEXTURE_2D);
            glColor3f(m_Color.m_fR, m_Color.m_fG, m_Color.m_fB);
            glBegin(GL_QUADS);
            glVertex3d(left, bottom, 0);
            glVertex3d(right, bottom, 0);
            glVertex3d(right, top, 0);
            glVertex3d(left, top, 0);
            glEnd();
        }
        else
        {
            if(m_pBackgroundMaterial->m_pTexPtr != NULL)
            {
                glEnable(GL_TEXTURE_2D);
                ApplyMaterial(m_pBackgroundMaterial, TEX_COLOR, NULL);

                if(m_pBackgroundMaterial->m_pTexPtr->m_MaskTexID == 1)
                {
                    /*
                    Texture Coordinate Orientation

                    (0,1)-------------(1,1)
                    |                 |
                    |     Image       |
                    |                 |
                    |                 |
                    (0,0)-------------(1,0)
                    */

                    glAlphaFunc(GL_GREATER, 0.0f);
                    glEnable(GL_ALPHA_TEST);

                    glBegin(GL_QUADS);
                    //				Bottom Left							Bottom Left
                    glTexCoord2f(m_fTexCoord[0].x, m_fTexCoord[0].y);
                    glVertex3d(left, bottom, 0);
                    //				Bottom Right is Bottom Left			Bottom Right
                    glTexCoord2f(m_fTexCoord[1].x, m_fTexCoord[1].y);
                    glVertex3d(right, bottom, 0);
                    //				Top Right is Bottom Right			Top Right
                    glTexCoord2f(m_fTexCoord[2].x, m_fTexCoord[2].y);
                    glVertex3d(right, top, 0);
                    //				Top Left is Top Right				Top Left
                    glTexCoord2f(m_fTexCoord[3].x, m_fTexCoord[3].y);
                    glVertex3d(left, top, 0);
                    glEnd();

                    glDisable(GL_ALPHA_TEST);
                }
                else
                {
                    glBegin(GL_QUADS);
                    //				Bottom Left							Bottom Left
                    glTexCoord2f(m_fTexCoord[0].x, m_fTexCoord[0].y);
                    glVertex3d(left, bottom, 0);
                    //				Bottom Right is Bottom Left			Bottom Right
                    glTexCoord2f(m_fTexCoord[1].x, m_fTexCoord[1].y);
                    glVertex3d(right, bottom, 0);
                    //				Top Right is Bottom Right			Top Right
                    glTexCoord2f(m_fTexCoord[2].x, m_fTexCoord[2].y);
                    glVertex3d(right, top, 0);
                    //				Top Left is Top Right				Top Left
                    glTexCoord2f(m_fTexCoord[3].x, m_fTexCoord[3].y);
                    glVertex3d(left, top, 0);
                    glEnd();
                }
            }
            else
            {
                ApplyMaterial(m_pBackgroundMaterial, TEX_COLOR, NULL);
                glBegin(GL_QUADS);
                //					Bottom Left
                glVertex3d(left, bottom, 0);
                //		Bottom Right
                glVertex3d(right, bottom, 0);
                //		Top Right
                glVertex3d(right, top, 0);
                //					Top Left
                glVertex3d(left, top, 0);
                glEnd();
            }
        }
    }

    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        tmp->OnDraw();
        tmp = m_lstChildren.next();
    }
}

tRect & CGUIElement::GetRect()
{
    return m_Rect;
}

void CGUIElement::SetRect(tRect & r)
{
    m_Rect = r;

    CGUIElement * border = FindChild(Border);
    if(border != NULL)
        border->OnSize(r);
}

int CGUIElement::GetWidth()
{
    return m_Rect.m_iRight - m_Rect.m_iLeft;
}

void CGUIElement::SetWidth(unsigned int width)
{
    m_Rect.m_iRight = m_Rect.m_iLeft + width;

    if(GetEventHandler() == NULL)
    {
        CGUIElement * border = FindChild(Border);
        if(border != NULL)
            border->OnSize(m_Rect);
    }
    else
        BroadcastMessage(this, SizeX);
}

int CGUIElement::GetHeight()
{
    // Remember, in OpenGL m_iTop has bigger value than m_iBottom, but taking absolute value will work for any
    // API
    return abs(m_Rect.m_iTop - m_Rect.m_iBottom);
}

void CGUIElement::SetHeight(unsigned int height)
{
    m_Rect.m_iBottom = m_Rect.m_iTop - height;

    if(GetEventHandler() == NULL)
    {
        CGUIElement * border = FindChild(Border);
        if(border != NULL)
            border->OnSize(m_Rect);
    }
    else
        BroadcastMessage(this, SizeY);
}

void CGUIElement::SetID(int id)
{
    m_iElementID = id;
}

int CGUIElement::GetID()
{
    return m_iElementID;
}

eControlType CGUIElement::GetType()
{
    return m_eElementType;
}

void CGUIElement::SetType(eControlType type)
{
    m_eElementType = type;
}

void CGUIElement::SetParent(CGUIElement * parent)
{
    m_pParent = parent;
}

CGUIElement * CGUIElement::GetParent()
{
    return m_pParent;
}

int CGUIElement::OnSize(tRect newRect)
{
    int sx = 0, sy = 0;
    if((newRect.m_iRight - newRect.m_iLeft) >= MINIMUM_WIDTH
       && (((m_Rect.m_iRight - newRect.m_iRight) != 0) || ((m_Rect.m_iLeft - newRect.m_iLeft) != 0)))
    {
        if(m_RestrictionFlags.m_iFlag0 != RestrictSizeX)
        {
            m_Rect.m_iLeft  = newRect.m_iLeft;
            m_Rect.m_iRight = newRect.m_iRight;
            sx              = SizeX;
        }
    }

    if((newRect.m_iTop - newRect.m_iBottom) >= MINIMUM_HEIGHT
       && ((((m_Rect.m_iBottom - newRect.m_iBottom) != 0) || ((m_Rect.m_iTop - newRect.m_iTop) != 0))))
    {
        if(m_RestrictionFlags.m_iFlag1 != RestrictSizeY)
        {
            m_Rect.m_iTop    = newRect.m_iTop;
            m_Rect.m_iBottom = newRect.m_iBottom;
            sy               = SizeY;
        }
    }

    if(GetEventHandler() == NULL)
    {
        CGUIElement * border = FindChild(Border);
        if(border != NULL)
            border->OnSize(newRect);
    }

    if(sx && sy)
    {
        BroadcastMessage(this, SizeXY);
        return SizeXY;
    }

    if(sx == SizeX && sy == 0)
    {
        BroadcastMessage(this, SizeX);
        return SizeX;
    }

    else if(sy == SizeY && sx == 0)
    {
        BroadcastMessage(this, SizeY);
        return SizeY;
    }

    return 0;
}

int CGUIElement::OnKeyDown(int KeyCode)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->OnKeyDown(KeyCode))
            return 1;
        tmp = m_lstChildren.prev();
    }

    return 0;
}

int CGUIElement::OnKeyUp(int KeyCode)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->OnKeyUp(KeyCode))
            return 1;
        tmp = m_lstChildren.prev();
    }

    return 0;
}

int CGUIElement::OnMove(int x, int y)
{
    if(GetType() == GUI)
        return 0;

    int mx = Default, my = Default;
    if(m_bVisible)
    {
        // Resize this element according to its restriction flags
        if(m_RestrictionFlags.m_iFlag2 != RestrictMoveX && x != 0)
        {
            m_Rect.m_iLeft += x;
            m_Rect.m_iRight += x;
            mx = MoveX;
        }

        if(m_RestrictionFlags.m_iFlag3 != RestrictMoveY && y != 0)
        {
            m_Rect.m_iTop += y;
            m_Rect.m_iBottom += y;
            my = MoveY;
        }
    }

    if(mx != Default && my != Default)
    {
        BroadcastMessage(this, MoveXY, x, y, 0, NULL);   // Send message to children
        return MoveXY;
    }
    else if(mx == MoveX && my == Default)
    {
        BroadcastMessage(this, MoveX, x, y, 0, NULL);   // Send message to children
        return MoveX;
    }
    else if(my == MoveY && mx == Default)
    {
        BroadcastMessage(this, MoveY, x, y, 0, NULL);   // Send message to children
        return MoveY;
    }

    return 0;
}

int CGUIElement::OnLMouseDown(int x, int y)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->OnLMouseDown(x, y))
            return 1;
        tmp = m_lstChildren.prev();
    }

    if(GetType() != GUI)
    {
        if(m_bVisible)
        {
            if(PointInRect(m_Rect, x, y))
            {
                CGUIUtility::GetSingleton().SetActiveElement(this);
                // Activate here and bring it to m_iTop!
                CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag1 = LMouseDown;
                return 1;
            }
        }
    }

    return 0;
}

int CGUIElement::OnLMouseUp(int x, int y)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->OnLMouseUp(x, y))
            return 1;
        tmp = m_lstChildren.prev();
    }

    if(GetType() != GUI)
    {
        if(m_bVisible)
            CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag1 = Default;

        if(PointInRect(GetRect(), x, y))
        {
            BroadcastMessage(this, AquireFocus);
            return 1;
        }
    }

    return 0;
}

int CGUIElement::OnRMouseDown(int x, int y)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->OnRMouseDown(x, y))
            return 1;
        tmp = m_lstChildren.prev();
    }

    if(GetType() != GUI)
    {
        if(m_bVisible)
        {
            if(PointInRect(m_Rect, x, y))
                return 1;
        }
    }

    return 0;
}

int CGUIElement::OnRMouseUp(int x, int y)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->OnRMouseUp(x, y))
            return 1;
        tmp = m_lstChildren.prev();
    }

    if(GetType() != GUI)
    {
        if(m_bVisible) {}
    }

    return 0;
}

int CGUIElement::OnMouseMove(int x, int y)
{
    CGUIElement * tmp = m_lstChildren.end();
    m_lstChildren.set_ptr(tmp);

    int ret = 0;
    while(tmp != NULL)
    {
        ret |= tmp->OnMouseMove(x, y);
        tmp = m_lstChildren.prev();
    }

    if(GetType() != GUI)
    {
        if(m_bVisible)
        {
            // Move this element if it has a lmousedown flag
            if(CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag1 == LMouseDown)
            {
                if(CGUIUtility::GetSingleton().GetActiveElement() == this)
                    OnMove(CGUIUtility::GetSingleton().GetMousePos().x
                               - CGUIUtility::GetSingleton().GetPrevMousePos().x,
                           CGUIUtility::GetSingleton().GetMousePos().y
                               - CGUIUtility::GetSingleton().GetPrevMousePos().y);
            }

            if(PointInRect(m_Rect, x, y))
            {
                CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag0 = MouseOver;
                ret                                                  = true;
            }
        }
    }

    return ret;
}

tMaterial * CGUIElement::GetActiveMaterial()
{
    return m_pBackgroundMaterial;
}

void CGUIElement::SetActiveMaterial(tMaterial * mat)
{
    if(mat != NULL)
        m_pBackgroundMaterial = mat;
}

// Retrieves/Moves element in parent' list of elements up to specified order index
void CGUIElement::SetZOrder(unsigned int order) {}

unsigned int CGUIElement::GetZOrder()
{
    CGUIElement * parent = GetParent();
    if(parent == 0)
        return 0;
    else
    {
        for(int i = 0; i < parent->GetChildCount(); i++)
        {
            if(parent->GetChild(i) == this)
                return i;
        }
    }
    return 1;
}

CGUIElement * CGUIElement::GetChild(int index)
{
    if(index > m_lstChildren.size() || index < 0)
        return NULL;

    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    int count = 0;
    while(tmp != NULL)
    {
        if(count == index)
            return tmp;

        tmp = m_lstChildren.next();
        count++;
    }

    return NULL;
}

bool CGUIElement::FindChild(CGUIElement * element)
{
    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp == element)
            return true;

        tmp = m_lstChildren.next();
    }

    return false;
}

CGUIElement * CGUIElement::FindChild(eControlType type, unsigned int id)
{
    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(id == 0)
        {
            if(tmp->m_eElementType == type)
                return tmp;
        }
        else
        {
            if(tmp->m_eElementType == type && tmp->m_iElementID == id)
                return tmp;
        }

        tmp = m_lstChildren.next();
    }

    return NULL;
}

CGUIElement * CGUIElement::FindChild(TiXmlNode * node)
{
    if(node == m_pXMLNode)
        return this;

    CGUIElement * child = m_lstChildren.begin();
    m_lstChildren.set_ptr(child);

    while(child != NULL)
    {
        CGUIElement * found = child->FindChild(node);
        if(found)
            return found;

        child = m_lstChildren.next();
    }

    return NULL;
}

int CGUIElement::GetChildCount()
{
    return m_lstChildren.size();
}

bool CGUIElement::AddChild(CGUIElement * child)
{
    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp == child)
            return false;

        tmp = m_lstChildren.next();
    }

    m_lstChildren.push_back(child);
    return true;
}

bool CGUIElement::RemoveChild(CGUIElement * child)
{
    CGUIElement * to_remove = m_lstChildren.remove(child);
    if(to_remove)
    {
        delete to_remove;
        return true;
    }

    return false;
}

void CGUIElement::SetEventHandler(CGUIEventHandler * handler)
{
    m_pHEvent = handler;

    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        tmp->SetEventHandler(handler);
        tmp = m_lstChildren.next();
    }
}

CGUIEventHandler * CGUIElement::GetEventHandler()
{
    return m_pHEvent;
}

void CGUIElement::ProcessMessage(tMessage * msg)
{
    if(msg != NULL)
    {
        switch(msg->m_eMsg)
        {
            case DeleteMe:
                {
                    CGUIElement * ToDelete  = msg->m_pSender;
                    CGUIElement * ItsParent = ToDelete->GetParent();
                    if(ItsParent != NULL)
                        ItsParent->RemoveChild(ToDelete);

                    GetEventHandler()->RemoveReferences(ToDelete);
                    break;
                }
        }
    }
}

void CGUIElement::ProcessMessages()
{
    tMessage * msg = m_pHEvent->GetNextMsg();
    while(msg != NULL)
    {
        if(msg->m_pReceiver == this)
            ProcessMessage(msg);

        msg = m_pHEvent->GetNextMsg(msg);
    }
}

void CGUIElement::BroadcastMessage(CGUIElement * sender, eMessage msg, DWORD prm1, DWORD prm2, double delay,
                                   CGUIElement * receiver)
{
    if(m_pHEvent != NULL)
    {
        if(receiver == NULL)
        {
            receiver = GetParent();
            m_pHEvent->PostMessage(sender, receiver, msg, prm1, prm2, 0);
        }
        else
            m_pHEvent->PostMessage(sender, receiver, msg, prm1, prm2, delay);
    }
}

TiXmlNode * CGUIElement::GetXMLNode()
{
    return m_pXMLNode;
}

void CGUIElement::SetTexCoord(unsigned int index, float U, float V)
{
    if(index >= 0 && index <= 3)
    {
        m_fTexCoord[index].x = U;
        m_fTexCoord[index].y = V;
    }
}

tVERTEX2f CGUIElement::GetTexCoord(unsigned int index)
{
    if(index >= 0 && index <= 3)
        return m_fTexCoord[index];

    return tVERTEX2f(-1, -1);
}

char * CGUIElement::GetExtRef()
{
    return m_strExternRef;
}

void CGUIElement::OnDestroy()
{
    m_lstChildren.erase();
}
