#include "AnimatedTexture.h"

int CAnimatedTexture::Parse(TiXmlNode * this_node, char * filename)
{
    char const *   value        = NULL;
    TiXmlElement * anim_element = NULL;
    TiXmlNode *    anim_node    = NULL;

    TiXmlDocument doc(filename);

    if(filename != NULL)
    {
        int loadOkay = doc.LoadFile();

        if(loadOkay != 1)
            return -1;

        anim_node = doc.FirstChild();
    }
    else
        anim_node = this_node->FirstChild();

    if(anim_node == NULL)
        return 0;

    CTextureManager::GetSingleton().Parse(this_node, filename);
    CMaterialManager::GetSingleton().Parse(this_node, filename);

    anim_element = anim_node->ToElement();
    value        = anim_element->Attribute("Materials");
    if(value != NULL)
    {
        m_iTexCount = atoi(value);
        value       = NULL;
    }
    else
        return 0;

    value = anim_element->Attribute("Frames");
    if(value != NULL)
    {
        m_iFrameCount = atoi(value);
        value         = NULL;
    }
    else
        return 0;

    m_pFrameOffset = new tRect[m_iFrameCount];
    m_piTexIndex   = new int[m_iFrameCount];

    int frm_count = 0;

    TiXmlNode *    frame_node    = NULL;
    TiXmlElement * frame_element = NULL;
    frame_node                   = anim_element->FirstChild();

    while(frame_node != NULL)
    {
        frame_element = frame_node->ToElement();

        if(stricmp(frame_element->Value(), "frame") == 0)
        {
            value = frame_element->Attribute("MatByRefID");
            if(value != NULL)
            {
                m_piTexIndex[frm_count] = atoi(value);
                value                   = NULL;
            }

            value = frame_element->Attribute("Rect");
            if(value != NULL)
            {
                sscanf(value, "%d,%d,%d,%d", &m_pFrameOffset[frm_count].m_iLeft,
                       &m_pFrameOffset[frm_count].m_iRight, &m_pFrameOffset[frm_count].m_iTop,
                       &m_pFrameOffset[frm_count].m_iBottom);
                value = NULL;
            }

            frm_count++;
        }

        frame_node = anim_element->IterateChildren(frame_node);
    }

    return 1;
}