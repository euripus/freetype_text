#include "FontEngine.h"

CCustomFont::CCustomFont()
{
    if(CFontEngine::GetSingletonPtr() != NULL)
        m_uiFontID = CFontEngine::GetSingleton().GetNextUID();

    for(int i = 0; i < 128; i++)
        m_strFontName[i] = m_strFilename[i] = '\0';

    m_uiUserID = 0;
}

CCustomFont::~CCustomFont()
{
    Destroy();
}

/*!
    Default function for font creation.
*/
int CCustomFont::Create()
{
    return 1;
}

/*!
    Default function for text drawing.
*/
void CCustomFont::Draw(char const * fmt, ...) {}

/*!
    Default function for drawing character.
*/
void CCustomFont::DrawChar(float x, float y, char c) {}

/*!
    Default function for font data parsing.
*/
int CCustomFont::Parse(TiXmlNode * this_node, char * filename)
{
    return 1;
}

/*!
    Default function for destruction of font.
*/
void CCustomFont::Destroy() {}

/*!
    Sets font name.
*/
void CCustomFont::SetFontName(char * name)
{
    if(strlen(name) > 128)
        strncpy(name, m_strFontName, 128);
    else
        strcpy(m_strFontName, name);
}

/*!
    Returns font name.
*/
char * CCustomFont::GetFontName()
{
    return m_strFontName;
}

/*!
    Returns font type
*/
eFontType CCustomFont::GetFontType()
{
    return m_eFontType;
}

/*!
    Sets font USER ID.
*/
void CCustomFont::SetUserFontID(unsigned int id)
{
    m_uiUserID = id;
}

/*!
    Returns font USER ID.
*/
unsigned int CCustomFont::GetUserFontID()
{
    return m_uiUserID;
}

/*!
    Commences orthographic mode.
*/
void BeginOrtho()
{
    int viewport[4];

    glMatrixMode(GL_PROJECTION);   // Select The Projection Matrix
    glPushMatrix();                // Store The Projection Matrix
    glLoadIdentity();              // Reset The Projection Matrix
    glGetIntegerv(GL_VIEWPORT, viewport);

    glOrtho(0, viewport[2], 0, viewport[3], 0, 100);   // Set Up An Ortho Screen
    glMatrixMode(GL_MODELVIEW);                        // Select The Modelview Matrix
    glPushMatrix();                                    // Store The Modelview Matrix
}

/*!
    Finishes orthographic mode.
*/
void EndOrtho()
{
    glMatrixMode(GL_PROJECTION);   // Select The Projection Matrix
    glPopMatrix();                 // Restore The Old Projection Matrix

    glMatrixMode(GL_MODELVIEW);   // Select The Modelview Matrix
    glPopMatrix();                // Restore The Old Projection Matrix
}