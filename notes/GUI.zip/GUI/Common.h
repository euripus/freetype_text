#include "Logger.h"
#include "Singleton.h"
#include "DoubleList.h"

int roundf(float val);