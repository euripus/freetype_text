/*
    CTimer.cpp

        Timer class under Microsoft Windows.

    Author:	Brett Porter
    Email: brettporter@yahoo.com
    Website: http://rsn.gamedev.net/pl3d
    Copyright (C)2000, 2001, Brett Porter. All Rights Reserved.
    This source code is released under the LGPL. See license.txt for details.

    Created: 18 July 2000
    Last Edited: 6 Febraury 2001

    Please see the file ChangeLog.html for a revision history.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "Timer.h"

#ifndef _WIN32
#error This file should only be used in a Microsoft Windows build.
#endif

// Disable warning about non-standard extension in Microsoft's header files
#pragma warning(disable:4201)
#include <mmsystem.h>
#pragma warning(default:4201)
#pragma comment(lib, "winmm.lib")

CTimer::CTimer()
{
    if(QueryPerformanceFrequency((LARGE_INTEGER *)&m_dwFrequency) == false)
    {
        // No performance counter available
        m_bUsePerformanceCounter = false;

        m_dwTimerStart = timeGetTime();
    }
    else
    {
        // Performance counter is available, use it instead of the multimedia timer
        m_bUsePerformanceCounter = true;

        // Get the current time and store it in pcTimerStart
        QueryPerformanceCounter((LARGE_INTEGER *)&m_dwTimerStart);

        // Calculate the timer resolution using the timer frequency
        m_fResolution = (float)(1.0 / (double)m_dwFrequency) * 1000.0f;
    }

    m_iPauseCount = 0;
    m_fPauseTime  = 0;
}

CTimer::~CTimer() {}

void CTimer::Reset()
{
    if(m_bUsePerformanceCounter == true)
        QueryPerformanceCounter((LARGE_INTEGER *)&m_dwTimerStart);
    else
        m_dwTimerStart = timeGetTime();

    m_fPauseTime = GetTime();
}

double CTimer::GetTime()
{
    if(m_iPauseCount > 0)
        return m_fPauseTime;

    __int64 timeElapsed;

    if(m_bUsePerformanceCounter == true)
    {
        QueryPerformanceCounter((LARGE_INTEGER *)&timeElapsed);
        timeElapsed -= m_dwTimerStart;
        return timeElapsed * m_fResolution;
    }
    else
    {
        timeElapsed = timeGetTime() - m_dwTimerStart;
        return (double)timeElapsed;
    }
}

void CTimer::Pause()
{
    if(m_iPauseCount == 0)
        m_fPauseTime = GetTime();

    m_iPauseCount++;
}

double CTimer::GetAbsoluteTime()
{
    __int64 timeElapsed;
    if(m_bUsePerformanceCounter == true)
        QueryPerformanceCounter((LARGE_INTEGER *)&timeElapsed);

    else
        timeElapsed = timeGetTime();

    return timeElapsed * m_fResolution;
}

void CTimer::Unpause()
{
    if(m_iPauseCount > 0)
        m_iPauseCount--;

    if(m_iPauseCount == 0)
    {
        if(m_bUsePerformanceCounter == true)
        {
            __int64 time;
            QueryPerformanceCounter((LARGE_INTEGER *)&time);
            m_dwTimerStart = time - (__int64)(m_fPauseTime / m_fResolution);
        }
        else
        {
            m_dwTimerStart = (unsigned)(timeGetTime() - m_fPauseTime);
        }
    }
}
