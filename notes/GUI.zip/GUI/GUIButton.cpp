#include "GUI.h"

CGUIButton::CGUIButton()
{
    m_iButtonState = 0;
    m_bLoopState   = false;   // Default checkbox actions
                              //	AddDefaultEventToState(0, true, 0, NULL); // Add default normal state
    SetType(Button);
}

CGUIButton::~CGUIButton()
{
    // Ensure all button states are freed in overridden function, so there's no memory leaks
    OnDestroy();
}

int CGUIButton::GetButtonState()
{
    return m_iButtonState;
}

void CGUIButton::SetButtonState(bool loopanim, int state)
{
    // Ensure proper value is assigned
    if(state >= 0 && state < m_lstButtonStates.size())
        m_iButtonState = state;

    m_bLoopState = loopanim;
}

int CGUIButton::OnLMouseUp(int x, int y)
{
    int ret = CGUIElement::OnLMouseUp(x, y);
    if(ret)   // If mouse was un-pressed over this rectangle
    {
        // If mouse was pressed over this rect
        if(PointInRect(GetRect(), CGUIUtility::GetSingleton().GetLMouseDown().x,
                       CGUIUtility::GetSingleton().GetLMouseDown().y)
           && m_bVisible)
        {
            // Progress in button states
            if(m_iButtonState == (m_lstButtonStates.size() - 1))
            {
                if(m_bLoopState)
                    m_iButtonState = 0;
            }
            else
                m_iButtonState++;

            // Broadcast the 'pressed' message
            BroadcastMessage(this, ButtonPressed, 0, 0, 0, GetParent());
        }
    }

    return ret;
}

int CGUIButton::Parse(TiXmlNode * this_node, string filename)
{
    // Firstly, parse the sub- of the button - static control values, text, etc
    if(!CGUIStatic::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    // Parse the button states
    if(!ParseBtnStates(m_pXMLNode))
    {
#ifdef USE_GLOBAL_LOGGER
        CGlobalLogger::GetSingleton().Write(
            "GUI Framework - Parsing Failed! Element Type: %d, Error Desc.: Unable to parse states!\n",
            GetType());
#endif

        return -1;
    }

    TiXmlElement * element = NULL;
    TiXmlNode *    node    = m_pXMLNode;
    char const *   value   = NULL;

    element = m_pXMLNode->ToElement();

    value = element->Attribute("Loop");
    if(value != NULL)
    {
        m_bLoopState = (bool)(int)atoi(value);
        value        = NULL;
    }

    return 1;
}

int CGUIButton::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("Button");

    if(this_element != NULL)
        element = this_element;

    if(strlen(GetExtRef()) != 0)
        element->SetAttribute("Filename", GetExtRef());
    /*
    // Wrapping text?
    if(m_bLoopState)
        element->SetAttribute("Loop", "1");

    if(m_iButtonState !=0)
    {
        sprintf((char *)value, "%d", m_iButtonState);
        element->SetAttribute("State", value);

        memset((void *)value, 0, 128);
    }

    // The button states/events will have to be saved/edited manually,
    // so it's better to load buttons by filename (remote)!!
    // The ability to save states/events will be added later.
    */

    if(this_element != NULL)
        CGUIStatic::Save(NULL, this_element);
    else
    {
        CGUIStatic::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIButton::OnDestroy()
{
    // Erase all button states so there are no memory leaks
    m_lstButtonStates.erase();
}

void CGUIButton::OnDraw()
{
    // Aquire current animation
    CAnimatedTexture * cur = GetCurrentAnimation();

    if(cur != NULL)
    {
        // 'Animate' the animation - e.g progress
        cur->Animate(100);

        // Aquire current material pointer
        tMaterial * mat = CMaterialManager::GetSingleton().GetMaterial(
            -1, (unsigned int)cur->m_piTexIndex[cur->m_iCurrentFrame]);
        if(mat != NULL)
        {
            SetActiveMaterial(mat);

            if(mat->m_pTexPtr != NULL)   // Check if we got the texture
            {
                if(cur->m_pFrameOffset != NULL)
                {
                    m_fTexCoord[0].x = (float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iLeft
                                       / (float)mat->m_pTexPtr->m_iWidth;
                    m_fTexCoord[1].x = (float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iRight
                                       / (float)mat->m_pTexPtr->m_iWidth;
                    m_fTexCoord[2].x = (float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iRight
                                       / (float)mat->m_pTexPtr->m_iWidth;
                    m_fTexCoord[3].x = (float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iLeft
                                       / (float)mat->m_pTexPtr->m_iWidth;

                    // if(cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iBottom != mat->m_pTexPtr->m_iHeight)
                    //{
                    m_fTexCoord[0].y = 1.0f
                                       - ((float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iBottom
                                          / (float)mat->m_pTexPtr->m_iHeight);
                    m_fTexCoord[1].y = 1.0f
                                       - ((float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iBottom
                                          / (float)mat->m_pTexPtr->m_iHeight);
                    m_fTexCoord[2].y = 1.0f
                                       - ((float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iTop
                                          / (float)mat->m_pTexPtr->m_iHeight);
                    m_fTexCoord[3].y = 1.0f
                                       - ((float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iTop
                                          / (float)mat->m_pTexPtr->m_iHeight);
                    //}
                    // else
                    //{
                    //	m_fTexCoord[0].y = (float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iTop /
                    //(float)mat->m_pTexPtr->m_iHeight; 	m_fTexCoord[1].y =
                    //(float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iTop /
                    //(float)mat->m_pTexPtr->m_iHeight; 	m_fTexCoord[2].y =
                    //(float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iBottom /
                    //(float)mat->m_pTexPtr->m_iHeight; 	m_fTexCoord[3].y =
                    //(float)cur->m_pFrameOffset[cur->m_iCurrentFrame].m_iBottom /
                    //(float)mat->m_pTexPtr->m_iHeight;
                    //}
                }
            }
        }
    }

    // Draw the static control part
    CGUIStatic::OnDraw();
}

CAnimatedTexture * CGUIButton::GetCurrentAnimation()
{
    CAnimatedTexture * ret = NULL;
    // If no mouse over this button and its not pressed

    // State 0 - NORMAL state
    // A button MUST have a normal state!
    // There must be no change of flags when a button is disabled!
    // Normal (not mouseover)
    if(CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag0 == MouseOver
       && CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag1 == Default
       && PointInRect(GetRect(), CGUIUtility::GetSingleton().GetMousePos().x,
                      CGUIUtility::GetSingleton().GetMousePos().y))   // Only mouseover
    {
        if((&GetEvent(MouseOver)->m_Animation) != NULL)
            return &GetEvent(MouseOver)->m_Animation;
    }
    else if(CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag0 == MouseOver
            && CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag1 == LMouseDown
            && CGUIUtility::GetSingleton().GetActiveElement() == this)
    {
        if((&GetEvent(LMouseDown)->m_Animation) != NULL)
            return &GetEvent(LMouseDown)->m_Animation;
    }

    return &GetEvent(Default)->m_Animation;
}

tButtonAnimation * CGUIButton::GetEvent(int event)
{
    // Returns event based on current mouse position/state
    int evt = 0;
    switch(event)
    {
        case Default:   // Normal
            evt = 0;
            break;

        case MouseOver:   // Mouseover
            evt = 1;
            break;

        case LMouseDown:   // LMouseDown
            evt = 2;
            break;
    }

    // Basically, goes through all events and states and finds one appropriate
    // for current config of 'm_iButtonState' and 'event' variables
    // and if finds one, returns its animation
    int            state_count = 0;
    tButtonState * st          = m_lstButtonStates.begin();
    m_lstButtonStates.set_ptr(st);

    while(st != NULL)
    {
        tButtonAnimation * anim = st->m_lstEvents.begin();
        st->m_lstEvents.set_ptr(anim);

        while(anim != NULL)
        {
            if(anim->m_iEventType == evt && state_count == m_iButtonState)
                return anim;

            anim = st->m_lstEvents.next();
        }

        state_count++;
        st = m_lstButtonStates.next();
    }

    return NULL;
}

bool CGUIButton::ParseBtnStates(TiXmlNode * btn_xml_node)
{
    if(btn_xml_node == NULL)
        return false;

    TiXmlNode *    state_node    = NULL;
    TiXmlElement * state_element = NULL;

    state_node = btn_xml_node->FirstChild();

    const string value = "";
    while(state_node != NULL)
    {
        state_element = state_node->ToElement();
        if(stricmp(state_element->Value(), "state") == 0)
        {
            tButtonState * newState = new tButtonState;
            if(!ParseStateEvents(newState, state_node))
            {
#ifdef USE_GLOBAL_LOGGER
                CGlobalLogger::GetSingleton().Write(
                    "GUI Framework - Parsing Failed! Element Type: %d, Error Desc.: Unable to parse event!\n",
                    GetType());
#endif

                delete newState;
                newState = NULL;
            }
            else
                m_lstButtonStates.push_back(newState);
        }

        state_node = btn_xml_node->IterateChildren(state_node);
    }

    return true;
}

bool CGUIButton::ParseStateEvents(tButtonState * btn_state, TiXmlNode * state_xml_node)
{
    char const * value = NULL;

    TiXmlNode *    event_node    = NULL;
    TiXmlElement * event_element = NULL;

    event_node = state_xml_node->FirstChild();

    while(event_node != NULL)
    {
        event_element = event_node->ToElement();

        if(stricmp(event_element->Value(), "event") == 0)
        {
            tButtonAnimation * newEvent = new tButtonAnimation;

            // Each button has 4 events - disabled(-1), normal(0), mouseover(1), mousedown(2) -
            //  IT MAY HAVE MORE IF YOU ADD!!
            value = event_element->Attribute("Type");
            if(value == NULL)
                return false;
            else
            {
                if(stricmp(value, "disabled") == 0)
                    newEvent->m_iEventType = -1;   // Disabled
                else if((stricmp(value, "normal") == 0) || (stricmp(value, "std") == 0)
                        || (stricmp(value, "none") == 0))
                    newEvent->m_iEventType = 0;
                else if((stricmp(value, "mouseover") == 0) || (stricmp(value, "mouse over") == 0))
                    newEvent->m_iEventType = 1;
                else if((stricmp(value, "mousedown") == 0) || (stricmp(value, "mouse down") == 0))
                    newEvent->m_iEventType = 2;

                value = NULL;
            }

            value = event_element->Attribute("AnimationFile");
            if(value != NULL)
            {
                if(!newEvent->m_Animation.Parse(NULL, (char *)value))
                {
#ifdef USE_GLOBAL_LOGGER
                    CGlobalLogger::GetSingleton().Write("GUI Framework - Parsing Failed! Element Type: %d, "
                                                        "Error Desc.: Unable to parse animation!\n",
                                                        GetType());
#endif

                    return false;
                }

                value = NULL;
            }
            else
            {
                if(!newEvent->m_Animation.Parse(event_node, NULL))
                {
#ifdef USE_GLOBAL_LOGGER
                    CGlobalLogger::GetSingleton().Write("GUI Framework - Parsing Failed! Element Type: %d, "
                                                        "Error Desc.: Unable to parse animation!\n",
                                                        GetType());
#endif

                    return false;
                }

                value = NULL;
            }

            btn_state->m_lstEvents.push_back(newEvent);
        }

        event_node = state_xml_node->IterateChildren(event_node);
    }

    return true;
}