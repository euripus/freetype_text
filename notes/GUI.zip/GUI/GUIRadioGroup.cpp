// GUIRadioGroup.cpp: implementation of the CGUIRadioGroup class.
//
//////////////////////////////////////////////////////////////////////
#include "GUI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGUIRadioGroup::CGUIRadioGroup()
{
    SetType(RadioGroup);
    m_iCurBtnSel = -1;
}

CGUIRadioGroup::~CGUIRadioGroup() {}

int CGUIRadioGroup::Parse(TiXmlNode * node, string filename)
{
    if(!CGUIStatic::Parse(node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = node;

    // START PARSING ELEMENT PROPERTIES
    char const *   value   = NULL;
    TiXmlElement * element = NULL;
    element                = m_pXMLNode->ToElement();

    value = element->Attribute("CurSel");
    if(value != NULL)
    {
        SetCurSel(atoi(value));
        value = NULL;
    }

    return 1;
}

int CGUIRadioGroup::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("RadioGroup");

    if(this_element != NULL)
        element = this_element;

    if(m_iCurBtnSel != -1)
    {
        sprintf((char *)value, "%d", m_iCurBtnSel);
        element->SetAttribute("CurSel", value);

        memset((void *)value, 0, 128);
    }

    if(this_element != NULL)
        CGUIStatic::Save(NULL, this_element);
    else
    {
        CGUIStatic::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIRadioGroup::OnDraw()
{
    // Comment the next line if you want the rectangle of radio group to be drawn
    HideSiblings();
    CGUIStatic::OnDraw();
    ShowSiblings();

    if(!Visible())
        return;

    if(m_lstChildren.size() == 0)
        return;

    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    while(tmp != NULL)
    {
        if(tmp->GetType() == Button)
            tmp->OnDraw();

        tmp = m_lstChildren.next();
    }
}

int CGUIRadioGroup::OnLMouseUp(int x, int y)
{
    if(!Visible())
        return 0;

    if(m_lstChildren.size() == 0)
        return 0;

    CGUIElement * tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    int ret = 0, count = 0;   // Button is considered pressed when the mouse was down over it and mouse is up
                              // when its inside the button's rectangle
    while(tmp != NULL)
    {
        if(tmp->GetType() == Button)
        {
            ret = tmp->OnLMouseUp(x, y);   // Mouse down was accepted by this button and processed
            if(ret == 1)
            {
                ((CGUIButton *)tmp)->SetButtonState(false, 1);
                m_iCurBtnSel = count;
            }

            count++;
        }

        tmp = m_lstChildren.next();
    }

    // Reset all other buttons
    tmp = m_lstChildren.begin();
    m_lstChildren.set_ptr(tmp);

    count = 0;
    while(tmp != NULL)
    {
        if(tmp->GetType() == Button)
        {
            if(count != m_iCurBtnSel)
                ((CGUIButton *)tmp)->SetButtonState(false, 0);

            count++;
        }

        tmp = m_lstChildren.next();
    }

    return CGUIStatic::OnLMouseUp(x, y);
}

void CGUIRadioGroup::SetCurSel(int index)
{
    if(index >= 0 && index < GetChildCount())
    {
        m_iCurBtnSel = index;

        CGUIElement * tmp = m_lstChildren.begin();
        m_lstChildren.set_ptr(tmp);

        int count = 0;
        while(tmp != NULL)
        {
            if(tmp->GetType() == Button)
            {
                if(count == m_iCurBtnSel)
                    ((CGUIButton *)tmp)->SetButtonState(false, 1);
                else
                    ((CGUIButton *)tmp)->SetButtonState(false, 0);

                count++;
            }

            tmp = m_lstChildren.next();
        }
    }
    else
        m_iCurBtnSel = -1;
}

int CGUIRadioGroup::GetCurSel()
{
    return m_iCurBtnSel;
}
