// GUIMenu.cpp: implementation of the CGUIDropList class.
//
//////////////////////////////////////////////////////////////////////
#include "GUI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CGUIDropList::CGUIDropList()
{
    SetType(DropList);
    m_iListType  = 0;
    m_bIdentSize = true;
    m_iCurSel    = -1;
    m_bExpanded  = false;
    m_iSpacing   = 1;
}

CGUIDropList::~CGUIDropList() {}

void CGUIDropList::Expand()
{
    // Shows all buttons (e.g expand)
    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * tmp = GetChild(i);
        if(tmp->GetType() == Button)
            tmp->Show();
    }

    // Sets flag
    m_bExpanded = true;
}

void CGUIDropList::Collapse()
{
    // Hides all buttons
    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * tmp = GetChild(i);
        if(tmp->GetType() == Button)
            tmp->Hide();
    }

    // Sets flag
    m_bExpanded = false;
}

void CGUIDropList::OnPrepare()
{
    int max_width = 0;

    // Find longest text entry size
    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * tmp = GetChild(i);

        if(tmp->GetType() == Button)
        {
            if(((CGUIButton *)tmp)->GetText() != "")
            {
                int ttl_width = 0;
                for(int i = 0; i < ((CGUIButton *)tmp)->GetText().size() + 1; i++)
                    ttl_width = ttl_width + ((CGUIButton *)tmp)->GetFont()->m_iQuadLengthX
                                + ((CGUIButton *)tmp)->GetFont()->m_iSpaceChar;

                if(max_width <= ttl_width)
                    max_width = ttl_width;
            }
        }
    }

    // Get absolute maximum width
    if(max_width < GetWidth() || max_width > GetWidth())
        max_width = GetWidth();

    // Figure out sub-parameters
    if(m_iListType == 0)   // All entries are of the same width!
    {
        // LimitWidth(true);
        m_bIdentSize = true;
    }
    else if(m_iListType == 1)   // A droplist width becomes the width of the 'widthest' button
                                // and all entries are of the same width!
    {
        tRect r    = GetRect();
        r.m_iRight = r.m_iLeft + max_width;
        SetRect(r);
        m_bIdentSize = true;
    }
    else if(m_iListType == 2)   // A droplist width becomes the width of the 'widthest' button
                                // but all entries stay with their own width!
    {
        tRect r    = GetRect();
        r.m_iRight = r.m_iLeft + max_width;
        SetRect(r);
        m_bIdentSize = false;
    }

    // OK, we got max length, assign each menu its rectangle

    for(int j = 0; j < GetChildCount(); j++)
    {
        CGUIElement * tmp = GetChild(j);

        if(tmp->GetType() == Button)
        {
            // We store previous rect so that next button will know its rectangle coords
            int   ycount = 0;
            tRect prev_rect;
            if(j == 0)
                prev_rect = GetRect();
            else
                prev_rect = GetChild(j - 1)->GetRect();

            int cur_width = max_width;
            if(!m_bIdentSize)
            {
                int width = 0;
                for(int i = 0; i < ((CGUIButton *)tmp)->GetText().size(); i++)
                    width = width + ((CGUIButton *)tmp)->GetFont()->m_iQuadLengthX
                            + ((CGUIButton *)tmp)->GetFont()->m_iSpaceChar;
                cur_width = width;
            }

            tRect r;
            r.m_iLeft   = prev_rect.m_iLeft;
            r.m_iRight  = prev_rect.m_iLeft + cur_width;
            r.m_iTop    = prev_rect.m_iBottom - m_iSpacing;
            r.m_iBottom = r.m_iTop - ((CGUIButton *)tmp)->GetFont()->m_iQuadLengthY;
            tmp->SetRect(r);
            prev_rect = r;

            ycount++;
        }
    }
}

int CGUIDropList::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIButton::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    TiXmlElement * element = NULL;
    TiXmlNode *    node    = m_pXMLNode;
    char const *   value   = NULL;

    element = m_pXMLNode->ToElement();

    value = element->Attribute("EqualSized");
    if(value != NULL)
    {
        if(stricmp(value, "true") == 0 || atoi(value) == 1)
            m_iListType = 1;

        value = NULL;
    }

    value = element->Attribute("CurSel");
    if(value != NULL)
    {
        if(atoi(value) != -1)
            SetCurSel(atoi(value));

        value = NULL;
    }

    OnPrepare();
    Collapse();

    return 1;
}

int CGUIDropList::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("DropList");

    if(this_element != NULL)
        element = this_element;

    if(m_iListType == 1)   // all items are of same size (of control width)
        element->SetAttribute("EqualSized", "1");

    if(m_iCurSel != -1)
    {
        // Sets attributes
        sprintf((char *)value, "%d", m_iCurSel);
        element->SetAttribute("CurSel", value);

        memset((void *)value, 0, 128);
    }

    if(this_element != NULL)
        CGUIButton::Save(NULL, this_element);
    else
    {
        CGUIButton::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIDropList::OnDraw()
{
    // Firstly process messages
    ProcessMessages();
    // Only then draw
    CGUIButton::OnDraw();
}

void CGUIDropList::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);

    while(tmp != NULL)
    {
        switch(tmp->m_eMsg)
        {
            // On Movement/resize we re-calculate our buttons rectangles!
            case MoveX:
            case MoveY:
            case MoveXY:
            case SizeX:
            case SizeY:
            case SizeXY:
                if(tmp->m_pSender == this)
                    OnPrepare();
                break;

            case ButtonPressed:
                {
                    switch(tmp->m_pSender->GetType())
                    {
                        case DropList:
                            {
                                if(tmp->m_pSender == this)   // If the button was this droplist
                                {
                                    if(m_bExpanded)   // Do its stuff
                                    {
                                        Collapse();
                                        GetEventHandler()->RemoveMessage(tmp);
                                        tmp = NULL;
                                    }
                                    else
                                    {
                                        OnPrepare();
                                        Expand();
                                        GetEventHandler()->RemoveMessage(tmp);
                                        tmp = NULL;
                                    }
                                }
                                break;
                            }

                        case Button:
                            {
                                // If the button was the child of this droplist
                                if(!FindChild(tmp->m_pSender))
                                    break;

                                int count = 0;
                                for(int i = 0; i < GetChildCount(); i++)
                                {
                                    CGUIElement * btn = GetChild(i);

                                    if(btn->GetType()
                                       == Button)   // Find out which button has sent it (by count)
                                    {
                                        if(tmp->m_pSender == btn)
                                        {
                                            SetCurSel(count);   // And set the selection count index
                                            Collapse();
                                        }

                                        count++;
                                    }
                                }
                                break;
                            }
                    }
                }
        }

        tmp = GetEventHandler()->GetNextMsg(tmp);
    }
}

void CGUIDropList::SetCurSel(int sel)
{
    if(sel >= 0)
    {
        int           count = 0;
        CGUIElement * tmp   = m_lstChildren.begin();
        m_lstChildren.set_ptr(tmp);

        while(tmp != NULL)
        {
            if(count == sel)
            {
                m_iCurSel = sel;
                SetText(((CGUIButton *)tmp)->GetText());
            }

            // Increment count only if this was a button!
            if(tmp->GetType() == Button)
                count++;

            tmp = m_lstChildren.next();
        }
    }
}

int CGUIDropList::GetCurSel()
{
    return m_iCurSel;
}
