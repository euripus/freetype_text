#include "GUI.h"

CGUIProgressBar::CGUIProgressBar()
{
    m_iCurPos   = 0;
    m_iMinPos   = 0;
    m_iMaxPos   = 0;
    m_fCurPos   = 0;
    m_fPPV      = 0.0;
    m_bMinToMax = true;
    SetType(HorizontalProgressBar);
}

CGUIProgressBar::~CGUIProgressBar() {}

int CGUIProgressBar::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIStatic::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    TiXmlElement * element = NULL;
    TiXmlNode *    node    = m_pXMLNode;
    char const *   value   = NULL;

    element = m_pXMLNode->ToElement();

    value = element->Attribute("Type");
    if(value != NULL)
    {
        if(stricmp(value, "horizontal") == 0)
            SetType(HorizontalProgressBar);
        else if(stricmp(value, "vertical") == 0)
            SetType(VerticalProgressBar);

        value = NULL;
    }

    value = element->Attribute("MinMaxCur");
    if(value != NULL)
    {
        sscanf(value, "%d,%d,%d", &m_iMinPos, &m_iMaxPos, &m_iCurPos);

        value = NULL;
    }

    value = element->Attribute("Min");
    if(value != NULL)
    {
        m_iMinPos = atoi(value);

        value = NULL;
    }

    value = element->Attribute("Max");
    if(value != NULL)
    {
        m_iMaxPos = atoi(value);

        value = NULL;
    }

    value = element->Attribute("Cur");
    if(value != NULL)
    {
        m_iCurPos = atoi(value);

        value = NULL;
    }

    if(m_iMinPos == m_iMaxPos == m_iCurPos == 0)
    {
#ifdef USE_GLOBAL_LOGGER
        CGlobalLogger::GetSingleton().Write(
            "GUI Framework - General Warning: Min/Max/Cur Values are not specified! Element Type: %d\n",
            GetType());
#endif
    }

    int count = 0;
    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * child = GetChild(i);
        if(child->GetType() == Simple)
        {
            child->SetID(PROGRESSBAR_ELMNT_POSITIVE + count);
            count++;
        }
    }

    SetRange(m_iMinPos, m_iMaxPos);
    SetCurPos(m_iCurPos);

    return 1;
}

int CGUIProgressBar::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("ProgressBar");

    if(this_element != NULL)
        element = this_element;

    if(GetType() == HorizontalProgressBar)
        element->SetAttribute("Type", "Horizontal");
    else if(GetType() == VerticalProgressBar)
        element->SetAttribute("Type", "Vertical");

    // Sets attributes
    sprintf((char *)value, "%d,%d,%d", m_iMinPos, m_iMaxPos, m_iCurPos);
    element->SetAttribute("MinMaxCur", value);

    memset((void *)value, 0, 128);

    if(this_element != NULL)
        CGUIStatic::Save(NULL, this_element);
    else
    {
        CGUIStatic::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIProgressBar::OnDraw()
{
    ProcessMessages();

    if(!Visible())
        return;

    // When we have horizontal progress bar, minimum is on m_iLeft, max - m_iRight
    // When we have a vertical progress bar, minimum is m_iTop, max - m_iBottom

    CGUIElement * PositiveSide = FindChild(Simple, PROGRESSBAR_ELMNT_POSITIVE);
    CGUIElement * NegativeSide = FindChild(Simple, PROGRESSBAR_ELMNT_NEGATIVE);

    if(PositiveSide != NULL)
    {
        tMaterial * pos_mat = PositiveSide->GetActiveMaterial();
        if(pos_mat != NULL && pos_mat->m_pTexPtr != NULL)
        {
            PositiveSide->SetTexCoord(0, 0, 1);
            PositiveSide->SetTexCoord(
                1, (float)PositiveSide->GetWidth() / (float)pos_mat->m_pTexPtr->m_iWidth, 1);
            PositiveSide->SetTexCoord(
                2, (float)PositiveSide->GetWidth() / (float)pos_mat->m_pTexPtr->m_iWidth, 0);
            PositiveSide->SetTexCoord(3, 0, 0);
        }

        if(GetActiveMaterial() != NULL && GetActiveMaterial()->m_pTexPtr != NULL)
        {
            SetTexCoord(0, 0, 1);
            SetTexCoord(1, (float)GetWidth() / (float)GetActiveMaterial()->m_pTexPtr->m_iWidth, 1);
            SetTexCoord(2, (float)GetWidth() / (float)GetActiveMaterial()->m_pTexPtr->m_iWidth, 0);
            SetTexCoord(3, 0, 0);
        }
    }

    CGUIElement::OnDraw();   // First we draw underneath the progess bar

    if(m_iCurPos != m_fCurPos)
    {
        m_fCurPos = m_iCurPos;
        OnSize(GetRect());
    }

    char val[10] = "";
    itoa(m_iCurPos, val, 10);
    SetText(val);
    DrawText();
}

int CGUIProgressBar::OnSize(tRect newRect)
{
    int ret = CGUIElement::OnSize(newRect);

    CGUIElement * pos = FindChild(Simple, PROGRESSBAR_ELMNT_POSITIVE);
    CGUIElement * neg = FindChild(Simple, PROGRESSBAR_ELMNT_NEGATIVE);

    int tmp_icurpos = m_iCurPos, tmp_fcurpos = m_fCurPos;
    if(!m_bMinToMax)   // Swap colors for pos/neg areas and substract value because it goes from other end
    {
        m_iCurPos = m_iMaxPos - m_iCurPos;
        m_fCurPos = float(m_iMaxPos) - m_fCurPos;
    }

    tRect r[2];
    if(GetType() == HorizontalProgressBar)   // We have horizontal progress bar
    {
        if(pos != NULL)
        {
            // Change to m_fCurPos to have more precision
            r[0].m_iLeft   = GetRect().m_iLeft + DEFAULT_PROGRESSBAR_SPACINGX;
            r[0].m_iRight  = r[0].m_iLeft + m_fPPV * m_iCurPos;
            r[0].m_iTop    = GetRect().m_iTop - DEFAULT_PROGRESSBAR_SPACINGY;
            r[0].m_iBottom = GetRect().m_iBottom + DEFAULT_PROGRESSBAR_SPACINGY;
        }

        if(neg != NULL)
        {
            r[1].m_iLeft   = r[0].m_iRight;
            r[1].m_iRight  = GetRect().m_iRight - DEFAULT_PROGRESSBAR_SPACINGX;
            r[1].m_iTop    = GetRect().m_iTop - DEFAULT_PROGRESSBAR_SPACINGY;
            r[1].m_iBottom = GetRect().m_iBottom + DEFAULT_PROGRESSBAR_SPACINGY;
        }
    }
    else if(GetType() == VerticalProgressBar)   // We have a vertical progress bar
    {
        if(pos != NULL)
        {
            // Change to m_fCurPos to have more precision
            r[0].m_iLeft   = GetRect().m_iLeft + DEFAULT_PROGRESSBAR_SPACINGX;
            r[0].m_iRight  = GetRect().m_iRight - DEFAULT_PROGRESSBAR_SPACINGX;
            r[0].m_iTop    = GetRect().m_iTop - DEFAULT_PROGRESSBAR_SPACINGY;
            r[0].m_iBottom = r[0].m_iTop - m_fPPV * m_iCurPos;
        }

        if(neg != NULL)
        {
            r[1].m_iLeft   = GetRect().m_iLeft + DEFAULT_PROGRESSBAR_SPACINGX;
            r[1].m_iRight  = GetRect().m_iRight - DEFAULT_PROGRESSBAR_SPACINGX;
            r[1].m_iTop    = r[0].m_iBottom;
            r[1].m_iBottom = GetRect().m_iBottom + DEFAULT_PROGRESSBAR_SPACINGY;
        }
    }

    if(pos != NULL)
        pos->SetRect(r[0]);

    if(neg != NULL)
        neg->SetRect(r[1]);

    if(!m_bMinToMax)
    {
        m_iCurPos = tmp_icurpos;
        m_fCurPos = tmp_fcurpos;
    }

    SetRange(m_iMinPos, m_iMaxPos, m_bMinToMax);
    return ret;
}

void CGUIProgressBar::OnUpdate(float curpos)
{
    if(curpos >= m_iMaxPos)
        m_iCurPos = (int)m_iMaxPos;
    else if(curpos <= m_iMinPos)
        m_iCurPos = (int)m_iMinPos;
    if(curpos > m_iMinPos && curpos < m_iMaxPos)
        m_iCurPos = (int)curpos;
}

int CGUIProgressBar::GetCurPos()
{
    return m_iCurPos;
}

void CGUIProgressBar::SetCurPos(float pos)
{
    OnUpdate(pos);
}

void CGUIProgressBar::SetRange(int min, int max, bool mintomax)
{
    m_iMinPos = min;
    m_iMaxPos = max;
    if(GetType() == HorizontalProgressBar)   // If this is a horizontal progress bar
        m_fPPV = float(GetWidth() - 2 * DEFAULT_PROGRESSBAR_SPACINGX) / (m_iMaxPos - m_iMinPos);
    else if(GetType() == VerticalProgressBar)   // If its a vertical one
        m_fPPV = float(GetHeight() - 2 * DEFAULT_PROGRESSBAR_SPACINGY) / (m_iMaxPos - m_iMinPos);
    m_bMinToMax = mintomax;
}

tVERTEX2f CGUIProgressBar::GetRange()
{
    return tVERTEX2f(m_iMinPos, m_iMaxPos);
}

void CGUIProgressBar::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    if(GetEventHandler() != NULL)
    {
        tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);

        while(tmp != NULL)
        {
            switch(tmp->m_eMsg)
            {
                case MoveX:
                case MoveY:
                case MoveXY:
                    if(FindChild(tmp->m_pSender) || tmp->m_pSender == this)
                        OnSize(GetRect());
                    break;
            }

            tmp = GetEventHandler()->GetNextMsg(tmp);
        }
    }
}
