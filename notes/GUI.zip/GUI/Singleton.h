// CSingleton.h: interface for the CSingleton class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SINGLETON_H__A92F649D_846D_4119_B642_FA7730C464EF__INCLUDED_)
#define AFX_SINGLETON_H__A92F649D_846D_4119_B642_FA7730C464EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

#include <assert.h>

//!  Singleton class
/*!
    The derivatives of this class can be accessed anywhere (hence, singleton pattern)
*/
template<typename T>
class CSingleton
{
    static T * ms_singleton;
public:
    CSingleton()
    {
        assert(!ms_singleton);
        // use a cunning trick to get the singleton pointing to the start of the whole, rather than
        // the start of the CSingleton part of the object
        int offset   = (int)(T *)1 - (int)(CSingleton<T> *)(T *)1;
        ms_singleton = (T *)((int)this + offset);
    }
    ~CSingleton()
    {
        assert(ms_singleton);
        ms_singleton = 0;
    }
    /*!
        Aquire singleton (reference)
    */
    static inline T & GetSingleton()
    {
        assert(ms_singleton);
        return *ms_singleton;
    }

    /*!
        Aquire singleton (pointer)
    */
    static inline T * GetSingletonPtr()
    {
        // assert(ms_singleton);
        return ms_singleton;
    }
};

template<typename T>
T * CSingleton<T>::ms_singleton = 0;

#endif   // !defined(AFX_SINGLETON_H__A92F649D_846D_4119_B642_FA7730C464EF__INCLUDED_)
