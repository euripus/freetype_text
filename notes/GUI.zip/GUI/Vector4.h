// Vector3.h: interface for the CVector4 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VECTOR4_H__5EF287E0_EB3A_48B8_B1EA_B33B9387B469__INCLUDED_)
#define AFX_VECTOR4_H__5EF287E0_EB3A_48B8_B1EA_B33B9387B469__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

#pragma once

#include <assert.h>

//! Vector class of tuple 4.
/*!
    This class represents a vector with 4 tuples that is commonly used\n
    in algebra, geometry and other applications.
*/
class CVector4
{

public:
    union
    {
        struct
        {
            float x; /*!< X Value */
            float y; /*!< Y Value */
            float z; /*!< Z Value */
            float w; /*!< W Value */
        };
        float Elements[4]; /*!<Array of 4 elements */
    };

    // Constructors
    CVector4(float x = 0, float y = 0, float z = 0, float w = 0) : x(x), y(y), z(z), w(w) {}
    CVector4(CVector4 const & V) : x(V.x), y(V.y), z(V.z), w(V.w) {}

    /* --------------------------------- VECTOR IMPLEMENTATION -------------------------------//
    //----------------------------------------------------------------------------------------*/
    /*!
        Assignment operator with constant reference to values parameter
    */
    CVector4 const & operator=(CVector4 const & V)
    {
        x = V.x;
        y = V.y;
        z = V.z;
        w = V.w;
        return *this;
    }

    /*!
        Assignment operator with pointer to values parameter
    */
    CVector4 const & operator=(float const * d)
    {
        assert(d != 0x00000000);

        x = d[0];
        y = d[1];
        z = d[2];
        w = d[3];
        return *this;
    }
    /*!
        Access operator with i as index
    */
    float & operator[](int i) { return Elements[i]; }

    /*!
        Addition operator
    */
    const CVector4 operator+(CVector4 const & Vector) const
    {
        return CVector4(x + Vector.x, y + Vector.y, z + Vector.z, w + Vector.w);
    }

    /*!
        ++ operator
    */
    const CVector4 operator+() const { return CVector4(*this); }

    /*!
        Addition operator with assignment operator combination
    */
    CVector4 const & operator+=(CVector4 const & Vector)
    {
        x += Vector.x;
        y += Vector.y;
        z += Vector.z;
        w += Vector.w;

        return *this;
    }

    /*!
        Substraction operator with vector parameter
    */
    const CVector4 operator-(CVector4 const & Vector) const
    {
        return CVector4(x - Vector.x, y - Vector.y, z - Vector.z, w - Vector.w);
    }

    /*!
        -- operator
    */
    const CVector4 operator-() const { return CVector4(-x, -y, -z, -w); }

    /*!
        Substraction operator with assignment operator combination with vector parameter
    */
    CVector4 const & operator-=(CVector4 const & Vector)
    {
        x -= Vector.x;
        y -= Vector.y;
        z -= Vector.z;
        w -= Vector.w;

        return *this;
    }

    /*!
        Multiplication operator with a vector parameter
    */
    const CVector4 operator*(CVector4 const & Vector) const
    {
        return CVector4(x * Vector.x, y * Vector.y, z * Vector.z, w * Vector.w);
    }

    /*!
        Multiplication operator with assignment operator combination with vector parameter
    */
    CVector4 const & operator*=(CVector4 const & Vector)
    {
        x *= Vector.x;
        y *= Vector.y;
        z *= Vector.z;
        w *= Vector.w;

        return *this;
    }

    /*!
        Multiplication operator with scalar parameter
    */
    const CVector4 operator*(float const d) const { return CVector4(x * d, y * d, z * d, w * d); }

    /*!
        Multiplication operator with assignment operator combination with scalar parameter
    */
    CVector4 const & operator*=(float const d)
    {
        x *= d;
        y *= d;
        z *= d;
        w *= d;

        return *this;
    }

    /*!
        Division operator with vector parameter
    */
    const CVector4 operator/(CVector4 const & Vector) const
    {
        return CVector4(x / Vector.x, y / Vector.y, z / Vector.z, w / Vector.w);
    }

    /*!
        Division operator with assignment operator with vector parameter
    */
    CVector4 const & operator/=(CVector4 const & Vector)
    {
        x /= Vector.x;
        y /= Vector.y;
        z /= Vector.z;
        w /= Vector.w;

        return *this;
    }

    /*!
        Division operator with scalar
    */
    const CVector4 operator/(float const d) const
    {
        double const _d = 1.0f / d;
        return CVector4(x * _d, y * _d, z * _d, w * _d);
    }

    /*!
        Division operator with assignment operator with scalar parameter
    */
    CVector4 const & operator/=(float const d)
    {
        float const _d = 1.0f / d;
        x *= _d;
        y *= _d;
        z *= _d;
        w *= _d;

        return *this;
    }

    /*!
        Boolean (equality) operator
    */
    bool const operator==(CVector4 const & Vector) const
    {
        return (x == Vector.x) && (y == Vector.y) && (z == Vector.z) && (w == Vector.w);
    }

    /*!
        Boolean (inequality) operator
    */
    bool const operator!=(CVector4 const & Vector) const { return !((*this) == Vector); }

    /*!
        Comparative operator (More than)
    */
    bool const operator>(CVector4 const & v) { return (x > v.x && y > v.y && z > v.z && w > v.w); }

    /*!
        Comparative operator (Less than)
    */
    bool const operator<(CVector4 const & v) { return (x < v.x && y < v.y && z < v.z && w < v.w); }

    /*!
        Returns scalar value of dot product of (this DotProduct Vector)
    */
    float const DotProduct(CVector4 const & Vector) const
    {
        return x * Vector.x + y * Vector.y + z * Vector.z + w * Vector.w;
    }

    /*!
        Returns vector value of cross product of (this CrossProduct Vector)
    */
    const CVector4 CrossProduct(CVector4 const & Vector) const
    {
        return CVector4(y * Vector.z - Vector.y * z, z * Vector.x - Vector.z * x, x * Vector.y - Vector.x * y,
                        Vector.w);
    }

    /*!
        Returns lengh of this vector
    */
    float const Length() const { return sqrtf(x * x + y * y + z * z); }

    /*!
        Normalizes this vector
    */
    void Normalize()
    {
        float length = this->Length();
        (*this) /= length;
    }

    /*!
        Returns normal to this vector
    */
    CVector4 & Normal()
    {
        CVector4 tmp = *this;
        tmp.Normalize();
        return tmp;
    }
};

#endif   // !defined(AFX_VECTOR3_H__5EF287E0_EB3A_48B8_B1EA_B33B9387B469__INCLUDED_)
