#include "GUI.h"

CGUIWindow::CGUIWindow()
{
    SetType(Window);
    m_ReservedFlags.m_iFlag3 = WINDOW_STATUS_NOTFULL;
}

CGUIWindow::~CGUIWindow()
{
    OnDestroy();
}

int CGUIWindow::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIElement::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * child = GetChild(i);
        if(child->GetType() == Static)
        {
            if(child->GetXMLNode()->ToElement()->Attribute("Type") == NULL)
            {
                if(child->GetID() == WindowTitleBar)
                {
                    child->SetType(WindowTitleBar);
                    child->SetID(WindowTitleBar);

                    for(int j = 0; j < child->GetChildCount(); j++)
                    {
                        CGUIElement * elmnt = child->GetChild(j);
                        if(elmnt->GetID() == WINDOW_CLOSE_BTN)
                            elmnt->SetID(WINDOW_CLOSE_BTN);
                        else if(elmnt->GetID() == WINDOW_MIN_BTN)
                            elmnt->SetID(WINDOW_MIN_BTN);
                        else if(elmnt->GetID() == WINDOW_RESIZE_BTN)
                            elmnt->SetID(WINDOW_RESIZE_BTN);

                        if(elmnt->GetXMLNode()->ToElement()->Attribute("Type") != NULL)
                        {
                            if(stricmp(elmnt->GetXMLNode()->ToElement()->Attribute("Type"), "closebutton")
                               == 0)
                                elmnt->SetID(WINDOW_CLOSE_BTN);
                            else if(
                                stricmp(elmnt->GetXMLNode()->ToElement()->Attribute("Type"), "resizebutton")
                                == 0)
                                elmnt->SetID(WINDOW_RESIZE_BTN);
                            else if(stricmp(elmnt->GetXMLNode()->ToElement()->Attribute("Type"), "minbutton")
                                    == 0)
                                elmnt->SetID(WINDOW_MIN_BTN);
                        }
                    }
                }
                else if(child->GetID() == WindowStatusBar)
                    child->SetType(WindowStatusBar);
            }
            else if(stricmp(child->GetXMLNode()->ToElement()->Attribute("Type"), "titlebar") == 0)
            {
                child->SetType(WindowTitleBar);
                child->SetID(WindowTitleBar);

                for(int j = 0; j < child->GetChildCount(); j++)
                {
                    CGUIElement * elmnt = child->GetChild(j);
                    if(elmnt->GetID() == WINDOW_CLOSE_BTN)
                        elmnt->SetID(WINDOW_CLOSE_BTN);
                    else if(elmnt->GetID() == WINDOW_MIN_BTN)
                        elmnt->SetID(WINDOW_MIN_BTN);
                    else if(elmnt->GetID() == WINDOW_RESIZE_BTN)
                        elmnt->SetID(WINDOW_RESIZE_BTN);

                    if(elmnt->GetXMLNode()->ToElement()->Attribute("Type") != NULL)
                    {
                        if(stricmp(elmnt->GetXMLNode()->ToElement()->Attribute("Type"), "closebutton") == 0)
                            elmnt->SetID(WINDOW_CLOSE_BTN);
                        else if(
                            stricmp(elmnt->GetXMLNode()->ToElement()->Attribute("Type"), "resizebutton") == 0)
                            elmnt->SetID(WINDOW_RESIZE_BTN);
                        else if(
                            stricmp(elmnt->GetXMLNode()->ToElement()->Attribute("Type"), "minbutton") == 0)
                            elmnt->SetID(WINDOW_MIN_BTN);
                    }
                }
            }
            else if(stricmp(child->GetXMLNode()->ToElement()->Attribute("Type"), "StatusBar") == 0)
            {
                child->SetType(WindowStatusBar);
                child->SetID(WindowStatusBar);
            }
        }
    }

    OnSize(GetRect());
    return 1;
}

int CGUIWindow::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("Window");

    if(this_element != NULL)
        element = this_element;

    if(this_element != NULL)
        CGUIElement::Save(NULL, this_element);
    else
    {
        CGUIElement::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIWindow::OnDraw()
{
    OnSize(GetRect());
    CGUIElement::OnDraw();
}

int CGUIWindow::OnSize(tRect newRect)
{
    CGUIElement *titlebar = FindChild(WindowTitleBar), *statusbar = FindChild(WindowStatusBar);

    int min_height = MINIMUM_HEIGHT;
    int min_width  = MINIMUM_WIDTH;

    if(titlebar != NULL)
    {
        if(titlebar->GetHeight() < DEFAULT_TITLEBAR_HEIGHT)
            titlebar->SetHeight(DEFAULT_TITLEBAR_HEIGHT);

        int btn_count = 0;
        for(int i = 0; i < titlebar->GetChildCount(); i++)
        {
            CGUIElement * elmnt = titlebar->GetChild(i);
            if(elmnt->GetType() == Button)
                btn_count++;
        }

        min_width += titlebar->GetHeight() * btn_count;
        if(newRect.m_iRight - newRect.m_iLeft <= min_width)
        {
            SetRect(GetRect());
            return 0;
        }

        min_height += titlebar->GetHeight();
    }
    if(statusbar != NULL)
    {
        if(statusbar->GetHeight() < DEFAULT_STATUSBAR_HEIGHT)
            statusbar->SetHeight(DEFAULT_STATUSBAR_HEIGHT);

        min_height += statusbar->GetHeight();
    }

    if((newRect.m_iTop - newRect.m_iBottom) <= min_height)
        return 0;

    tRect TitleBarRect, StatusBarRect;

    if(titlebar != NULL)
    {
        TitleBarRect.m_iLeft   = GetRect().m_iLeft;
        TitleBarRect.m_iRight  = GetRect().m_iRight;
        TitleBarRect.m_iTop    = GetRect().m_iTop;
        TitleBarRect.m_iBottom = GetRect().m_iTop - titlebar->GetHeight();

        titlebar->SetRect(TitleBarRect);

        // Titlebar resized, let's assign its buttons rectangles
        if(titlebar->GetChildCount() != 0)
        {
            for(int i = 0; i < titlebar->GetChildCount(); i++)
            {
                CGUIElement * btn = titlebar->GetChild(i);
                if(btn->GetType() == Button)
                {
                    // There must be no border for the button!
                    if(btn->FindChild(Border) != NULL)
                        btn->RemoveChild(btn->FindChild(Border));

                    tRect btnRect;
                    btnRect.m_iRight  = GetRect().m_iRight - (i)*titlebar->GetHeight();
                    btnRect.m_iLeft   = GetRect().m_iRight - (i + 1) * titlebar->GetHeight();
                    btnRect.m_iTop    = titlebar->GetRect().m_iTop;
                    btnRect.m_iBottom = titlebar->GetRect().m_iBottom;

                    btn->SetRect(btnRect);
                }
            }
        }
    }

    if(statusbar != NULL)
    {
        StatusBarRect.m_iLeft   = GetRect().m_iLeft;
        StatusBarRect.m_iRight  = GetRect().m_iRight;
        StatusBarRect.m_iBottom = GetRect().m_iBottom;
        StatusBarRect.m_iTop    = GetRect().m_iBottom + statusbar->GetHeight();

        statusbar->SetRect(StatusBarRect);
    }

    return CGUIElement::OnSize(newRect);
}

void CGUIWindow::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);

    while(tmp != NULL)
    {
        switch(tmp->m_eMsg)
        {
            case MoveX:
            case MoveY:
            case MoveXY:
                if(tmp->m_pSender == FindChild(WindowTitleBar))
                {
                    // Allow to move window when title bar is moved
                    m_RestrictionFlags.m_iFlag2 = Default;
                    m_RestrictionFlags.m_iFlag3 = Default;

                    // Move window
                    OnMove(tmp->m_dwParam[0], tmp->m_dwParam[1]);

                    // Disallow to move window thereafter
                    m_RestrictionFlags.m_iFlag2 = RestrictMoveX;
                    m_RestrictionFlags.m_iFlag3 = RestrictMoveY;

                    OnSize(GetRect());
                    GetEventHandler()->RemoveMessage(tmp);
                    tmp = NULL;
                }
                break;

            case ButtonPressed:
                {
                    // If there's no Title bar in this window, do nothing with close/min/restore button
                    // presses in THIS window
                    CGUIElement * TitleBar = FindChild(WindowTitleBar);
                    if(TitleBar == NULL)
                        break;
                    else
                    {
                        // If the button pressed was a child of title bar, do:
                        if(TitleBar->FindChild(tmp->m_pSender))
                        {
                            if(tmp->m_pSender->GetID() == WINDOW_CLOSE_BTN)
                            {
                                Close();
                                GetEventHandler()->RemoveMessage(tmp);
                                tmp = NULL;
                                return;
                            }
                            else if(tmp->m_pSender->GetID() == WINDOW_RESIZE_BTN)
                            {
                                if(m_ReservedFlags.m_iFlag3 == WINDOW_STATUS_FULL)
                                {
                                    Restore();
                                    GetEventHandler()->RemoveMessage(tmp);
                                    tmp = NULL;
                                    return;
                                }
                                else if(m_ReservedFlags.m_iFlag3 == WINDOW_STATUS_NOTFULL)
                                {
                                    Maximize();
                                    GetEventHandler()->RemoveMessage(tmp);
                                    tmp = NULL;
                                    return;
                                }
                            }
                        }
                    }
                }

            case AppResize:
                {
                    if(m_ReservedFlags.m_iFlag3 == WINDOW_STATUS_FULL)
                    {
                        SetRect(m_BackupRect);
                        Maximize();
                    }
                    break;
                }
        }

        tmp = GetEventHandler()->GetNextMsg(tmp);
    }
}

void CGUIWindow::Close()
{
    BroadcastMessage(this, DeleteMe);
}

void CGUIWindow::Restore()
{
    SetRect(m_BackupRect);
    OnSize(GetRect());
    m_ReservedFlags.m_iFlag3 = WINDOW_STATUS_NOTFULL;
}

void CGUIWindow::Maximize()
{
    tRect FullRect = CGUI::GetSingleton().GetGUI()->GetRect();
    m_BackupRect   = GetRect();
    SetRect(FullRect);
    OnSize(GetRect());

    m_ReservedFlags.m_iFlag3 = WINDOW_STATUS_FULL;
}