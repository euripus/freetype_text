#include "GUI.h"

CGUIBorder::CGUIBorder()
{
    m_iBorderElmntDrag = -1;
    m_iBorderWidth     = DEFAULT_BORDER_WIDTH;
    m_iBorderSpacing   = DEFAULT_BORDER_SPACING;
    SetType(Border);
}

CGUIBorder::~CGUIBorder() {}

int CGUIBorder::Parse(TiXmlNode * this_node, string filename)
{
    char const *   value   = NULL;
    TiXmlElement * element = NULL;
    TiXmlNode *    node    = NULL;
    TiXmlDocument  doc;

    // If a user passed a filename, use it as an external link to our data for this element
    if(filename != "")
    {
        if(!doc.LoadFile(filename.c_str()))   // Try to parse data using given filename
            return 0;

        node = doc.FirstChild();   // Aquire first data node
    }

    if(this_node != NULL)
    {
        element = this_node->ToElement();

        if(element->Attribute("Filename") != NULL)
        {
            if(!doc.LoadFile(element->Attribute("Filename")))
                return 0;

            node = doc.FirstChild();
        }
    }

    if(!CGUIElement::Parse(this_node, filename))
        return 0;

    // Assign pointer to last node loaded
    m_pXMLNode = this_node;
    if(this_node == NULL)
        m_pXMLNode = node;

    element = m_pXMLNode->ToElement();

    value = element->Attribute("Width");
    if(value != NULL)
    {
        m_iBorderWidth = atoi(value);
        value          = NULL;
    }

    value = element->Attribute("Spacing");
    if(value != NULL)
    {
        m_iBorderSpacing = atoi(value);
        value            = NULL;
    }

    OnSize(GetParent()->GetRect());
    return 1;
}

int CGUIBorder::OnSize(tRect newSizeRect)
{
    // Recalculate each rectangle for each one of 8 elements and assign them

    SetRect(newSizeRect);

    tRect r[8];

    // Left
    r[0].m_iLeft   = newSizeRect.m_iLeft - m_iBorderWidth - m_iBorderSpacing;
    r[0].m_iRight  = newSizeRect.m_iLeft - m_iBorderSpacing;
    r[0].m_iTop    = newSizeRect.m_iTop + m_iBorderSpacing;
    r[0].m_iBottom = newSizeRect.m_iBottom - m_iBorderSpacing;

    // Right
    r[1].m_iLeft   = newSizeRect.m_iRight + m_iBorderSpacing;
    r[1].m_iRight  = newSizeRect.m_iRight + m_iBorderWidth + m_iBorderSpacing;
    r[1].m_iTop    = newSizeRect.m_iTop + m_iBorderSpacing;
    r[1].m_iBottom = newSizeRect.m_iBottom - m_iBorderSpacing;

    // Top
    r[2].m_iLeft   = newSizeRect.m_iLeft - m_iBorderSpacing;
    r[2].m_iRight  = newSizeRect.m_iRight + m_iBorderSpacing;
    r[2].m_iTop    = newSizeRect.m_iTop + m_iBorderWidth + m_iBorderSpacing;
    r[2].m_iBottom = newSizeRect.m_iTop + m_iBorderSpacing;

    // Bottom
    r[3].m_iLeft   = newSizeRect.m_iLeft - m_iBorderSpacing;
    r[3].m_iRight  = newSizeRect.m_iRight + m_iBorderSpacing;
    r[3].m_iTop    = newSizeRect.m_iBottom - m_iBorderSpacing;
    r[3].m_iBottom = newSizeRect.m_iBottom - m_iBorderWidth - m_iBorderSpacing;

    // Top Left
    r[4].m_iLeft   = r[0].m_iLeft;
    r[4].m_iRight  = r[0].m_iRight;
    r[4].m_iTop    = r[0].m_iTop + m_iBorderWidth;
    r[4].m_iBottom = r[0].m_iTop;

    // Top Right
    r[5].m_iLeft   = r[1].m_iLeft;
    r[5].m_iRight  = r[1].m_iRight;
    r[5].m_iTop    = r[1].m_iTop + m_iBorderWidth;
    r[5].m_iBottom = r[1].m_iTop;

    // Bottom Left
    r[6].m_iLeft   = r[0].m_iLeft;
    r[6].m_iRight  = r[0].m_iRight;
    r[6].m_iTop    = r[0].m_iBottom;
    r[6].m_iBottom = r[0].m_iBottom - m_iBorderWidth;

    // Bottom m_iRight
    r[7].m_iLeft   = r[1].m_iLeft;
    r[7].m_iRight  = r[1].m_iRight;
    r[7].m_iTop    = r[1].m_iBottom;
    r[7].m_iBottom = r[1].m_iBottom - m_iBorderWidth;

    for(int i = 0; i < 8; i++)
        GetChild(i)->SetRect(r[i]);

    return 1;
}

int CGUIBorder::OnLMouseDown(int x, int y)
{
    // Figuring out over which element the mouse was pressed on.
    // If none, return 0, otherwise assign drag flag and return 1
    for(int i = 0; i < 8; i++)
    {
        CGUIElement * border_element = GetChild(i);
        int           ret            = border_element->OnLMouseDown(x, y);
        if(ret == 1)
        {
            m_iBorderElmntDrag = i;
            return 1;
        }
    }
    return 0;
}

int CGUIBorder::OnLMouseUp(int x, int y)
{
    // In any way, assign 'none' to drag flag
    m_iBorderElmntDrag = -1;
    return 0;
}

int CGUIBorder::OnMouseMove(int x, int y)
{
    // Check if flag is on, and if it is:
    if(m_iBorderElmntDrag != -1)
    {
        // Aquire dragged element pointer
        CGUIElement * dragged_element = GetChild(m_iBorderElmntDrag);
        tRect         oldDraggedRect  = dragged_element->GetRect();
        tRect         oldParentRect   = GetParent()->GetRect();

        CGUIElement::OnMouseMove(x, y);   // Do general movement of dragged element border (if there's any)
        // Now, let's check if parent can accept the actual movement of that dragged border element that is
        // resizing it Firstly, let's find the displacement of the rectangle...

        // Do a pre-test resize of parent
        tRect newRect = dragged_element->GetRect();
        tRect diff_rect;
        diff_rect.m_iLeft   = newRect.m_iLeft - oldDraggedRect.m_iLeft;
        diff_rect.m_iRight  = newRect.m_iRight - oldDraggedRect.m_iRight;
        diff_rect.m_iTop    = newRect.m_iTop - oldDraggedRect.m_iTop;
        diff_rect.m_iBottom = newRect.m_iBottom - oldDraggedRect.m_iBottom;

        tRect newParentRect = oldParentRect;

        // Figure out which element was dragged

        // If it's left one, we decrease/increase left value of the parent rectangle
        if(m_iBorderElmntDrag == 0 || m_iBorderElmntDrag == 4
           || m_iBorderElmntDrag == 6)   // User drags leftmost elements, this decreasing m_iLeft
            newParentRect.m_iLeft = GetParent()->GetRect().m_iLeft + diff_rect.m_iLeft;

        // If it is the right one, decrease/increase right value of the parent rectangle
        if(m_iBorderElmntDrag == 1 || m_iBorderElmntDrag == 5
           || m_iBorderElmntDrag == 7)   // User drags rightmost elements, thus decreasing m_iRight
            newParentRect.m_iRight = GetParent()->GetRect().m_iRight + diff_rect.m_iRight;

        // And so on..
        if(m_iBorderElmntDrag == 2 || m_iBorderElmntDrag == 4
           || m_iBorderElmntDrag == 5)   // User drags topmost elements, thus increasing m_iTop
            newParentRect.m_iTop = GetParent()->GetRect().m_iTop + diff_rect.m_iTop;

        // And so on..
        if(m_iBorderElmntDrag == 3 || m_iBorderElmntDrag == 6
           || m_iBorderElmntDrag == 7)   // User drags topmost elements, thus decreasing m_iBottom
            newParentRect.m_iBottom = GetParent()->GetRect().m_iBottom + diff_rect.m_iBottom;

        // Resize parent using newly created rectangle
        if(!GetParent()->OnSize(newParentRect))
            return OnSize(oldParentRect);
        else
            return OnSize(newParentRect);
    }

    return 0;
}

void CGUIBorder::OnDraw()
{
    ProcessMessages();
    // Custom drawing procedure, since we don't want to draw the rectangle OF the border (e.g the inside part)
    // only the border elements
    for(int i = 0; i < 8; i++)
        GetChild(i)->OnDraw();
}

void CGUIBorder::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);
    while(tmp != NULL)
    {
        switch(tmp->m_eMsg)
        {
            // When parent is resized/moved, we update our border elements!
            case SizeX:
            case SizeY:
            case SizeXY:
            case MoveX:
            case MoveY:
            case MoveXY:
                {
                    if(tmp->m_pSender == GetParent())
                        OnSize(GetParent()->GetRect());

                    break;
                }
        }

        tmp = GetEventHandler()->GetNextMsg(tmp);
    }
}
