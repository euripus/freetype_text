// GUIListBox.cpp: implementation of the CGUIListBox class.
//
//////////////////////////////////////////////////////////////////////
#include "GUI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGUIListBox::CGUIListBox()
{
    m_bIdentSize = true;
    m_iSpacing   = 1;
    m_iCurSel    = -1;
    SetType(ListBox);
}

CGUIListBox::~CGUIListBox() {}

void CGUIListBox::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);

    while(tmp != NULL)
    {
        switch(tmp->m_eMsg)
        {
            case ButtonPressed:
                {
                    if((tmp->m_pReceiver == this)
                       && FindChild(tmp->m_pSender))   // If this button is a child of a listbox, do:
                    {
                        int cur_count = 0;   // Find it by count and set current selection (by index count)
                        for(int i = 0; i < GetChildCount(); i++)
                        {
                            CGUIElement * element = GetChild(i);
                            if(element->GetType() == Button)
                            {
                                cur_count++;
                                if(tmp->m_pSender == element)
                                {
                                    SetCurSel(cur_count);
                                    break;
                                }
                            }
                        }
                    }

                    break;
                }

            // Resize/move buttons if listbox was moved!
            case MoveX:
            case MoveY:
            case MoveXY:
            case SizeX:
            case SizeY:
            case SizeXY:
                {
                    OnPrepare();
                    break;
                }
        }
        tmp = GetEventHandler()->GetNextMsg(tmp);
    }
}

int CGUIListBox::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIElement::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    TiXmlElement * element = NULL;
    TiXmlNode *    node    = m_pXMLNode;
    char const *   value   = NULL;

    element = node->ToElement();

    value = element->Attribute("CurSel");
    if(value != NULL)
    {
        m_iCurSel = atoi(value);

        value = NULL;
    }

    OnPrepare();
    SetCurSel(m_iCurSel + 1);

    return 1;
}

int CGUIListBox::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("ListBox");

    if(this_element != NULL)
        element = this_element;

    if(m_iCurSel != -1)
    {
        // Sets attributes
        sprintf((char *)value, "%d", m_iCurSel);
        element->SetAttribute("CurSel", value);

        memset((void *)value, 0, 128);
    }

    if(this_element != NULL)
        CGUIElement::Save(NULL, this_element);
    else
    {
        CGUIElement::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIListBox::OnPrepare()
{
    int max_width = 0;

    // Find longest text entry size
    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * element = GetChild(i);

        if(element->GetType() == Button && ((CGUIButton *)element)->GetText() != "")
        {
            int ttl_width = 0;
            for(int i = 0; i < ((CGUIButton *)element)->GetText().size(); i++)
                ttl_width = ttl_width + ((CGUIButton *)element)->GetFont()->m_iQuadLengthX
                            + ((CGUIButton *)element)->GetFont()->m_iSpaceChar;

            if(max_width <= ttl_width)
                max_width = ttl_width;
        }
    }

    //	LimitWidth(true);
    m_bIdentSize = true;

    // OK, we got max length, assign each menu its rectangle

    CGUIElement * element = NULL;
    int           ycount  = 0;
    tRect         prev_rect;
    prev_rect.m_iLeft   = GetRect().m_iLeft;
    prev_rect.m_iRight  = GetRect().m_iRight;
    prev_rect.m_iTop    = GetRect().m_iTop;
    prev_rect.m_iBottom = GetRect().m_iTop;

    for(i = 0; i < GetChildCount(); i++)
    {
        element = GetChild(i);
        if(element->GetType() == Button)
        {
            tRect r;
            r.m_iLeft   = GetRect().m_iLeft;
            r.m_iRight  = GetRect().m_iRight;
            r.m_iTop    = prev_rect.m_iBottom - m_iSpacing;
            r.m_iBottom = r.m_iTop - ((CGUIButton *)element)->GetFont()->m_iQuadLengthY;
            element->SetRect(r);
            if(((r.m_iTop > GetRect().m_iBottom) && (r.m_iBottom < GetRect().m_iBottom))
               || r.m_iTop <= GetRect().m_iBottom)
                element->Hide();
            else
                element->Show();
            prev_rect = r;

            ycount++;
        }
    }
}

void CGUIListBox::SetCurSel(int sel)
{
    if(sel >= 0 && sel < GetChildCount())
    {
        m_iCurSel = sel - 1;

        CGUIElement * tmp = m_lstChildren.begin();
        m_lstChildren.set_ptr(tmp);

        int count = 0;
        while(tmp != NULL)
        {
            if(tmp->GetType() == Button)
            {
                if(count == m_iCurSel)
                    ((CGUIButton *)tmp)->SetButtonState(false, 1);
                else
                    ((CGUIButton *)tmp)->SetButtonState(false, 0);

                count++;
            }

            tmp = m_lstChildren.next();
        }
    }
    else
        m_iCurSel = -1;
}

int CGUIListBox::GetCurSel()
{
    return m_iCurSel;
}