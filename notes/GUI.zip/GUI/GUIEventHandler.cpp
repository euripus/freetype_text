#include "GUI.h"

CGUIEventHandler::CGUIEventHandler() {}

CGUIEventHandler::~CGUIEventHandler()
{
    Erase();
}

int CGUIEventHandler::PostMessage(CGUIElement * sender, CGUIElement * receiver, eMessage msg, DWORD lParam,
                                  DWORD wParam, int Timeout)
{
    tMessage * newMsg      = new tMessage;
    newMsg->m_eMsg         = msg;
    newMsg->m_pReceiver    = receiver;
    newMsg->m_pSender      = sender;
    newMsg->m_dwCreateTime = CGlobalTimer::GetSingleton().GetAbsoluteTime();

    if(receiver == NULL)
        newMsg->m_dwTimeout = 0;
    else
        newMsg->m_dwTimeout = Timeout;

    newMsg->m_dwParam[0] = (int)lParam;
    newMsg->m_dwParam[1] = (int)wParam;
    m_lstMessages.push_back(newMsg);
    return m_lstMessages.size();
}

void CGUIEventHandler::Dispatch()
{
    tMessage * msg = m_lstMessages.begin();
    m_lstMessages.set_ptr(msg);

    while(msg != NULL)
    {
        double cur_time = CGlobalTimer::GetSingleton().GetAbsoluteTime();
        if(cur_time - msg->m_dwCreateTime >= msg->m_dwTimeout)
        {
            if(msg->m_pReceiver != NULL)
                msg->m_pReceiver->ProcessMessage(msg);
        }

        msg = m_lstMessages.next();
    }
}

tMessage * CGUIEventHandler::GetNextMsg(tMessage * prev)
{
    if(prev == NULL)
        return m_lstMessages.begin();

    if(prev == m_lstMessages.ptr())
        return m_lstMessages.next();
    else
    {
        m_lstMessages.set_ptr(prev);
        return m_lstMessages.next();
    }

    return NULL;
}

void CGUIEventHandler::Flush()
{
    tMessage * msg = m_lstMessages.begin();
    m_lstMessages.set_ptr(msg);

    while(msg != NULL)
    {
        if(msg->m_dwTimeout == 0)
        {
            delete m_lstMessages.remove(msg);
            msg = m_lstMessages.begin();
            m_lstMessages.set_ptr(msg);
        }
        else
            msg = m_lstMessages.next();
    }
}

void CGUIEventHandler::Erase()
{
    m_lstMessages.erase();
}

void CGUIEventHandler::RemoveMessage(tMessage * msg)
{
    tMessage * tmp = m_lstMessages.remove(msg);
    if(tmp != NULL)
        delete msg;

    m_lstMessages.set_ptr(m_lstMessages.begin());
}

void CGUIEventHandler::RemoveReferences(CGUIElement * element)
{
    tMessage * msg = m_lstMessages.begin();
    m_lstMessages.set_ptr(msg);

    while(msg != NULL)
    {
        if(msg->m_pSender == element || msg->m_pReceiver == element)
        {
            RemoveMessage(msg);
            msg = m_lstMessages.begin();
            m_lstMessages.set_ptr(msg);
        }

        msg = m_lstMessages.next();
    }
}