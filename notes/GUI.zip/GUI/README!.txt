If you want to change the GUI that's being loaded at start, modify gui.xml file with reference to file that contains the GUI you need. For example, if you want to load GUI #1, create a gui.xml file in this directory with following content:
<GUI Filename="Data/GUI Set #1/XML/gui.xml"/>

Remember, if you press 's' key, the data will be saved into gui.xml file entirely, not by reference. So, if you would want to load other GUI next time, follow the step above and overwrite gui.xml with above content.
Also remember that I haven't done saving procedures for TabControl, Menu and Window controls, so take extra care putting them into GUI and attempting to save it. Make a backup copy if you do decide to put any of them, because I haven't tested how code will behave without them.
