// FontEngine.h: interface for the CFontEngine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FONTENGINE_H__9CCE99A4_F641_4A04_A24A_D0E8584462C1__INCLUDED_)
#define AFX_FONTENGINE_H__9CCE99A4_F641_4A04_A24A_D0E8584462C1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

#include "Common.h"
#include "Math.h"
#include "tinyxml.h"
#include "MaterialManager.h"

class CCustomFont;
class CBitmapFont;
//! Font engine class
/*!
    This engine stores and manages fonts in its database. (One instance only!)
*/
class CFontEngine : public CSingleton<CFontEngine>
{
public:
    CFontEngine();
    virtual ~CFontEngine();

    //! Parsing function
    virtual int Parse(TiXmlNode * this_node, char * filename = NULL);
    //! Adds (extracts) font from XML data
    int AddFont(TiXmlNode * this_node, char * filename = NULL);

    //! Returns font by index/Database ID
    CCustomFont * GetFont(int index = -1, int uid = -1);
    //! Returns font by name
    CCustomFont * GetFont(char const * font_name);
    //! Removes font
    int RemoveFont(CCustomFont * font);

    //! Sets text position
    void SetTextPos(CVector3 pos);
    //! Returns text position
    CVector3 GetTextPos();
    //! Returns font Unique ID (For database)
    unsigned int GetNextUID();

private:
    CDoubleList<CCustomFont *> m_lstFonts;     /*!< List of fonts */
    unsigned int               m_iLastFontUID; /*!< Last font Unique ID */
    CVector3                   m_TextPos;      /*!< Text position  */
};

//! Font type enum
enum eFontType
{
    Undefined_Font, /*!< Unidentified font */
    Logical_Font,   /*!< Logical font */
    Bitmap_Font     /*!< Bitmap font */
};

//! Custom font class
/*!
    A Font class that contains all data needed for\n
    STD font.
*/
class CCustomFont
{
public:
    CCustomFont();
    virtual ~CCustomFont();

    char m_strFilename[128]; /*!<  Font filename */
    char m_strFontName[128]; /*!<  Font name */

    DWORD m_dwFlags; /*!<  Custom flags */

    //! Default creation function
    virtual int Create();
    //! Parsing function
    virtual int Parse(TiXmlNode * this_node, char * filename);
    //! Drawing function
    virtual void Draw(char const * fmt, ...);
    //! Draws a character
    virtual void DrawChar(float x, float y, char c);
    //! Destruction function
    virtual void Destroy();

    //! Sets font name
    void SetFontName(char * name);
    //! Returns font name
    char * GetFontName();

    //! Sets font user ID
    void SetUserFontID(unsigned int id);
    //! Returns font user ID
    unsigned int GetUserFontID();

    //! Sets font type
    void SetFontType(eFontType type);
    //! Returns font type
    eFontType GetFontType();
    //! Returns font ID
    unsigned int GetID();

private:
    unsigned int m_uiFontID; /*!<  Font ID */
    unsigned int m_uiUserID; /*!<  User assigned ID */

protected:
    eFontType m_eFontType; /*!<  Font type */
};

//! Bitmap font class
/*!
    Font class that uses bitmap-mapped quads to print text.
*/
class CBitmapFont : public CCustomFont
{
public:
    CBitmapFont();
    virtual ~CBitmapFont();

    unsigned int m_iNI;          /*!< Normal or italic attribute */
    unsigned int m_iCharLengthX, /*!< Character width (in pixels) on the bitmap */
        m_iCharLengthY,          /*!< Character hieght (in pixels) on the bitmap */
        m_iQuadLengthX,          /*!< Quad width (in GL units) */
        m_iQuadLengthY,          /*!< Quad height (int GL units) */
        m_iSpaceChar;            /*!< Spacing between character quads (GL) */

    tMaterial * m_pFontMat; /*!< Pointer to characters bitmap */

    //! Parsing function
    virtual int Parse(TiXmlNode * this_node, char * filename);
    //! Drawing function
    virtual void Draw(char const * fmt, ...);
    //! Draw the char function
    virtual void DrawChar(float x, float y, char c);
    //! Creates this bitmap font
    int CreateBitmapFont(unsigned int normal_italic, unsigned int charx, unsigned int chary,
                         unsigned int quadx, unsigned int quady, unsigned int space);

private:
    int m_iFontBase; /*!< GL Font List ID */
    int m_iNumLists; /*!< Number of GL lists */
};

//! Commence blending
void BeginBlend();
//! Finish blending
void EndBlend();

//! Enter orthographic mode
void BeginOrtho();
//! Exit orthographic mode
void EndOrtho();

#endif   // !defined(AFX_FONTENGINE_H__9CCE99A4_F641_4A04_A24A_D0E8584462C1__INCLUDED_)
