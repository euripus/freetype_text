#include "GUI.h"

CGUIUtility::CGUIUtility()
{
    m_pActiveElement = NULL;
}

CGUIUtility::~CGUIUtility() {}

void CGUIUtility::SetActiveElement(CGUIElement * element)
{
    m_pActiveElement = element;
}

CGUIElement * CGUIUtility::GetActiveElement()
{
    return m_pActiveElement;
}

int CGUIUtility::OnMouseMove(int x, int y)
{
    int viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);
    int dy = viewport[3] - y;

    m_PrevMousePos = m_MousePos;
    m_MousePos     = tVERTEX2d(x, dy);
    if(!CGUI::GetSingleton().GetGUI()->OnMouseMove(x, dy))
        CGUIUtility::GetSingleton().m_MouseMessages.m_iFlag0 = Default;

    return 1;
}

int CGUIUtility::OnLMouseDown(int x, int y)
{
    int viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);
    int dy = viewport[3] - y;

    m_LMouseDown = tVERTEX2d(x, dy);
    CGUI::GetSingleton().GetGUI()->OnLMouseDown(x, dy);

    return 1;
}

int CGUIUtility::OnLMouseUp(int x, int y)
{
    int viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);
    int dy = viewport[3] - y;

    m_LMouseUp = tVERTEX2d(x, dy);
    CGUI::GetSingleton().GetGUI()->OnLMouseUp(x, dy);
    return 1;
}

int CGUIUtility::OnRMouseDown(int x, int y)
{
    int viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);
    int dy = viewport[3] - y;

    m_RMouseDown = tVERTEX2d(x, dy);
    CGUI::GetSingleton().GetGUI()->OnRMouseDown(x, dy);
    return 1;
}

int CGUIUtility::OnRMouseUp(int x, int y)
{
    int viewport[4];
    glGetIntegerv(GL_VIEWPORT, viewport);
    int dy = viewport[3] - y;

    m_RMouseUp = tVERTEX2d(x, dy);
    CGUI::GetSingleton().GetGUI()->OnRMouseUp(x, dy);
    return 1;
}

int CGUIUtility::OnKeyDown(int KeyCode)
{
    int ret          = CGUI::GetSingleton().GetGUI()->OnKeyDown(KeyCode);
    m_iKeys[KeyCode] = FALSE;

    return ret;
}

int CGUIUtility::OnKeyUp(int KeyCode)
{
    m_iKeys[KeyCode] = FALSE;
    return CGUI::GetSingleton().GetGUI()->OnKeyUp(KeyCode);
}

tVERTEX2d CGUIUtility::GetMousePos()
{
    return m_MousePos;
}

tVERTEX2d CGUIUtility::GetPrevMousePos()
{
    return m_PrevMousePos;
}

tVERTEX2d CGUIUtility::GetLMouseDown()
{
    return m_LMouseDown;
}

tVERTEX2d CGUIUtility::GetLMouseUp()
{
    return m_LMouseUp;
}

tVERTEX2d CGUIUtility::GetRMouseDown()
{
    return m_LMouseDown;
}

tVERTEX2d CGUIUtility::GetRMouseUp()
{
    return m_LMouseUp;
}

bool PointInRect(tRect rect, int x, int y)
{
    bool good_x = (x > rect.m_iLeft) & (x < rect.m_iRight);
    bool good_y = (y > rect.m_iBottom) & (y < rect.m_iTop);

    return good_x & good_y;
}