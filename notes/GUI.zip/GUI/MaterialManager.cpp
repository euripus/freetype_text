// MaterialManager.cpp: implementation of the CMaterialManager class.
//
//////////////////////////////////////////////////////////////////////

#include "MaterialManager.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMaterialManager::CMaterialManager()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - Material Manager: Initialized.\n");
#endif
}

CMaterialManager::~CMaterialManager()
{
#ifdef USE_GLOBAL_LOGGER
    CGlobalLogger::GetSingleton().Write("GUI Framework - Material Manager: Exiting.\n");
#endif

    m_lstMaterialDb.erase();
    m_lstMaterials.erase();
}

int CMaterialManager::GetMaterialCount()
{
    return m_lstMaterials.size();
}

int CMaterialManager::Parse(TiXmlNode * parent_node, char * filename)
{
    int mat_count = 0;

    char const *   value       = NULL;
    TiXmlElement * mat_element = NULL;
    TiXmlNode *    mat_node    = NULL;

    TiXmlDocument doc(filename);

    if(filename != NULL)
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return mat_count;

        mat_node = doc.FirstChild();
    }
    else
        mat_node = parent_node->FirstChild();

    if(mat_node == NULL)
        return mat_count;

    while(mat_node != NULL)
    {
        mat_element = mat_node->ToElement();
        if(stricmp(mat_element->Value(), "material") == 0)
        {
            tMaterial * newMaterial = new tMaterial;

            CTextureManager::GetSingleton().Parse(mat_node, NULL);

            TiXmlNode *    tex_node    = NULL;
            TiXmlElement * tex_element = NULL;
            tex_node                   = mat_node->FirstChild();

            bool already_added = false;

            while(tex_node != NULL)
            {
                tex_element = tex_node->ToElement();
                if(stricmp(tex_element->Value(), "texture") == 0)
                    newMaterial->m_pTexPtr = CTextureManager::GetSingleton().GetTexture(
                        (char *)tex_element->Attribute("Filename"));

                tex_node = mat_node->IterateChildren(tex_node);
            }

            value = mat_element->Attribute("TexRefID");
            if(value != NULL)
            {
                newMaterial->m_pTexPtr = CTextureManager::GetSingleton().GetTexture(-1, atoi(value), -1);
                value                  = NULL;
            }

            tMaterialEntry * newEntry = new tMaterialEntry;

            value = mat_element->Attribute("RefID");
            if(value != NULL)
            {
                if(CMaterialManager::GetSingleton().GetMaterial(-1, atoi(value)) != NULL)
                {
                    already_added = true;
                    delete newMaterial;
                    delete newEntry;
                    newEntry    = NULL;
                    newMaterial = NULL;
                }
                else
                {
                    // Found material with same ID
                    newEntry->m_iDbID     = atoi(value);
                    newEntry->m_pMaterial = newMaterial;
                }

                value = NULL;
            }

            if(newEntry != NULL)
            {
                value = mat_element->Attribute("Name");
                if(value != NULL)
                {
                    // if(CMaterialManager::GetSingleton().GetMaterial(-1, atoi(value)) !=NULL)
                    //  Found material with same ID
                    strncpy(newEntry->m_strName, value, 128);
                    newEntry->m_pMaterial = newMaterial;
                    value                 = NULL;
                }

                m_lstMaterialDb.push_back(newEntry);
            }

            if(!already_added)
            {
                value = mat_element->Attribute("Ambient");
                if(value != NULL)
                {
                    int col[3] = {0, 0, 0};
                    sscanf(value, "%d,%d,%d", &col[0], &col[1], &col[2]);
                    newMaterial->m_Ambient = tRGBA(col[0], col[1], col[2], -1);
                    value                  = NULL;
                }

                value = mat_element->Attribute("Diffuse");
                if(value != NULL)
                {
                    int col[3] = {0, 0, 0};
                    sscanf(value, "%d,%d,%d", &col[0], &col[1], &col[2]);
                    newMaterial->m_Diffuse = tRGBA(col[0], col[1], col[2], -1);
                    value                  = NULL;
                }

                value = mat_element->Attribute("Emissive");
                if(value != NULL)
                {
                    int col[3] = {0, 0, 0};
                    sscanf(value, "%d,%d,%d", &col[0], &col[1], &col[2]);
                    newMaterial->m_Emissive = tRGBA(col[0], col[1], col[2], -1);
                    value                   = NULL;
                }

                value = mat_element->Attribute("Specular");
                if(value != NULL)
                {
                    int col[3] = {0, 0, 0};
                    sscanf(value, "%d,%d,%d", &col[0], &col[1], &col[2]);
                    newMaterial->m_Specular = tRGBA(col[0], col[1], col[2], -1);
                    value                   = NULL;
                }

                value = mat_element->Attribute("Shininess");
                if(value != NULL)
                {
                    sscanf(value, "%d", &newMaterial->m_fShininess);
                    value = NULL;
                }

                value = mat_element->Attribute("Name");
                if(value != NULL)
                {
                    strncpy(newMaterial->m_strName, value, 128);

                    value = NULL;
                }

#ifdef USE_GLOBAL_LOGGER
                CGlobalLogger::GetSingleton().Write(
                    "GUI Framework - Material Manager: Material added successfully. (%s)\n",
                    newMaterial->m_strName);
#endif

                m_lstMaterials.push_back(newMaterial);
                mat_count++;
            }
        }

        if(parent_node == NULL)
            mat_node = doc.IterateChildren(mat_node);
        else
            mat_node = parent_node->IterateChildren(mat_node);
    }

    return mat_count;
}

tMaterial * CMaterialManager::GetMaterial(int index, int db_index)
{
    if(index == -1)
    {
        tMaterialEntry * mat_entry = m_lstMaterialDb.begin();
        m_lstMaterialDb.set_ptr(mat_entry);

        while(mat_entry != NULL)
        {
            if(mat_entry->m_iDbID == db_index)
                return mat_entry->m_pMaterial;

            mat_entry = m_lstMaterialDb.next();
        }
    }
    else
    {
        int              count     = 0;
        tMaterialEntry * mat_entry = m_lstMaterialDb.begin();
        m_lstMaterialDb.set_ptr(mat_entry);

        while(mat_entry != NULL)
        {
            if(count == index)
                return mat_entry->m_pMaterial;

            mat_entry = m_lstMaterialDb.next();
            count++;
        }
    }

    return NULL;
}

tMaterial * CMaterialManager::GetMaterial(char const * name)
{
    if(name != NULL)
    {
        if(strlen(name) == 0)
            return NULL;

        tMaterialEntry * mat_entry = m_lstMaterialDb.begin();
        m_lstMaterialDb.set_ptr(mat_entry);

        while(mat_entry != NULL)
        {
            if(stricmp(mat_entry->m_strName, name) == 0)
                return mat_entry->m_pMaterial;

            mat_entry = m_lstMaterialDb.next();
        }
    }

    return NULL;
}

bool CMaterialManager::RemoveMaterial(tMaterial * mat)
{
    if(mat == NULL)
        return false;

    tMaterial * to_be_removed = m_lstMaterials.remove(mat);
    if(to_be_removed != NULL)
    {
        tMaterialEntry * entry_with_mat_ptr = m_lstMaterialDb.begin();
        m_lstMaterialDb.set_ptr(entry_with_mat_ptr);

        while(entry_with_mat_ptr != NULL)
        {
            if(entry_with_mat_ptr->m_pMaterial == to_be_removed)
                delete m_lstMaterialDb.remove(entry_with_mat_ptr);

            entry_with_mat_ptr = m_lstMaterialDb.next();
        }

        delete to_be_removed;
        return true;
    }

    return false;
}

int CMaterialManager::GetMaterialDbID(tMaterial * mat)
{
    if(mat != NULL)
    {
        tMaterialEntry * mat_entry = m_lstMaterialDb.begin();
        m_lstMaterialDb.set_ptr(mat_entry);

        while(mat_entry != NULL)
        {
            if(mat_entry->m_pMaterial == mat)
                return mat_entry->m_iDbID;

            mat_entry = m_lstMaterialDb.next();
        }
    }

    return -1;
}