#ifndef ANIMATED_TEXTURE_INCLUDED
#define ANIMATED_TEXTURE_INCLUDED

#include <windows.h>
#include <stdio.h>

#include "MaterialManager.h"
#include "Timer.h"

//! Rectangle structure
/*!
    This structure represents a rectangle with 4 corners.
*/
struct tRect
{
public:
    union
    {
        struct
        {
            int m_iLeft,   /*!< Left Attribute */
                m_iRight,  /*!< Right Attribute */
                m_iTop,    /*!< Top Attribute */
                m_iBottom; /*!< Bottom Attribute */
        };
        int m_iSide[4]; /*!< An array of above elements that can be accessed by index */
    };

    tRect(){};
    virtual ~tRect(){};

    tRect(int x1, int x2, int y1, int y2)
    {
        m_iLeft   = x1;
        m_iRight  = x2;
        m_iTop    = y1;
        m_iBottom = y2;
    };

    /*!
        Assignment operator with constant reference to values parameter
    */
    tRect const & operator=(tRect const & other)
    {
        m_iLeft   = other.m_iLeft;
        m_iRight  = other.m_iRight;
        m_iTop    = other.m_iTop;
        m_iBottom = other.m_iBottom;

        return *this;
    };

    /*!
        Index operator
    */
    int const operator[](int i)
    {
        if(i == 0)
            return m_iLeft;
        else if(i == 1)
            return m_iRight;
        else if(i == 2)
            return m_iTop;
        else if(i == 3)
            return m_iBottom;
    };

    /*!
        Returns width of the rectangle
    */
    unsigned int Width() { return m_iRight - m_iLeft; };

    /*!
        Returns height of the rectangle
    */
    unsigned int Height() { return m_iTop - m_iBottom; };
};

//!  Animation class.
/*!
    This class performs an animation sequence based on the parameters given,\n
    and also on the passed time when Animate() is called.
*/
class CAnimatedTexture
{
public:
    CAnimatedTexture()
    {
        m_piTexIndex    = NULL;
        m_iTexCount     = 0;
        m_iCurrentFrame = 0;
        m_iFrameCount   = 0;
        m_pFrameOffset  = NULL;
        m_fLastTime     = 0;
        m_bLoop         = false;

        Reset();
    };

    virtual ~CAnimatedTexture() { Destroy(); };

    int * m_piTexIndex; /*!< This variable stores a list of texture indices from CMaterial/CTextureManager. */
    int   m_iTexCount;  /*!< This variable stores a number of textures/materials for the list above
                           (m_piTexIndex). */
    int    m_iFrameCount; /*!< This variable stores a number of frames in this animation. */
    int    m_iLoopsCount; /*!< This variable stores a total number of loops this animation has to run thru. */
    int    m_iCurrentLoop;  /*!< This variable stores the current loop index. */
    int    m_iCurrentFrame; /*!< This variable stores a current frame value for the animation. */
    double m_fLastTime; /*!< This variable stores the last time the animation has been called successfully. */
    tRect * m_pFrameOffset; /*!< These variables (n) store the rectangle offsets for the texture. */
    bool    m_bLoop; /*!< This variable stores the boolean value that determines if it has to loop thru the
                        animation. */
    bool m_bAnimationComplete; /*!< This is a variable that indicates whether an animation has been completed.
                                */

public:
    /*!
        Performs the animation\n
      \param dt - The elapsed time to undertake animation to next frame.
    */
    __forceinline bool Animate(double dt)
    {
        double cur_time = CGlobalTimer::GetSingleton().GetAbsoluteTime();
        if(m_iCurrentFrame != (m_iFrameCount - 1))
        {
            if((cur_time - m_fLastTime) >= dt)
            {
                m_iCurrentFrame++;
                m_fLastTime = cur_time;
            }
        }
        else
        {
            if(m_bLoop)
            {
                if(m_iCurrentLoop != (m_iLoopsCount - 1))
                {
                    m_iCurrentLoop++;
                    m_bAnimationComplete = false;
                }
                else
                    m_bAnimationComplete = true;
            }

            m_bAnimationComplete = true;
        }

        return m_bAnimationComplete;
    };

    /*!
        Resets the animation
    */
    __forceinline void Reset()
    {
        m_fLastTime          = 0;
        m_iCurrentFrame      = 0;
        m_bAnimationComplete = false;
        m_iCurrentLoop       = 0;
    };

    /*!
        Destroys the animation
    */
    __forceinline void Destroy()
    {
        if(m_piTexIndex)
        {
            delete[] m_piTexIndex;
            m_piTexIndex = NULL;
        }

        if(m_pFrameOffset)
        {
            delete[] m_pFrameOffset;
            m_pFrameOffset = NULL;
        }
    };

    //! Parses the animation data from file or from XML node
    /*!
      filename - the filename containing XML data.\n
      this_node - Pointer to data XML Node.
    */
    virtual int Parse(TiXmlNode * this_node, char * filename);
};

#endif