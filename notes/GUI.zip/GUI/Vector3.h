// Vector3.h: interface for the CVector3 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VECTOR3_H__5EF287E0_EB3A_48B8_B1EA_B33B9387B469__INCLUDED_)
#define AFX_VECTOR3_H__5EF287E0_EB3A_48B8_B1EA_B33B9387B469__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif   // _MSC_VER > 1000

#include <math.h>
#include <assert.h>

#pragma once
//!  Vector class of tuple 3.
/*!
    This class represents a vector with 3 tuples that is commonly used\n
    in algebra, geometry and other applications.
*/
class CVector3
{

public:
    union
    {
        struct
        {
            float x; /*!< X Value */
            float y; /*!< Y Value */
            float z; /*!< Z Value */
        };
        float Elements[3]; /*!< An array of 3 elements */
    };

    // Constructors
    CVector3(float x = 0, float y = 0, float z = 0) : x(x), y(y), z(z) {}
    CVector3(CVector3 const & V) : x(V.x), y(V.y), z(V.z) {}

    /* --------------------------------- VECTOR IMPLEMENTATION -------------------------------//
    //----------------------------------------------------------------------------------------*/
    /*!
        Assignment operator with vector parameter
    */
    CVector3 const & operator=(CVector3 const & V)
    {
        x = V.x;
        y = V.y;
        z = V.z;
        return *this;
    }

    /*!
        Assignment operator with pointer to values parameter
    */
    CVector3 const & operator=(float const * d)
    {
        assert(d != 0x00000000);
        x = d[0];
        y = d[1];
        z = d[2];
        return *this;
    }

    /*!
        Access operator with i as index
    */
    float & operator[](int i)
    {
        assert(i >= 0 && i < 3);
        return Elements[i];
    }

    /*!
        Addition operator
    */
    const CVector3 operator+(CVector3 const & Vector) const
    {
        return CVector3(x + Vector.x, y + Vector.y, z + Vector.z);
    }

    /*!
        ++ operator
    */
    const CVector3 operator+() const { return CVector3(*this); }

    /*!
        Addition operator with assignment operator combination
    */
    CVector3 const & operator+=(CVector3 const & Vector)
    {
        x += Vector.x;
        y += Vector.y;
        z += Vector.z;

        return *this;
    }

    /*!
        Substraction operator with vector parameter
    */
    const CVector3 operator-(CVector3 const & Vector) const
    {
        return CVector3(x - Vector.x, y - Vector.y, z - Vector.z);
    }

    /*!
        -- operator
    */
    const CVector3 operator-() const { return CVector3(-x, -y, -z); }

    /*!
        Substraction operator with assignment operator combination with vector parameter
    */
    CVector3 const & operator-=(CVector3 const & Vector)
    {
        x -= Vector.x;
        y -= Vector.y;
        z -= Vector.z;

        return *this;
    }

    /*!
        Multiplication operator with a vector parameter
    */
    const CVector3 operator*(CVector3 const & Vector) const
    {
        return CVector3(x * Vector.x, y * Vector.y, z * Vector.z);
    }

    /*!
        Multiplication operator with assignment operator combination with vector parameter
    */
    CVector3 const & operator*=(CVector3 const & Vector)
    {
        x *= Vector.x;
        y *= Vector.y;
        z *= Vector.z;

        return *this;
    }

    /*!
        Multiplication operator with scalar parameter
    */
    const CVector3 operator*(float const d) const { return CVector3(x * d, y * d, z * d); }

    /*!
        Multiplication operator with assignment operator combination with scalar parameter
    */
    CVector3 const & operator*=(float const d)
    {
        x *= d;
        y *= d;
        z *= d;

        return *this;
    }

    /*!
        Division operator with vector parameter
    */
    const CVector3 operator/(CVector3 const & Vector) const
    {
        return CVector3(x / Vector.x, y / Vector.y, z / Vector.z);
    }

    /*!
        Division operator with assignment operator with vector parameter
    */
    CVector3 const & operator/=(CVector3 const & Vector)
    {
        x /= Vector.x;
        y /= Vector.y;
        z /= Vector.z;

        return *this;
    }

    /*!
        Division operator with scalar
    */
    const CVector3 operator/(float const d) const
    {
        double const _d = 1.0f / d;
        return CVector3(x * _d, y * _d, z * _d);
    }

    /*!
        Division operator with assignment operator with scalar parameter
    */
    CVector3 const & operator/=(float const d)
    {
        float const _d = 1.0f / d;
        x *= _d;
        y *= _d;
        z *= _d;

        return *this;
    }

    /*!
        Boolean (equality) operator
    */
    bool const operator==(CVector3 const & Vector) const
    {
        return (x == Vector.x) && (y == Vector.y) && (z == Vector.z);
    }

    /*!
        Boolean (inequality) operator
    */
    bool const operator!=(CVector3 const & Vector) const { return !((*this) == Vector); }

    /*!
        Comparative operator (More than)
    */
    bool const operator>(CVector3 const & v) { return (x > v.x && y > v.y && z > v.z); }

    /*!
        Comparative operator (Less than)
    */
    bool const operator<(CVector3 const & v) { return (x < v.x && y < v.y && z < v.z); }

    /*!
        Returns scalar value of dot product of (this DotProduct Vector)
    */
    float const DotProduct(CVector3 const & Vector) const
    {
        return x * Vector.x + y * Vector.y + z * Vector.z;
    }

    /*!
        Returns vector value of cross product of (this CrossProduct Vector)
    */
    const CVector3 CrossProduct(CVector3 const & Vector) const
    {
        return CVector3(y * Vector.z - Vector.y * z, z * Vector.x - Vector.z * x,
                        x * Vector.y - Vector.x * y);
    }

    /*!
        Returns lengh of this vector
    */
    float const Length() const { return sqrtf(x * x + y * y + z * z); }

    /*!
        Normalizes this vector
    */
    void Normalize()
    {
        float length = this->Length();
        x /= length;
        y /= length;
        z /= length;
    }

    /*!
        Returns normal to this vector
    */
    CVector3 & Normal()
    {
        CVector3 tmp = *this;
        tmp.Normalize();
        return tmp;
    }
};

#endif   // !defined(AFX_VECTOR3_H__5EF287E0_EB3A_48B8_B1EA_B33B9387B469__INCLUDED_)
