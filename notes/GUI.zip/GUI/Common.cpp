#include "Common.h"

int roundf(float val)
{
    int   whole_part = (int)val;
    float exp_part   = whole_part + 0.5;
    if(val >= exp_part && val < whole_part + 1)
        return whole_part + 1;

    return whole_part;
}