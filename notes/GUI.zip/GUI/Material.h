// Texture.h: interface for the CMaterial class.
//
//////////////////////////////////////////////////////////////////////
#pragma once

#include <windows.h>
#include <stdio.h>
#include <GL\gl.h>
#include <GL\glu.h>
// #include <GL\glh_genext.h>
#include <gl\glaux.h>   // Header File For The Glaux Library

#include "tinyxml.h"

#define SAFEDEL(x)  \
    if(x != NULL)   \
    {               \
        delete[] x; \
        x = NULL;   \
    }
#pragma warning(disable:4018)

enum MAT_RENDER
{
    MAT,
    TEX,
    MAT_TEX,
    TEX_COLOR,
};

#define MAX_EMBOSS   (float)0.01f   // Maximum Emboss-Translate. Increase To Get Higher Immersion
#define __ARB_ENABLE true           // Used To Disable ARB Extensions Entirely
// #define EXT_INFO								// Uncomment To See Your Extensions At Start-Up?
#define MAX_EXTENSION_SPACE  10240   // Characters For Extension-Strings
#define MAX_EXTENSION_LENGTH 256     // Maximum Characters In One Extension-String

#if !defined(AFX_TEXTURE_H__F46069B2_AE7A_11D5_8A89_444553540000__INCLUDED_)
#define AFX_TEXTURE_H__F46069B2_AE7A_11D5_8A89_444553540000__INCLUDED_

#define TGA_RGB 2    // This tells us it's a normal RGB (really BGR) file
#define TGA_A   3    // This tells us it's a ALPHA file
#define TGA_RLE 10   // This tells us that the targa is Run-Length Encoded (RLE)

#define BITMAP_ID 0x4D42

//! RGBA structure
/*!
    This structure represents an RGBA color.\n
    Consists of 4 (four) colors.
*/
struct tRGBA
{
    tRGBA(float r = 0, float g = 0, float b = 0, float a = 0) : m_fR(r), m_fG(g), m_fB(b), m_fA(a) {}
    union
    {
        struct
        {
            float m_fR; /*!< Red channel value */
            float m_fG; /*!< Green channel value */
            float m_fB; /*!< Blue channel value */
            float m_fA; /*!< Alpha value */
        };

        float m_fRGBA[4]; /*!< An array for 4 members above that can be accessed by index. */
    };
};

//! Image structure
/*!
    An external structure used for storing images.
*/
typedef struct _ImageRec
{
    unsigned short imagic;
    unsigned short type;
    unsigned short dim;
    unsigned short xsize, ysize, zsize;
    unsigned int   min, max;
    unsigned int   wasteBytes;
    char           name[80];
    unsigned long  colorMap;
    FILE *         file;
    unsigned char *tmp, *tmpR, *tmpG, *tmpB;
    unsigned long  rleEnd;
    unsigned int * rowStart;
    int *          rowSize;
} ImageRec;

//! OpenGL texture parameters (see glTexParameteri)
struct tTexParam
{
    unsigned int m_uiTarget; /*!< Texture target (GL Specific) */
    unsigned int m_uiName;   /*!< Parameter name (GL Specific) */
    unsigned int m_uiParam;  /*!< Parameter attribute (GL Specific */
};

//! Texture structure
/*!
    This structure represents a standard texture\n
    with relevant attributes.
*/
struct tTexture
{
    unsigned int m_iBpp;      /*!< Depth value (in bits) */
    unsigned int m_iWidth;    /*!< Texture width */
    unsigned int m_iHeight;   /*!< Texture height */
    unsigned int m_id;        /*!< Texture ID */
    unsigned int m_iError;    /*!< Error code (assigned on load if error occured) */
    int          m_MaskTexID; /*!< Masking texture ID (Not used) */

    GLubyte * m_cData;            /*!< Pixel data */
    char      m_strFilename[255]; /*!< Texture filename */

    tTexParam *  m_pTexParams;      /*!< OpenGL Texture parameters (see glTexParameteri) */
    unsigned int m_uiTexParamCount; /*!< Number of OpenGL parameters */

    tTexture()
    {
        m_iBpp            = 0;
        m_iWidth          = 0;
        m_iHeight         = 0;
        m_id              = -1;
        m_cData           = NULL;
        m_MaskTexID       = -1;
        m_pTexParams      = NULL;
        m_uiTexParamCount = 0;
    };

    ~tTexture()
    {
        if(m_id > 0)
        {
            glDeleteTextures(1, &m_id);
            m_id = 0;
        }
        if(m_cData != NULL)
            SAFEDEL(m_cData)
    };
};

//! Material structure
/*!
    This structure represents a standard material\n
    with relevant attributes.
*/
struct tMaterial
{
    tTexture *   m_pTexPtr;    /*!< Texture this material uses */
    unsigned int m_uiTexCount; /*!< Number of textures for this material (UNUSED!) */

    tRGBA m_Ambient, /*!< Ambient Attribute */
        m_Diffuse,   /*!< Diffuse Attribute */
        m_Emissive,  /*!< Emissive Attribute */
        m_Specular;  /*!< Specular Attribute */

    float        m_fShininess; /*!< Shininess attribute */
    unsigned int m_iError;     /*!< Material error code */

    char m_strName[128]; /*!< Material filename */

    tMaterial()
    {
        for(int i = 0; i < 4; i++)
        {
            m_Ambient.m_fRGBA[i]  = 255.0;
            m_Diffuse.m_fRGBA[i]  = 255.0;
            m_Emissive.m_fRGBA[i] = 255.0;
            m_Specular.m_fRGBA[i] = 255.0;
        }
        m_pTexPtr    = NULL;
        m_fShininess = 0;
        m_iError     = 0;
        for(i = 0; i < 128; i++)
            m_strName[i] = '\0';
    }

    ~tMaterial(){};
};

#define FILE_NOT_FOUND             WM_USER + 256
#define ERROR_ALLOC                WM_USER + 257
#define INVALID_TEXTURE_DIMENSIONS WM_USER + 258
#define CANNOT_LOAD                WM_USER + 259
#define INVALID_PIXEL_FORMAT       WM_USER + 260
#define INVALID_FILE_FORMAT_SPEC   WM_USER + 261

#endif   // !defined(AFX_TEXTURE_H__F46069B2_AE7A_11D5_8A89_444553540000__INCLUDED_)

bool BitBlt(tMaterial src, tMaterial dst, GLshort src_xstart, GLshort src_ystart, GLshort src_xend,
            GLshort src_yend, GLshort dst_xstart, GLshort dst_ystart, GLshort blend, GLshort alpha);

bool      isInString(char * string, char * search);
bool      CheckSize(unsigned int Size);
GLubyte * ConvertPCX(GLubyte * dt, GLubyte * Palette, unsigned int Width, unsigned int Height);

// All works
bool LoadBMP(char * filename, tTexture * mat);
bool LoadTGA(char * filename, tTexture * mat);
bool LoadPCX(char * filename, tTexture * mat);
bool LoadRGB(char * filename, tTexture * mat);
bool LoadRAW(char * filename, int iSize, tTexture * mat);   // Not checked!

void CreateAlpha(tTexture * mat, tRGBA color);
void CreateGLTexture(tTexture * mat);

bool LoadTexture(char * filename, tTexture * mat);

void ApplyTexture(tTexture * texture);
void ApplyMaterial(tMaterial * mat, MAT_RENDER rendermode = MAT_TEX, float * color = NULL);

// MISC
bool SaveScreenshot(RECT Region, char * filename);