// Define this if you want to use global logger
#define USE_GLOBAL_LOGGER 1