#include "GUI.h"

CGUIStatic::CGUIStatic()
{
    m_bWrapText = true;
    SetType(Static);
    m_iTextHAlign = 0;
    m_iTextVAlign = 0;
    m_pFont       = NULL;
}

CGUIStatic::~CGUIStatic()
{
    OnDestroy();
}

void CGUIStatic::SetFont(CBitmapFont * font)
{
    m_pFont = font;
}

CBitmapFont * CGUIStatic::GetFont()
{
    return m_pFont;
}

int CGUIStatic::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIElement::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    // START PARSING ELEMENT PROPERTIES
    char const *   value   = NULL;
    TiXmlElement * element = NULL;
    element                = m_pXMLNode->ToElement();

    value = element->Attribute("Text");
    if(value != NULL)
    {
        SetText((string)value);
        value = NULL;
    }

    value = element->Attribute("FontByName");
    if(value != NULL)
    {
        CCustomFont * font = CFontEngine::GetSingleton().GetFont(value);
        if(font->GetFontType() == Bitmap_Font)
            m_pFont = (CBitmapFont *)font;

        value = NULL;
    }

    value = element->Attribute("HAlign");
    if(value != NULL)
    {
        if(stricmp(value, "left") == 0)
            m_iTextHAlign = 0;
        else if(stricmp(value, "center") == 0)
            m_iTextHAlign = 1;
        else if(stricmp(value, "right") == 0)
            m_iTextHAlign = 2;

        value = NULL;
    }

    value = element->Attribute("VAlign");
    if(value != NULL)
    {
        if(stricmp(value, "top") == 0)
            m_iTextVAlign = 0;
        else if(stricmp(value, "center") == 0)
            m_iTextVAlign = 1;
        else if(stricmp(value, "bottom") == 0)
            m_iTextVAlign = 2;

        value = NULL;
    }

    value = element->Attribute("Wrap");
    if(value != NULL)
    {
        if(stricmp(value, "yes") == 0 || atoi(value) == 1)
            m_bWrapText = true;
        else
            m_bWrapText = false;

        value = NULL;
    }

    if(m_pFont == NULL)
    {
#ifdef USE_GLOBAL_LOGGER
        CGlobalLogger::GetSingleton().Write(
            "GUI Framework - General Warning: No font specified! Element Type: %d\n", GetType());
#endif
    }
    return 1;
}

int CGUIStatic::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("Static");

    if(this_element != NULL)
        element = this_element;

    if(GetFont() != NULL)
    {
        if(strlen(GetFont()->GetFontName()) != 0)
            element->SetAttribute("FontByName", GetFont()->GetFontName());
        else
        {
            sprintf((char *)value, "%d", GetFont()->GetUserFontID());
            element->SetAttribute("FontByID", value);

            memset((void *)value, 0, 128);
        }
    }

    if(m_strText != "")
        element->SetAttribute("Text", m_strText.c_str());

    if(!(m_iTextHAlign == 0 && m_iTextVAlign == 0))
    {
        // Horizontal alignment
        if(m_iTextHAlign == 0)
            element->SetAttribute("HAlign", "Left");

        if(m_iTextHAlign == 1)
            element->SetAttribute("HAlign", "Center");

        if(m_iTextHAlign == 2)
            element->SetAttribute("HAlign", "Right");

        // Vertical alignment
        if(m_iTextVAlign == 0)
            element->SetAttribute("VAlign", "Top");

        if(m_iTextVAlign == 1)
            element->SetAttribute("VAlign", "Center");

        if(m_iTextVAlign == 2)
            element->SetAttribute("VAlign", "Bottom");
    }

    // Wrapping text?
    // if(m_bWrapText)
    //	element->SetAttribute("Wrap", "1");

    if(this_element != NULL)
        CGUIElement::Save(NULL, this_element);
    else
    {
        CGUIElement::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIStatic::DrawText()
{
    if(m_strText == "" || m_pFont == NULL)
        return;

    for(int i = 0; i < GetLineCount(); i++)
    {
        string line = "";

        int text_width = GetLineLength(i) * m_pFont->m_iQuadLengthX;

        if(text_width >= GetWidth())
            line = GetLine(i, GetWidth() / m_pFont->m_iQuadLengthX);
        else
            line = GetLine(i);

        // This part is the most important one:
        // Here we are aquiring alignment units (x & y)
        int align_x_pixels = 0, align_y_pixels = 0;

        int max_width_chars  = (GetWidth() / GetFont()->m_iQuadLengthX) + 1;
        int max_height_chars = (GetHeight() / GetFont()->m_iQuadLengthY) + 1;

        // If horizontal alignment is 'left'(0), there is no displacement for text then (alignx = 0)
        if(m_iTextHAlign == 0)
            align_x_pixels = 0;

        // If horizontal alignment is for center, then we calculate the displacement as:
        // alignx = (Total Control Width - (Number Of Chars In Line * Character Width) / 2)
        // because we want text to be in horizontal center of the control
        if(m_iTextHAlign == 1)
            align_x_pixels = (GetWidth() - (line.size() * m_pFont->m_iQuadLengthX)) / 2;

        // If horizontal alignment is right, the displacement is:
        // alignx = Total Control Width - (Number Of Chars * Character Width)
        // because we want text to be on the right - e.g rightmost character will be right near
        // right side of control
        if(m_iTextHAlign == 2)
            align_x_pixels = GetWidth() - (line.size() * m_pFont->m_iQuadLengthX);

        // If the vertical alignment is top(0), we do not displace text down at all
        if(m_iTextVAlign == 0)
            align_y_pixels = 0;

        // If the vertical alignment is middle(1), we displace each line by:
        // aligny = (Total Number of Lines - Line Count) / 2 * Character Height
        // If the total lines visible is 1, or there's only 1 line, the align is in pixels, not lines
        if(m_iTextVAlign == 1)
        {
            // A one line text, align in pixels!
            if(GetHeight() > GetFont()->m_iQuadLengthY && GetHeight() <= 2 * GetFont()->m_iQuadLengthY)
                align_y_pixels = (GetHeight() - GetFont()->m_iQuadLengthY) / 2;
            else   // More than one line, align in lines!
                align_y_pixels = ((max_height_chars - GetLineCount()) / 2) * GetFont()->m_iQuadLengthY;
        }

        // If the vertical alignment is bottom(2), we displace each line by:
        // aligny = (Total Number of Lines - Line Count) * Character Height
        if(m_iTextVAlign == 2)
            align_y_pixels = (max_height_chars - GetLineCount()) * m_pFont->m_iQuadLengthY;

        // Now we align each line by assigning text position
        m_TextPos.x = GetRect().m_iLeft + align_x_pixels;
        m_TextPos.y = GetRect().m_iTop - (i + 1) * m_pFont->m_iQuadLengthY - align_y_pixels;

        // Ensure that we don't print text that's outside control (top & bottom side check)
        if((m_TextPos.y) >= GetRect().m_iBottom
           && (m_TextPos.y + m_pFont->m_iQuadLengthY) <= GetRect().m_iTop)
        {
            CFontEngine::GetSingleton().SetTextPos(CVector3(m_TextPos.x, m_TextPos.y));
            m_pFont->Draw(line.c_str());
        }
    }
}

void CGUIStatic::OnDraw()
{
    // Hide children, and draw only this element
    CGUIElement::OnDraw();
    if(m_bVisible)
        DrawText();   // Draw it's text
}

void CGUIStatic::OnDestroy()
{
    CGUIElement::OnDestroy();
}

string CGUIStatic::GetText()
{
    return m_strText;
}

void CGUIStatic::SetText(string text)
{
    m_strText = text;
}

int CGUIStatic::GetLineLength(int index)
{
    int line_index = 0;
    int char_count = 0;
    for(int i = 0; i < m_strText.size(); i++)
    {
        if(m_strText[i] == '\n')
            line_index++;

        if(index == line_index)
        {
            if(m_strText[i] != '\n')
                char_count++;
        }

        if(char_count > 0 && m_strText[i] == '\n')
            return char_count;
    }

    return char_count;
}

int CGUIStatic::GetTextLength()
{
    return m_strText.size();
}

int CGUIStatic::GetLineCount()
{
    int count = 0;
    for(int i = 0; i < m_strText.size(); i++)
    {
        if(m_strText[i] == '\n')
            count++;
    }

    return count + 1;
}

string CGUIStatic::GetLine(int line, int char_count)
{
    int  line_index = 0;
    int  char_ptr   = 0;
    char buf[255]   = "";
    for(int i = 0; i < m_strText.size(); i++)
    {
        if(m_strText[i] == '\n')
            line_index++;

        if(line_index == line)
        {
            char_ptr = i;
            break;
        }
    }

    int chars = 0;
    if(char_count != -1 && char_count <= GetLineLength(line))
        chars = char_count;
    else
        chars = GetLineLength(line);

    while(m_strText[char_ptr] == '\n')
        char_ptr++;

    for(int j = char_ptr; j < char_ptr + chars; j++)
        buf[j - char_ptr] = m_strText[j];

    return buf;
}

int CGUIStatic::GetTextAlign(bool vert)
{
    if(vert)
        return m_iTextVAlign;

    return m_iTextHAlign;
}
