#include "GUI.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGUIScrollBar::CGUIScrollBar()
{
    // A default is a horizontal scrollbar (byte 1 is 1 if LMouse was initiated over a scroll element)
    SetType(HorizontalScrollBar);
    m_iMinPos  = 0;
    m_iMaxPos  = 1;
    m_fCurPos  = 0;
    m_iPrevPos = 0;
    m_iBtnInc  = 1;
    m_fPPV     = 0;
}

CGUIScrollBar::~CGUIScrollBar() {}

int CGUIScrollBar::Parse(TiXmlNode * this_node, string filename)
{
    if(!CGUIStatic::Parse(this_node, filename))
        return -1;

    TiXmlDocument doc(filename.c_str());
    if(filename != "")
    {
        bool loadOkay = doc.LoadFile();

        if(!loadOkay)
            return false;

        m_pXMLNode = doc.FirstChild();
    }
    else
        m_pXMLNode = this_node;

    // START PARSING ELEMENT PROPERTIES
    char const *   value   = NULL;
    TiXmlElement * element = NULL;
    element                = m_pXMLNode->ToElement();

    int count = 0;
    for(int i = 0; i < GetChildCount(); i++)
    {
        CGUIElement * child = GetChild(i);
        if(child->GetType() == Button)
        {
            child->SetID(SCROLLBAR_BTN_DRAG + count);
            if(count != 0)
            {
                child->m_RestrictionFlags.m_iFlag2 = RestrictMoveX;
                child->m_RestrictionFlags.m_iFlag3 = RestrictMoveY;
            }
            count++;

            if(count == SCROLLBAR_BTN_INC + 1)
                break;
        }
    }

    value = element->Attribute("Type");
    if(value != NULL)
    {
        if((stricmp(value, "h") == 0) || (stricmp(value, "horizontal") == 0))
            SetType(HorizontalScrollBar);
        if((stricmp(value, "v") == 0) || (stricmp(value, "vertical") == 0))
            SetType(VerticalScrollBar);

        value = NULL;
    }

    value = element->Attribute("MinMaxCur");
    if(value != NULL)
    {
        sscanf(value, "%d,%d,%f", &m_iMinPos, &m_iMaxPos, &m_fCurPos);
        SetCurPos(m_fCurPos);
        value = NULL;
    }

    value = element->Attribute("Min");
    if(value != NULL)
    {
        m_iMinPos = atoi(value);

        value = NULL;
    }

    value = element->Attribute("Max");
    if(value != NULL)
    {
        m_iMaxPos = atoi(value);

        value = NULL;
    }

    value = element->Attribute("Cur");
    if(value != NULL)
    {
        m_fCurPos = m_iCurPos = atoi(value);
        value                 = NULL;
    }

    if(m_iMinPos == m_iMaxPos == m_iCurPos == 0)
    {
#ifdef USE_GLOBAL_LOGGER
        CGlobalLogger::GetSingleton().Write(
            "GUI Framework - General Warning: Min/Max/Cur Values are not given! (File: %s, Node: %s)\n",
            element->Attribute("Filename"), element->Value());
#endif
    }

    OnSize(GetRect());
    OnUpdate(m_fCurPos);

    return 1;
}

int CGUIScrollBar::Save(TiXmlNode * parent_node, TiXmlElement * this_element)
{
    // Nowhere to save!			Nothing to save!
    if(parent_node == NULL && this_element == NULL)
        return -1;

    char const     value[128] = "";
    TiXmlElement * element    = new TiXmlElement("ScrollBar");

    if(this_element != NULL)
        element = this_element;

    if(GetType() == HorizontalScrollBar)
        element->SetAttribute("Type", "Horizontal");
    else if(GetType() == VerticalScrollBar)
        element->SetAttribute("Type", "Vertical");

    // Sets attributes
    sprintf((char *)value, "%d,%d,%d", m_iMinPos, m_iMaxPos, m_iCurPos);
    element->SetAttribute("MinMaxCur", value);

    memset((void *)value, 0, 128);

    if(this_element != NULL)
        CGUIStatic::Save(NULL, this_element);
    else
    {
        CGUIStatic::Save(NULL, element);
        parent_node->InsertEndChild(*element);
    }

    if(this_element == NULL)
        delete element;

    return 1;
}

void CGUIScrollBar::OnDraw()
{
    ProcessMessages();
    char buf[64] = "";
    itoa(m_iCurPos, buf, 10);
    SetText(buf);
    CGUIStatic::OnDraw();
}

int CGUIScrollBar::OnSize(tRect newRect)
{
    CGUIElement * btn_drag = FindChild(Button, SCROLLBAR_BTN_DRAG);
    CGUIElement * btn_inc  = FindChild(Button, SCROLLBAR_BTN_INC);
    CGUIElement * btn_dec  = FindChild(Button, SCROLLBAR_BTN_DEC);

    tRect prevRect = GetRect();
    // All went OK, we can resize to this rectangle
    int ret = CGUIStatic::OnSize(newRect);

    int inc_size = 0, dec_size = 0;

    // Set increment/decrement buttons rectangles (if any)
    if(GetType() == HorizontalScrollBar)
    {
        tRect dec_rect, inc_rect;

        if(btn_dec != NULL)
        {
            dec_rect.m_iLeft   = GetRect().m_iLeft;
            dec_rect.m_iRight  = GetRect().m_iLeft + GetHeight();
            dec_rect.m_iTop    = GetRect().m_iTop;
            dec_rect.m_iBottom = GetRect().m_iBottom;

            btn_dec->SetRect(dec_rect);
        }

        if(btn_inc != NULL)
        {
            inc_rect.m_iRight  = GetRect().m_iRight;
            inc_rect.m_iLeft   = GetRect().m_iRight - GetHeight();
            inc_rect.m_iTop    = GetRect().m_iTop;
            inc_rect.m_iBottom = GetRect().m_iBottom;

            btn_inc->SetRect(inc_rect);
        }
    }
    else if(GetType() == VerticalScrollBar)
    {
        tRect dec_rect, inc_rect;

        if(btn_dec != NULL)
        {
            dec_rect.m_iLeft   = GetRect().m_iLeft;
            dec_rect.m_iRight  = GetRect().m_iRight;
            dec_rect.m_iTop    = GetRect().m_iTop;
            dec_rect.m_iBottom = GetRect().m_iTop - GetWidth();

            btn_dec->SetRect(dec_rect);
        }

        if(btn_inc != NULL)
        {
            inc_rect.m_iLeft   = GetRect().m_iLeft;
            inc_rect.m_iRight  = GetRect().m_iRight;
            inc_rect.m_iBottom = GetRect().m_iBottom;
            inc_rect.m_iTop    = inc_rect.m_iBottom + GetWidth();

            btn_inc->SetRect(inc_rect);
        }
    }

    int ttl_width = 0, ttl_height = 0;
    if(GetType() == HorizontalScrollBar)
    {
        if(btn_drag != NULL)
            ttl_width += btn_drag->GetWidth();
        if(btn_inc != NULL)
            ttl_width += btn_inc->GetWidth();
        if(btn_dec != NULL)
            ttl_width += btn_dec->GetWidth();

        if(newRect.m_iRight - newRect.m_iLeft < ttl_width)
        {
            CGUIStatic::OnSize(prevRect);
            return 0;
        }
    }
    else if(GetType() == VerticalScrollBar)
    {
        if(btn_drag != NULL)
            ttl_height += btn_drag->GetHeight();
        if(btn_inc != NULL)
            ttl_height += btn_inc->GetHeight();
        if(btn_dec != NULL)
            ttl_height += btn_dec->GetHeight();

        if((newRect.m_iTop - newRect.m_iBottom) < ttl_height)
        {
            CGUIStatic::OnSize(prevRect);
            return 0;
        }
    }

    OnUpdate(m_fCurPos);
    return ret;
}

void CGUIScrollBar::SetRange(int min, int max)
{
    m_iMinPos = min;
    m_iMaxPos = max;
    if(GetType() == HorizontalScrollBar)   // If this is a horizontal scroll bar
        m_fPPV = float(GetWidth()) / (m_iMaxPos - m_iMinPos);
    else if(GetType() == VerticalScrollBar)   // If its a vertical scroll bar
        m_fPPV = float(GetHeight()) / (m_iMaxPos - m_iMinPos);
}

void CGUIScrollBar::SetCurPos(float x)
{
    m_iPrevPos = m_fCurPos;
    OnUpdate(x);
}

int CGUIScrollBar::GetCurPos()
{
    return m_iCurPos;
}

void CGUIScrollBar::ProcessMessages()
{
    if(GetEventHandler() == NULL)
        return;

    tMessage * tmp = GetEventHandler()->GetNextMsg(NULL);

    while(tmp != NULL)
    {
        switch(tmp->m_eMsg)
        {
            case MoveX:
            case MoveY:
            case MoveXY:
                {
                    if(tmp->m_pSender->GetID() == SCROLLBAR_BTN_DRAG && FindChild(tmp->m_pSender))
                    {
                        float value_per_pixel = 1.0f / m_fPPV;
                        int   displacement    = 0;
                        if(GetType() == HorizontalScrollBar)
                            displacement = CGUIUtility::GetSingleton().GetMousePos().x
                                           - CGUIUtility::GetSingleton().GetPrevMousePos().x;
                        else if(GetType() == VerticalScrollBar)
                            displacement = -(CGUIUtility::GetSingleton().GetMousePos().y
                                             - CGUIUtility::GetSingleton().GetPrevMousePos().y);

                        float val_change = displacement * value_per_pixel;

                        if(m_fCurPos + val_change <= m_iMinPos)
                            SetCurPos(m_iMinPos);
                        else if(m_fCurPos + val_change >= m_iMaxPos)
                            SetCurPos(m_iMaxPos);
                        else
                            SetCurPos(m_fCurPos + val_change);

                        GetEventHandler()->RemoveMessage(tmp);
                        tmp = NULL;
                    }
                    else if(FindChild(tmp->m_pSender) || tmp->m_pSender == this)
                        OnSize(GetRect());
                    break;
                }

            case ButtonPressed:
                {
                    if(tmp->m_pSender->GetID() == SCROLLBAR_BTN_INC && FindChild(tmp->m_pSender))
                    {
                        OnUpdate(m_fCurPos + m_iBtnInc);
                        GetEventHandler()->RemoveMessage(tmp);
                        tmp = NULL;
                    }
                    else if(tmp->m_pSender->GetID() == SCROLLBAR_BTN_DEC && FindChild(tmp->m_pSender))
                    {
                        OnUpdate(m_fCurPos - m_iBtnInc);
                        GetEventHandler()->RemoveMessage(tmp);
                        tmp = NULL;
                    }
                }
        }

        tmp = GetEventHandler()->GetNextMsg(tmp);
    }
}

int CGUIScrollBar::OnUpdate(float curpos)
{
    CGUIElement * btn_inc  = FindChild(Button, SCROLLBAR_BTN_INC);
    CGUIElement * btn_dec  = FindChild(Button, SCROLLBAR_BTN_DEC);
    CGUIElement * btn_drag = FindChild(Button, SCROLLBAR_BTN_DRAG);

    if(curpos >= m_iMaxPos)
    {
        m_fCurPos = m_iMaxPos;
        m_iCurPos = (int)m_iMaxPos;
    }
    else if(curpos <= m_iMinPos)
    {
        m_fCurPos = m_iMinPos;
        m_iCurPos = (int)m_iMinPos;
    }
    if(curpos > m_iMinPos && curpos < m_iMaxPos)
    {
        m_fCurPos = curpos;
        m_iCurPos = (int)curpos;
    }

    tRect r;

    // Set drag button rectangle
    if(GetType() == HorizontalScrollBar)
    {
        int add_width = 0;

        if(btn_dec != NULL)
            add_width += GetHeight();

        if(btn_inc != NULL)
            add_width += GetHeight();

        int ttl_width = GetWidth() - add_width - GetHeight();
        m_fPPV        = (float)ttl_width / ((float)m_iMaxPos - (float)m_iMinPos);

        int scrl_width = GetHeight();

        tRect r;

        int left_extend = GetRect().m_iLeft;
        if(btn_dec != NULL)
            left_extend = btn_dec->GetRect().m_iRight;

        if(btn_drag != NULL)
        {
            r.m_iLeft   = left_extend + m_fCurPos * m_fPPV;
            r.m_iRight  = left_extend + scrl_width + m_fCurPos * m_fPPV;
            r.m_iTop    = GetRect().m_iTop;
            r.m_iBottom = GetRect().m_iBottom;

            btn_drag->SetRect(r);
        }
    }
    if(GetType() == VerticalScrollBar)
    {
        int add_height = 0;

        if(btn_dec != NULL)
            add_height += GetWidth();

        if(btn_inc != NULL)
            add_height += GetWidth();

        int ttl_height = GetHeight() - add_height - GetWidth();
        m_fPPV         = (float)ttl_height / ((float)m_iMaxPos - (float)m_iMinPos);

        int scrl_height = GetWidth();

        tRect r;

        int top_extend = GetRect().m_iTop;
        if(btn_dec != NULL)
            top_extend = btn_dec->GetRect().m_iBottom;

        if(btn_drag != NULL)
        {
            r.m_iTop    = top_extend - m_fCurPos * m_fPPV;
            r.m_iBottom = top_extend - scrl_height - m_fCurPos * m_fPPV;
            r.m_iLeft   = GetRect().m_iLeft;
            r.m_iRight  = GetRect().m_iRight;

            btn_drag->SetRect(r);
        }
    }

    BroadcastMessage(this, Scrolled, m_fCurPos, m_iPrevPos, 0, GetParent());
    return 1;
}

tVERTEX2d CGUIScrollBar::GetRange()
{
    return tVERTEX2d(m_iMinPos, m_iMaxPos);
}
