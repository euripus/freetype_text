#ifndef CUSTOM_FONT
#define CUSTOM_FONT

#include "MaterialManager.h"
#include "Math.h"
#include "tinyxml.h"

class CFontEngine;

#endif